import axios from 'axios';

class DownloadService {
  constructor() {
    this.apiBaseUrl = process.env.REACT_APP_API_BASE_URL || 'https://api.socialdownloader.app';
    this.fallbackApiUrl = 'https://backup-api.socialdownloader.app';
    this.activeDownloads = new Map();
    this.maxRetries = 3;
    this.retryDelay = 1000; // 1 second
  }

  // Check network connectivity
  async checkNetworkConnectivity() {
    try {
      // Try to fetch a simple endpoint or use navigator.onLine
      if (!navigator.onLine) {
        throw new Error('No internet connection detected');
      }
      
      // Test connectivity with a simple ping
      await fetch('https://httpbin.org/get', { 
        method: 'HEAD', 
        mode: 'no-cors',
        timeout: 5000 
      });
      return true;
    } catch (error) {
      throw new Error('Network connectivity check failed. Please check your internet connection.');
    }
  }

  // Retry wrapper for API calls
  async retryApiCall(apiCall, retries = this.maxRetries) {
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        return await apiCall();
      } catch (error) {
        console.warn(`API call attempt ${attempt} failed:`, error.message);
        
        if (attempt === retries) {
          // Last attempt failed
          if (error.code === 'NETWORK_ERROR' || error.message.includes('Network Error')) {
            throw new Error('Unable to connect to the download service. Please check your internet connection and try again.');
          }
          throw error;
        }
        
        // Wait before retry with exponential backoff
        const delay = this.retryDelay * Math.pow(2, attempt - 1);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }

  // Create axios instance with better error handling
  createAxiosInstance(baseURL) {
    const instance = axios.create({
      baseURL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'SocialDownloader/1.0'
      }
    });

    // Request interceptor
    instance.interceptors.request.use(
      (config) => {
        console.log(`Making request to: ${config.baseURL}${config.url}`);
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Response interceptor
    instance.interceptors.response.use(
      (response) => {
        return response;
      },
      (error) => {
        if (error.code === 'ERR_NETWORK' || error.message === 'Network Error') {
          error.code = 'NETWORK_ERROR';
          error.message = 'Network connection failed. Please check your internet connection.';
        } else if (error.code === 'ECONNABORTED') {
          error.message = 'Request timeout. The server is taking too long to respond.';
        } else if (!error.response) {
          error.message = 'Unable to reach the server. Please try again later.';
        }
        return Promise.reject(error);
      }
    );

    return instance;
  }

  // Extract platform and video ID from URL
  extractPlatformInfo(url) {
    const patterns = {
      youtube: [
        /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
        /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/
      ],
      instagram: [
        /instagram\.com\/(?:p|reel|tv)\/([a-zA-Z0-9_-]+)/,
        /instagram\.com\/stories\/[^\/]+\/([0-9]+)/
      ],
      tiktok: [
        /tiktok\.com\/@[^\/]+\/video\/([0-9]+)/,
        /vm\.tiktok\.com\/([a-zA-Z0-9]+)/,
        /tiktok\.com\/t\/([a-zA-Z0-9]+)/
      ],
      twitter: [
        /(?:twitter\.com|x\.com)\/[^\/]+\/status\/([0-9]+)/
      ],
      facebook: [
        /facebook\.com\/[^\/]+\/videos\/([0-9]+)/,
        /fb\.watch\/([a-zA-Z0-9]+)/
      ],
      soundcloud: [
        /soundcloud\.com\/[^\/]+\/[^\/]+/
      ],
      vimeo: [
        /vimeo\.com\/([0-9]+)/
      ]
    };

    for (const [platform, regexes] of Object.entries(patterns)) {
      for (const regex of regexes) {
        const match = url.match(regex);
        if (match) {
          return {
            platform,
            videoId: match[1] || match[0],
            originalUrl: url
          };
        }
      }
    }

    throw new Error('Unsupported platform or invalid URL');
  }

  // Validate URL and check platform support
  async validateUrl(url) {
    try {
      // Basic URL validation
      new URL(url);
      
      // Extract platform info
      const platformInfo = this.extractPlatformInfo(url);
      
      // Check if platform is supported
      const supportedPlatforms = ['youtube', 'instagram', 'tiktok', 'twitter', 'facebook', 'soundcloud', 'vimeo'];
      if (!supportedPlatforms.includes(platformInfo.platform)) {
        throw new Error(`Platform ${platformInfo.platform} is not supported yet`);
      }

      return platformInfo;
    } catch (error) {
      throw new Error(error.message || 'Invalid URL format');
    }
  }

  // Get video metadata with improved error handling
  async getVideoMetadata(url, onProgress = null) {
    try {
      // Check network connectivity first
      await this.checkNetworkConnectivity();
      
      const platformInfo = await this.validateUrl(url);
      
      if (onProgress) onProgress({ stage: 'fetching_metadata', progress: 10 });

      // Try primary API first, then fallback
      const result = await this.retryApiCall(async () => {
        let axiosInstance = this.createAxiosInstance(this.apiBaseUrl);
        
        try {
          const response = await axiosInstance.post('/api/metadata', {
            url: platformInfo.originalUrl,
            platform: platformInfo.platform
          });
          return response;
        } catch (error) {
          console.warn('Primary API failed, trying fallback...', error.message);
          
          // Try fallback API
          axiosInstance = this.createAxiosInstance(this.fallbackApiUrl);
          const response = await axiosInstance.post('/api/metadata', {
            url: platformInfo.originalUrl,
            platform: platformInfo.platform
          });
          return response;
        }
      });

      if (onProgress) onProgress({ stage: 'metadata_ready', progress: 30 });

      return {
        ...result.data,
        platformInfo,
        availableFormats: result.data.formats || this.getDefaultFormats(platformInfo.platform)
      };
    } catch (error) {
      console.error('getVideoMetadata error:', error);
      
      if (error.response?.status === 404) {
        throw new Error('Video not found or may be private');
      } else if (error.response?.status === 429) {
        throw new Error('Too many requests. Please wait and try again');
      } else if (error.response?.status >= 500) {
        throw new Error('Server error. Please try again later');
      } else if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
        throw new Error('Request timeout. Please check your connection and try again');
      } else if (error.code === 'NETWORK_ERROR' || error.message.includes('Network')) {
        throw new Error('Network connection failed. Please check your internet connection and try again');
      }
      
      throw new Error(error.message || 'Failed to fetch video metadata. Please try again');
    }
  }

  // Get default formats for different platforms
  getDefaultFormats(platform) {
    const formatMap = {
      youtube: [
        { id: 'mp4_720p', label: 'MP4 720p', quality: '720p', format: 'mp4', size: 'Medium' },
        { id: 'mp4_1080p', label: 'MP4 1080p', quality: '1080p', format: 'mp4', size: 'Large' },
        { id: 'mp3_128k', label: 'MP3 Audio', quality: '128kbps', format: 'mp3', size: 'Small' }
      ],
      instagram: [
        { id: 'mp4_original', label: 'Original Quality', quality: 'Original', format: 'mp4', size: 'Medium' },
        { id: 'mp3_audio', label: 'Audio Only', quality: '128kbps', format: 'mp3', size: 'Small' }
      ],
      tiktok: [
        { id: 'mp4_original', label: 'Original (No Watermark)', quality: 'Original', format: 'mp4', size: 'Medium' },
        { id: 'mp4_watermark', label: 'With Watermark', quality: 'Original', format: 'mp4', size: 'Medium' },
        { id: 'mp3_audio', label: 'Audio Only', quality: '128kbps', format: 'mp3', size: 'Small' }
      ],
      twitter: [
        { id: 'mp4_720p', label: 'MP4 720p', quality: '720p', format: 'mp4', size: 'Medium' },
        { id: 'mp4_480p', label: 'MP4 480p', quality: '480p', format: 'mp4', size: 'Small' }
      ],
      facebook: [
        { id: 'mp4_720p', label: 'MP4 720p', quality: '720p', format: 'mp4', size: 'Medium' },
        { id: 'mp4_480p', label: 'MP4 480p', quality: '480p', format: 'mp4', size: 'Small' }
      ],
      soundcloud: [
        { id: 'mp3_original', label: 'Original Quality', quality: 'Original', format: 'mp3', size: 'Medium' },
        { id: 'mp3_128k', label: 'MP3 128kbps', quality: '128kbps', format: 'mp3', size: 'Small' }
      ],
      vimeo: [
        { id: 'mp4_1080p', label: 'MP4 1080p', quality: '1080p', format: 'mp4', size: 'Large' },
        { id: 'mp4_720p', label: 'MP4 720p', quality: '720p', format: 'mp4', size: 'Medium' }
      ]
    };

    return formatMap[platform] || [
      { id: 'mp4_720p', label: 'MP4 720p', quality: '720p', format: 'mp4', size: 'Medium' }
    ];
  }

  // Start download with improved error handling
  async startDownload(url, options = {}, onProgress = null) {
    const downloadId = `download_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    try {
      // Check network connectivity first
      await this.checkNetworkConnectivity();
      
      const platformInfo = await this.validateUrl(url);
      
      if (onProgress) onProgress({ stage: 'initializing', progress: 5, downloadId });

      // Start download request with retry mechanism
      const result = await this.retryApiCall(async () => {
        let axiosInstance = this.createAxiosInstance(this.apiBaseUrl);
        
        try {
          const response = await axiosInstance.post('/api/download', {
            url: platformInfo.originalUrl,
            platform: platformInfo.platform,
            format: options.format || 'mp4_720p',
            removeWatermark: options.removeWatermark || false,
            downloadId
          });
          return response;
        } catch (error) {
          console.warn('Primary download API failed, trying fallback...', error.message);
          
          // Try fallback API
          axiosInstance = this.createAxiosInstance(this.fallbackApiUrl);
          const response = await axiosInstance.post('/api/download', {
            url: platformInfo.originalUrl,
            platform: platformInfo.platform,
            format: options.format || 'mp4_720p',
            removeWatermark: options.removeWatermark || false,
            downloadId
          });
          return response;
        }
      });

      const { taskId, estimatedTime } = result.data;
      
      // Store download info
      this.activeDownloads.set(downloadId, {
        taskId,
        url: platformInfo.originalUrl,
        platform: platformInfo.platform,
        status: 'processing',
        startTime: Date.now(),
        estimatedTime
      });

      if (onProgress) onProgress({ 
        stage: 'processing', 
        progress: 15, 
        downloadId, 
        taskId,
        estimatedTime 
      });

      // Poll for download progress
      await this.pollDownloadProgress(downloadId, taskId, onProgress);

    } catch (error) {
      this.activeDownloads.delete(downloadId);
      
      if (error.response?.status === 400) {
        throw new Error('Invalid download parameters');
      } else if (error.response?.status === 403) {
        throw new Error('Video is private or restricted');
      } else if (error.response?.status === 429) {
        throw new Error('Too many download requests. Please wait');
      } else if (error.response?.status >= 500) {
        throw new Error('Download server error. Please try again');
      } else if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
        throw new Error('Download request timeout. Please try again');
      } else if (error.code === 'NETWORK_ERROR' || error.message.includes('Network')) {
        throw new Error('Network connection failed. Please check your internet connection and try again');
      }
      
      throw new Error(error.message || 'Failed to start download');
    }
  }

  // Poll download progress with improved error handling
  async pollDownloadProgress(downloadId, taskId, onProgress = null) {
    const maxAttempts = 60; // 5 minutes max
    let attempts = 0;
    let consecutiveErrors = 0;

    const poll = async () => {
      try {
        attempts++;
        
        const axiosInstance = this.createAxiosInstance(this.apiBaseUrl);
        const response = await axiosInstance.get(`/api/download/status/${taskId}`);

        // Reset error counter on successful request
        consecutiveErrors = 0;

        const { status, progress, downloadUrl, fileName, fileSize, error } = response.data;
        
        const downloadInfo = this.activeDownloads.get(downloadId);
        if (downloadInfo) {
          downloadInfo.status = status;
          downloadInfo.progress = progress;
          downloadInfo.downloadUrl = downloadUrl;
          downloadInfo.fileName = fileName;
          downloadInfo.fileSize = fileSize;
        }

        if (onProgress) {
          onProgress({
            stage: status,
            progress: progress || 0,
            downloadId,
            taskId,
            downloadUrl,
            fileName,
            fileSize,
            estimatedTime: this.calculateRemainingTime(progress, downloadInfo?.startTime)
          });
        }

        if (status === 'completed' && downloadUrl) {
          // Trigger file download
          await this.triggerFileDownload(downloadUrl, fileName);
          this.activeDownloads.delete(downloadId);
          return;
        } else if (status === 'failed' || error) {
          this.activeDownloads.delete(downloadId);
          throw new Error(error || 'Download failed');
        } else if (attempts >= maxAttempts) {
          this.activeDownloads.delete(downloadId);
          throw new Error('Download timeout - please try again');
        } else if (status === 'processing' || status === 'downloading') {
          // Continue polling
          setTimeout(poll, 5000);
        }
      } catch (error) {
        consecutiveErrors++;
        console.warn(`Poll attempt ${attempts} failed:`, error.message);
        
        if (attempts >= maxAttempts || consecutiveErrors >= 5) {
          this.activeDownloads.delete(downloadId);
          throw new Error('Failed to check download status. Please try again');
        }
        
        // Retry on network errors with exponential backoff
        const delay = Math.min(5000 * Math.pow(1.5, consecutiveErrors), 30000);
        setTimeout(poll, delay);
      }
    };

    await poll();
  }

  calculateRemainingTime(progress, startTime) {
    if (!progress || !startTime || progress <= 0) return null;
    
    const elapsed = Date.now() - startTime;
    const rate = progress / elapsed;
    const remaining = (100 - progress) / rate;
    
    return Math.ceil(remaining / 1000); // Convert to seconds
  }

  async triggerFileDownload(downloadUrl, fileName) {
    try {
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = fileName || 'download';
      link.style.display = 'none';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      if (downloadUrl.startsWith('blob:')) {
        URL.revokeObjectURL(downloadUrl);
      }
    } catch (error) {
      console.error('Failed to trigger download:', error);
      window.open(downloadUrl, '_blank');
    }
  }

  async cancelDownload(downloadId) {
    const downloadInfo = this.activeDownloads.get(downloadId);
    if (!downloadInfo) {
      throw new Error('Download not found');
    }

    try {
      const axiosInstance = this.createAxiosInstance(this.apiBaseUrl);
      await axiosInstance.delete(`/api/download/${downloadInfo.taskId}`);
    } catch (error) {
      console.warn('Failed to cancel download on server:', error);
    }

    this.activeDownloads.delete(downloadId);
  }

  getDownloadHistory() {
    try {
      const history = localStorage.getItem('downloadHistory');
      return history ? JSON.parse(history) : [];
    } catch (error) {
      console.error('Failed to load download history:', error);
      return [];
    }
  }

  addToHistory(downloadInfo) {
    try {
      const history = this.getDownloadHistory();
      const newEntry = {
        id: `history_${Date.now()}`,
        url: downloadInfo.url,
        title: downloadInfo.title || 'Unknown Title',
        platform: downloadInfo.platform,
        format: downloadInfo.format,
        fileName: downloadInfo.fileName,
        fileSize: downloadInfo.fileSize,
        downloadDate: new Date().toISOString(),
        thumbnail: downloadInfo.thumbnail
      };

      history.unshift(newEntry);
      const limitedHistory = history.slice(0, 50);
      localStorage.setItem('downloadHistory', JSON.stringify(limitedHistory));
    } catch (error) {
      console.error('Failed to save download history:', error);
    }
  }

  clearHistory() {
    try {
      localStorage.removeItem('downloadHistory');
    } catch (error) {
      console.error('Failed to clear download history:', error);
    }
  }
}

// Create singleton instance
const downloadService = new DownloadService();

export default downloadService;