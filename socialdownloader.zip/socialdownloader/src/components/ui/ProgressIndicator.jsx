import React from 'react';
import Icon from '../AppIcon';

const ProgressIndicator = ({ 
  currentStep = 1, 
  totalSteps = 3, 
  steps = [],
  className = "" 
}) => {
  const defaultSteps = [
    { id: 1, label: 'Enter URL', icon: 'Link' },
    { id: 2, label: 'Preview Content', icon: 'Eye' },
    { id: 3, label: 'Download', icon: 'Download' }
  ];

  const progressSteps = steps.length > 0 ? steps : defaultSteps;

  const getStepStatus = (stepId) => {
    if (stepId < currentStep) return 'completed';
    if (stepId === currentStep) return 'current';
    return 'pending';
  };

  const getStepClasses = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-success text-success-foreground border-success';
      case 'current':
        return 'bg-primary text-primary-foreground border-primary';
      case 'pending':
        return 'bg-muted text-muted-foreground border-border';
      default:
        return 'bg-muted text-muted-foreground border-border';
    }
  };

  const getConnectorClasses = (stepId) => {
    return stepId < currentStep ? 'bg-success' : 'bg-border';
  };

  return (
    <div className={`w-full ${className}`}>
      {/* Mobile Progress Bar */}
      <div className="md:hidden mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-foreground">
            Step {currentStep} of {totalSteps}
          </span>
          <span className="text-xs text-text-secondary">
            {Math.round((currentStep / totalSteps) * 100)}%
          </span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="bg-primary h-2 rounded-full transition-all duration-300 ease-out"
            style={{ width: `${(currentStep / totalSteps) * 100}%` }}
          ></div>
        </div>
        <div className="mt-2">
          <span className="text-sm text-text-secondary">
            {progressSteps.find(step => step.id === currentStep)?.label}
          </span>
        </div>
      </div>

      {/* Desktop Step Indicator */}
      <div className="hidden md:flex items-center justify-center">
        {progressSteps.map((step, index) => {
          const status = getStepStatus(step.id);
          const isLast = index === progressSteps.length - 1;

          return (
            <div key={step.id} className="flex items-center">
              {/* Step Circle */}
              <div className="flex flex-col items-center">
                <div 
                  className={`
                    w-10 h-10 rounded-full border-2 flex items-center justify-center
                    transition-all duration-200 ease-out
                    ${getStepClasses(status)}
                  `}
                >
                  {status === 'completed' ? (
                    <Icon name="Check" size={16} />
                  ) : (
                    <Icon name={step.icon} size={16} />
                  )}
                </div>
                
                {/* Step Label */}
                <span 
                  className={`
                    mt-2 text-xs font-medium text-center
                    ${status === 'current' ? 'text-primary' : 
                      status === 'completed' ? 'text-success' : 'text-text-secondary'}
                  `}
                >
                  {step.label}
                </span>
              </div>

              {/* Connector Line */}
              {!isLast && (
                <div 
                  className={`
                    w-16 h-0.5 mx-4 transition-all duration-300 ease-out
                    ${getConnectorClasses(step.id)}
                  `}
                ></div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ProgressIndicator;