import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../AppIcon';

const Footer = () => {
  const [language, setLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setLanguage(savedLanguage);
  }, []);

  const footerSections = {
    legal: {
      title: language === 'en' ? 'Legal' : 'Legal',
      links: [
        {
          label: language === 'en' ? 'Terms of Service' : 'Términos de Servicio',
          path: '/terms-of-service',
          icon: 'FileText'
        },
        {
          label: language === 'en' ? 'Privacy Policy' : 'Política de Privacidad',
          path: '/privacy-policy',
          icon: 'Shield'
        }
      ]
    },
    support: {
      title: language === 'en' ? 'Support' : 'Soporte',
      links: [
        {
          label: language === 'en' ? 'Contact Support' : 'Contactar Soporte',
          path: '/contact-support',
          icon: 'MessageCircle'
        },
        {
          label: language === 'en' ? 'How to Use' : 'Cómo Usar',
          path: '/how-to-use-guide',
          icon: 'HelpCircle'
        }
      ]
    },
    platforms: {
      title: language === 'en' ? 'Supported Platforms' : 'Plataformas Soportadas',
      items: [
        { name: 'YouTube', icon: 'Youtube' },
        { name: 'Instagram', icon: 'Instagram' },
        { name: 'TikTok', icon: 'Music' },
        { name: 'Twitter', icon: 'Twitter' },
        { name: 'Facebook', icon: 'Facebook' }
      ]
    }
  };

  return (
    <footer className="bg-surface border-t border-border">
      <div className="container mx-auto px-4 lg:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Icon name="Download" size={20} color="white" />
              </div>
              <span className="text-xl font-semibold text-foreground">
                SocialDownloader
              </span>
            </div>
            <p className="text-text-secondary text-sm leading-relaxed mb-4">
              {language === 'en' ?'Fast, secure, and reliable social media content downloader. Download videos, images, and audio from your favorite platforms with ease.' :'Descargador de contenido de redes sociales rápido, seguro y confiable. Descarga videos, imágenes y audio de tus plataformas favoritas con facilidad.'
              }
            </p>
            <div className="flex items-center space-x-2 text-xs text-text-secondary">
              <Icon name="Shield" size={14} />
              <span>
                {language === 'en' ? 'Secure & Private' : 'Seguro y Privado'}
              </span>
            </div>
          </div>

          {/* Legal Section */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-4">
              {footerSections.legal.title}
            </h3>
            <ul className="space-y-3">
              {footerSections.legal.links.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="flex items-center space-x-2 text-sm text-text-secondary hover:text-foreground transition-smooth"
                  >
                    <Icon name={link.icon} size={14} />
                    <span>{link.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Section */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-4">
              {footerSections.support.title}
            </h3>
            <ul className="space-y-3">
              {footerSections.support.links.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="flex items-center space-x-2 text-sm text-text-secondary hover:text-foreground transition-smooth"
                  >
                    <Icon name={link.icon} size={14} />
                    <span>{link.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Platforms Section */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-4">
              {footerSections.platforms.title}
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {footerSections.platforms.items.map((platform) => (
                <div
                  key={platform.name}
                  className="flex items-center space-x-2 p-2 rounded-md bg-background hover:bg-muted transition-smooth"
                >
                  <Icon name={platform.icon} size={16} className="text-text-secondary" />
                  <span className="text-xs text-text-secondary">{platform.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="mt-12 pt-8 border-t border-border">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4 text-xs text-text-secondary">
              <span>
                © 2025 SocialDownloader. {language === 'en' ? 'All rights reserved.' : 'Todos los derechos reservados.'}
              </span>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-xs text-text-secondary">
                <Icon name="Clock" size={12} />
                <span>
                  {language === 'en' ? 'Last updated: July 2025' : 'Última actualización: Julio 2025'}
                </span>
              </div>
              
              <div className="flex items-center space-x-2 text-xs text-success">
                <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
                <span>
                  {language === 'en' ? 'Service Online' : 'Servicio En Línea'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;