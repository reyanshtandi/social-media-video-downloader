import React, { useState, useEffect } from 'react';
import Button from './Button';
import Icon from '../AppIcon';

const UtilityControls = ({ 
  showThemeToggle = true, 
  showLanguageToggle = true,
  className = "",
  variant = "default" // "default", "compact", "minimal"
}) => {
  const [theme, setTheme] = useState('light');
  const [language, setLanguage] = useState('en');

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') || 'light';
    const savedLanguage = localStorage.getItem('language') || 'en';
    setTheme(savedTheme);
    setLanguage(savedLanguage);
    
    if (savedTheme === 'dark') {
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const toggleLanguage = () => {
    const newLanguage = language === 'en' ? 'es' : 'en';
    setLanguage(newLanguage);
    localStorage.setItem('language', newLanguage);
    
    // Trigger a custom event for language change
    window.dispatchEvent(new CustomEvent('languageChange', { 
      detail: { language: newLanguage } 
    }));
  };

  const getVariantClasses = () => {
    switch (variant) {
      case 'compact':
        return 'flex items-center space-x-1';
      case 'minimal':
        return 'flex items-center space-x-2';
      default:
        return 'flex items-center space-x-3';
    }
  };

  const getButtonSize = () => {
    switch (variant) {
      case 'compact':
        return 'sm';
      case 'minimal':
        return 'icon';
      default:
        return 'default';
    }
  };

  const languages = {
    en: { label: 'English', flag: '🇺🇸' },
    es: { label: 'Español', flag: '🇪🇸' }
  };

  return (
    <div className={`${getVariantClasses()} ${className}`}>
      {/* Theme Toggle */}
      {showThemeToggle && (
        <Button
          variant="ghost"
          size={variant === 'minimal' ? 'icon' : getButtonSize()}
          onClick={toggleTheme}
          className={`
            transition-smooth hover:bg-muted
            ${variant === 'minimal' ? 'w-9 h-9' : ''}
          `}
          title={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
        >
          <Icon 
            name={theme === 'light' ? 'Moon' : 'Sun'} 
            size={variant === 'compact' ? 16 : 18} 
          />
          {variant === 'default' && (
            <span className="ml-2 text-sm">
              {theme === 'light' ? 'Dark' : 'Light'}
            </span>
          )}
        </Button>
      )}

      {/* Language Toggle */}
      {showLanguageToggle && (
        <Button
          variant="ghost"
          size={getButtonSize()}
          onClick={toggleLanguage}
          className={`
            transition-smooth hover:bg-muted
            ${variant === 'minimal' ? 'w-9 h-9' : ''}
          `}
          title={`Switch to ${language === 'en' ? 'Spanish' : 'English'}`}
        >
          {variant === 'minimal' ? (
            <Icon name="Globe" size={18} />
          ) : (
            <div className="flex items-center space-x-2">
              <span className="text-sm">
                {languages[language].flag}
              </span>
              {variant === 'default' && (
                <span className="text-sm font-medium">
                  {language.toUpperCase()}
                </span>
              )}
              {variant === 'compact' && (
                <span className="text-xs font-medium">
                  {language.toUpperCase()}
                </span>
              )}
            </div>
          )}
        </Button>
      )}

      {/* Additional Utility - Download Status Indicator */}
      <div className="flex items-center space-x-2">
        <div className="flex items-center space-x-1">
          <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
          <span className="text-xs text-success font-medium">
            {language === 'en' ? 'Online' : 'En Línea'}
          </span>
        </div>
      </div>
    </div>
  );
};

export default UtilityControls;