import { useState, useCallback, useRef } from 'react';
import downloadService from '../services/downloadService';

export const useDownload = () => {
  const [isValidating, setIsValidating] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadComplete, setDownloadComplete] = useState(false);
  const [metadata, setMetadata] = useState(null);
  const [error, setError] = useState(null);
  const [downloadInfo, setDownloadInfo] = useState({
    stage: '',
    estimatedTime: null,
    downloadSpeed: null,
    fileName: '',
    fileSize: '',
    downloadId: null
  });

  const currentDownloadRef = useRef(null);

  // Validate URL and get metadata
  const validateAndFetchMetadata = useCallback(async (url) => {
    setIsValidating(true);
    setError(null);
    setMetadata(null);

    try {
      const result = await downloadService.getVideoMetadata(url, (progress) => {
        setDownloadInfo(prev => ({
          ...prev,
          stage: progress.stage,
          progress: progress.progress
        }));
      });

      setMetadata(result);
      return result;
    } catch (err) {
      setError({
        type: 'validation',
        message: err.message,
        code: 'VALIDATION_ERROR'
      });
      throw err;
    } finally {
      setIsValidating(false);
    }
  }, []);

  // Start download process
  const startDownload = useCallback(async (url, options = {}) => {
    setIsDownloading(true);
    setDownloadComplete(false);
    setDownloadProgress(0);
    setError(null);
    setDownloadInfo({
      stage: 'initializing',
      estimatedTime: null,
      downloadSpeed: null,
      fileName: '',
      fileSize: '',
      downloadId: null
    });

    try {
      currentDownloadRef.current = await downloadService.startDownload(
        url, 
        options, 
        (progress) => {
          setDownloadProgress(progress.progress || 0);
          setDownloadInfo(prev => ({
            ...prev,
            stage: progress.stage,
            estimatedTime: progress.estimatedTime,
            downloadSpeed: progress.downloadSpeed,
            fileName: progress.fileName || prev.fileName,
            fileSize: progress.fileSize || prev.fileSize,
            downloadId: progress.downloadId || prev.downloadId
          }));

          // Download completed
          if (progress.stage === 'completed') {
            setDownloadComplete(true);
            setIsDownloading(false);
            
            // Add to download history
            if (metadata) {
              downloadService.addToHistory({
                url,
                title: metadata.title,
                platform: metadata.platformInfo?.platform,
                format: options.format,
                fileName: progress.fileName,
                fileSize: progress.fileSize,
                thumbnail: metadata.thumbnail
              });
            }
            
            currentDownloadRef.current = null;
          }
        }
      );
    } catch (err) {
      setIsDownloading(false);
      setError({
        type: 'download',
        message: err.message,
        code: 'DOWNLOAD_ERROR'
      });
      currentDownloadRef.current = null;
    }
  }, [metadata]);

  // Cancel current download
  const cancelDownload = useCallback(async () => {
    if (currentDownloadRef.current && downloadInfo.downloadId) {
      try {
        await downloadService.cancelDownload(downloadInfo.downloadId);
      } catch (err) {
        console.warn('Failed to cancel download:', err);
      }
    }

    setIsDownloading(false);
    setDownloadProgress(0);
    setDownloadInfo({
      stage: '',
      estimatedTime: null,
      downloadSpeed: null,
      fileName: '',
      fileSize: '',
      downloadId: null
    });
    currentDownloadRef.current = null;
  }, [downloadInfo.downloadId]);

  // Reset all states
  const reset = useCallback(() => {
    setIsValidating(false);
    setIsDownloading(false);
    setDownloadProgress(0);
    setDownloadComplete(false);
    setMetadata(null);
    setError(null);
    setDownloadInfo({
      stage: '',
      estimatedTime: null,
      downloadSpeed: null,
      fileName: '',
      fileSize: '',
      downloadId: null
    });
    currentDownloadRef.current = null;
  }, []);

  // Clear error
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  return {
    // States
    isValidating,
    isDownloading,
    downloadProgress,
    downloadComplete,
    metadata,
    error,
    downloadInfo,

    // Actions
    validateAndFetchMetadata,
    startDownload,
    cancelDownload,
    reset,
    clearError,

    // Computed values
    isProcessing: isValidating || isDownloading,
    canDownload: metadata && !isDownloading && !isValidating && !error,
    canCancel: isDownloading && downloadInfo.downloadId
  };
};

export default useDownload;