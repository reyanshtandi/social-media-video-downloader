import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import Footer from '../../components/ui/Footer';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import PlatformGuideCard from './components/PlatformGuideCard';
import QuickStartCard from './components/QuickStartCard';
import FAQSection from './components/FAQSection';
import TroubleshootingGuide from './components/TroubleshootingGuide';
import AdvancedOptionsGuide from './components/AdvancedOptionsGuide';

const HowToUseGuide = () => {
  const [language, setLanguage] = useState('en');
  const [expandedPlatform, setExpandedPlatform] = useState(null);
  const [activeSection, setActiveSection] = useState('platforms');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setLanguage(savedLanguage);

    const handleLanguageChange = (event) => {
      setLanguage(event.detail.language);
    };

    window.addEventListener('languageChange', handleLanguageChange);
    return () => window.removeEventListener('languageChange', handleLanguageChange);
  }, []);

  const togglePlatform = (platform) => {
    setExpandedPlatform(expandedPlatform === platform ? null : platform);
  };

  const platforms = ['youtube', 'instagram', 'tiktok', 'twitter'];

  const sections = [
    {
      id: 'platforms',
      label: language === 'en' ? 'Platform Guides' : 'Guías de Plataforma',
      icon: 'Globe'
    },
    {
      id: 'advanced',
      label: language === 'en' ? 'Advanced Options' : 'Opciones Avanzadas',
      icon: 'Settings'
    },
    {
      id: 'troubleshooting',
      label: language === 'en' ? 'Troubleshooting' : 'Solución de Problemas',
      icon: 'Tool'
    },
    {
      id: 'faq',
      label: language === 'en' ? 'FAQ' : 'Preguntas Frecuentes',
      icon: 'HelpCircle'
    }
  ];

  const breadcrumbs = [
    { label: language === 'en' ? 'Home' : 'Inicio', path: '/home-landing-page' },
    { label: language === 'en' ? 'How to Use' : 'Cómo Usar', path: '/how-to-use-guide' }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>
          {language === 'en' ?'How to Use SocialDownloader - Step by Step Guide' :'Cómo Usar SocialDownloader - Guía Paso a Paso'
          }
        </title>
        <meta 
          name="description" 
          content={language === 'en' ?'Learn how to download videos and audio from YouTube, Instagram, TikTok, and more with our comprehensive step-by-step guide.' :'Aprende cómo descargar videos y audio de YouTube, Instagram, TikTok y más con nuestra guía completa paso a paso.'
          } 
        />
        <meta name="keywords" content="social media downloader, how to use, guide, tutorial, YouTube, Instagram, TikTok" />
        <link rel="canonical" href="https://socialdownloader.com/how-to-use-guide" />
      </Helmet>

      <Header />

      <main className="pt-16">
        {/* Breadcrumb Navigation */}
        <div className="bg-muted/30 border-b border-border">
          <div className="container mx-auto px-4 lg:px-6 py-3">
            <nav className="flex items-center space-x-2 text-sm">
              {breadcrumbs.map((crumb, index) => (
                <React.Fragment key={crumb.path}>
                  {index > 0 && (
                    <Icon name="ChevronRight" size={14} className="text-text-secondary" />
                  )}
                  <a
                    href={crumb.path}
                    className={`transition-colors ${
                      index === breadcrumbs.length - 1
                        ? 'text-foreground font-medium'
                        : 'text-text-secondary hover:text-foreground'
                    }`}
                  >
                    {crumb.label}
                  </a>
                </React.Fragment>
              ))}
            </nav>
          </div>
        </div>

        {/* Hero Section */}
        <section className="py-12 lg:py-16 bg-gradient-to-br from-primary/5 to-primary/10">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="max-w-4xl mx-auto text-center">
              <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Icon name="BookOpen" size={32} color="white" />
              </div>
              <h1 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
                {language === 'en' ?'How to Use SocialDownloader' :'Cómo Usar SocialDownloader'
                }
              </h1>
              <p className="text-lg text-text-secondary mb-8 max-w-2xl mx-auto">
                {language === 'en' ?'Complete guide to downloading videos and audio from your favorite social media platforms. Follow our step-by-step instructions for the best results.' :'Guía completa para descargar videos y audio de tus plataformas de redes sociales favoritas. Sigue nuestras instrucciones paso a paso para obtener los mejores resultados.'
                }
              </p>
              <Button
                variant="default"
                size="lg"
                iconName="ArrowDown"
                iconPosition="right"
                onClick={() => document.getElementById('guide-content').scrollIntoView({ behavior: 'smooth' })}
              >
                {language === 'en' ? 'Start Learning' : 'Comenzar a Aprender'}
              </Button>
            </div>
          </div>
        </section>

        {/* Main Content */}
        <section id="guide-content" className="py-12 lg:py-16">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="grid lg:grid-cols-4 gap-8">
              {/* Sidebar Navigation - Desktop */}
              <div className="lg:col-span-1">
                <div className="sticky top-24 space-y-6">
                  {/* Quick Start Card */}
                  <QuickStartCard language={language} />

                  {/* Section Navigation */}
                  <div className="hidden lg:block">
                    <h3 className="font-semibold text-foreground mb-4">
                      {language === 'en' ? 'Guide Sections' : 'Secciones de la Guía'}
                    </h3>
                    <nav className="space-y-2">
                      {sections.map((section) => (
                        <button
                          key={section.id}
                          onClick={() => setActiveSection(section.id)}
                          className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm font-medium transition-colors text-left ${
                            activeSection === section.id
                              ? 'bg-primary text-primary-foreground'
                              : 'text-text-secondary hover:text-foreground hover:bg-muted'
                          }`}
                        >
                          <Icon name={section.icon} size={16} />
                          <span>{section.label}</span>
                        </button>
                      ))}
                    </nav>
                  </div>
                </div>
              </div>

              {/* Main Content Area */}
              <div className="lg:col-span-3">
                {/* Mobile Section Navigation */}
                <div className="lg:hidden mb-8">
                  <div className="flex overflow-x-auto space-x-2 pb-2">
                    {sections.map((section) => (
                      <button
                        key={section.id}
                        onClick={() => setActiveSection(section.id)}
                        className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                          activeSection === section.id
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted text-text-secondary hover:text-foreground'
                        }`}
                      >
                        <Icon name={section.icon} size={16} />
                        <span>{section.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Content Sections */}
                <div className="space-y-12">
                  {/* Platform Guides */}
                  {activeSection === 'platforms' && (
                    <div className="space-y-8">
                      <div className="text-center">
                        <h2 className="text-2xl font-semibold text-foreground mb-4">
                          {language === 'en' ? 'Platform-Specific Guides' : 'Guías Específicas por Plataforma'}
                        </h2>
                        <p className="text-text-secondary">
                          {language === 'en' ?'Select a platform below to see detailed download instructions' :'Selecciona una plataforma a continuación para ver instrucciones detalladas de descarga'
                          }
                        </p>
                      </div>

                      <div className="space-y-4">
                        {platforms.map((platform) => (
                          <PlatformGuideCard
                            key={platform}
                            platform={platform}
                            isExpanded={expandedPlatform === platform}
                            onToggle={() => togglePlatform(platform)}
                            language={language}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Advanced Options */}
                  {activeSection === 'advanced' && (
                    <AdvancedOptionsGuide language={language} />
                  )}

                  {/* Troubleshooting */}
                  {activeSection === 'troubleshooting' && (
                    <TroubleshootingGuide language={language} />
                  )}

                  {/* FAQ */}
                  {activeSection === 'faq' && (
                    <FAQSection language={language} />
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-12 bg-primary/5 border-t border-border">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                {language === 'en' ? 'Ready to Start Downloading?' : '¿Listo para Comenzar a Descargar?'}
              </h2>
              <p className="text-text-secondary mb-6">
                {language === 'en' ?'Now that you know how to use our service, start downloading your favorite content!' :'¡Ahora que sabes cómo usar nuestro servicio, comienza a descargar tu contenido favorito!'
                }
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  variant="default"
                  size="lg"
                  iconName="Download"
                  iconPosition="left"
                  onClick={() => window.location.href = '/home-landing-page'}
                >
                  {language === 'en' ? 'Start Downloading' : 'Comenzar a Descargar'}
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  iconName="MessageCircle"
                  iconPosition="left"
                  onClick={() => window.location.href = '/contact-support'}
                >
                  {language === 'en' ? 'Get Support' : 'Obtener Soporte'}
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default HowToUseGuide;