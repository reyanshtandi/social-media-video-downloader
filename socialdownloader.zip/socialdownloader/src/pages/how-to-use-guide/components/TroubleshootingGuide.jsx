import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TroubleshootingGuide = ({ language }) => {
  const [activeIssue, setActiveIssue] = useState(null);

  const troubleshootingData = language === 'en' ? [
    {
      id: 1,
      issue: "Download fails or shows error",
      icon: "AlertCircle",
      color: "text-destructive",
      solutions: [
        "Verify the URL is correct and complete",
        "Check if the content is publicly accessible",
        "Try copying the URL again from the source",
        "Clear your browser cache and cookies",
        "Try using a different browser or device"
      ]
    },
    {
      id: 2,
      issue: "Video quality is poor",
      icon: "Monitor",
      color: "text-warning",
      solutions: [
        "Select a higher quality option (720p or 1080p)",
        "Check if the original video has higher quality available",
        "Ensure stable internet connection during download",
        "Try downloading during off-peak hours"
      ]
    },
    {
      id: 3,
      issue: "Download is very slow",
      icon: "Clock",
      color: "text-blue-500",
      solutions: [
        "Choose lower quality for faster downloads",
        "Check your internet connection speed",
        "Try downloading during less busy hours",
        "Close other bandwidth-heavy applications"
      ]
    },
    {
      id: 4,
      issue: "Private content not accessible",
      icon: "Lock",
      color: "text-text-secondary",
      solutions: [
        "Ensure the account/content is set to public",
        "Log into the platform and make content public",
        "Contact the content owner for permission",
        "Use official platform download features if available"
      ]
    }
  ] : [
    {
      id: 1,
      issue: "La descarga falla o muestra error",
      icon: "AlertCircle",
      color: "text-destructive",
      solutions: [
        "Verifica que la URL sea correcta y completa",
        "Comprueba si el contenido es accesible públicamente",
        "Intenta copiar la URL nuevamente desde la fuente",
        "Limpia la caché y cookies de tu navegador",
        "Intenta usar un navegador o dispositivo diferente"
      ]
    },
    {
      id: 2,
      issue: "La calidad del video es pobre",
      icon: "Monitor",
      color: "text-warning",
      solutions: [
        "Selecciona una opción de mayor calidad (720p o 1080p)",
        "Verifica si el video original tiene mayor calidad disponible",
        "Asegura una conexión estable a internet durante la descarga",
        "Intenta descargar durante horas de menor tráfico"
      ]
    },
    {
      id: 3,
      issue: "La descarga es muy lenta",
      icon: "Clock",
      color: "text-blue-500",
      solutions: [
        "Elige menor calidad para descargas más rápidas",
        "Verifica la velocidad de tu conexión a internet",
        "Intenta descargar durante horas menos ocupadas",
        "Cierra otras aplicaciones que consuman ancho de banda"
      ]
    },
    {
      id: 4,
      issue: "Contenido privado no accesible",
      icon: "Lock",
      color: "text-text-secondary",
      solutions: [
        "Asegura que la cuenta/contenido esté configurado como público",
        "Inicia sesión en la plataforma y haz el contenido público",
        "Contacta al propietario del contenido para obtener permiso",
        "Usa las funciones oficiales de descarga de la plataforma si están disponibles"
      ]
    }
  ];

  const toggleIssue = (issueId) => {
    setActiveIssue(activeIssue === issueId ? null : issueId);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center mx-auto mb-3">
          <Icon name="Tool" size={24} className="text-warning" />
        </div>
        <h2 className="text-2xl font-semibold text-foreground mb-2">
          {language === 'en' ? 'Troubleshooting Guide' : 'Guía de Solución de Problemas'}
        </h2>
        <p className="text-text-secondary">
          {language === 'en' ?'Common issues and their solutions' :'Problemas comunes y sus soluciones'
          }
        </p>
      </div>

      <div className="grid gap-4">
        {troubleshootingData.map((item) => (
          <div key={item.id} className="border border-border rounded-lg overflow-hidden">
            <button
              onClick={() => toggleIssue(item.id)}
              className="w-full p-4 flex items-center justify-between hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <Icon name={item.icon} size={20} className={item.color} />
                <span className="font-medium text-foreground text-left">
                  {item.issue}
                </span>
              </div>
              <Icon 
                name={activeIssue === item.id ? 'ChevronUp' : 'ChevronDown'} 
                size={20} 
                className="text-text-secondary" 
              />
            </button>

            {activeIssue === item.id && (
              <div className="px-4 pb-4">
                <div className="pt-2 border-t border-border">
                  <h4 className="font-medium text-foreground mb-3 text-sm">
                    {language === 'en' ? 'Solutions:' : 'Soluciones:'}
                  </h4>
                  <ul className="space-y-2">
                    {item.solutions.map((solution, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <Icon name="CheckCircle" size={14} className="text-success mt-1 flex-shrink-0" />
                        <span className="text-sm text-text-secondary leading-relaxed">
                          {solution}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={20} className="text-primary mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <h4 className="font-medium text-foreground mb-1">
              {language === 'en' ? 'Still Need Help?' : '¿Aún Necesitas Ayuda?'}
            </h4>
            <p className="text-sm text-text-secondary mb-3">
              {language === 'en' ?'If none of these solutions work, our support team is ready to assist you.' :'Si ninguna de estas soluciones funciona, nuestro equipo de soporte está listo para ayudarte.'
              }
            </p>
            <Button
              variant="outline"
              size="sm"
              iconName="MessageCircle"
              iconPosition="left"
              onClick={() => window.location.href = '/contact-support'}
            >
              {language === 'en' ? 'Contact Support' : 'Contactar Soporte'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TroubleshootingGuide;