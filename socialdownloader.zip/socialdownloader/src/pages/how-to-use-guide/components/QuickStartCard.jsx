import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickStartCard = ({ language }) => {
  const quickSteps = language === 'en' ? [
    {
      icon: 'Link',
      title: 'Copy URL',
      description: 'Copy the link from any supported social media platform'
    },
    {
      icon: 'Download',
      title: 'Paste & Download',
      description: 'Paste the URL and select your preferred format'
    },
    {
      icon: 'CheckCircle',
      title: 'Enjoy Content',
      description: 'Save to your device and enjoy offline'
    }
  ] : [
    {
      icon: 'Link',
      title: 'Copiar URL',
      description: 'Copia el enlace de cualquier plataforma de redes sociales compatible'
    },
    {
      icon: 'Download',
      title: 'Pegar y Descargar',
      description: 'Pega la URL y selecciona tu formato preferido'
    },
    {
      icon: 'CheckCircle',
      title: 'Disfruta el Contenido',
      description: 'Guarda en tu dispositivo y disfruta sin conexión'
    }
  ];

  return (
    <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-xl p-6 border border-primary/20">
      <div className="text-center mb-6">
        <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mx-auto mb-3">
          <Icon name="Zap" size={24} color="white" />
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-2">
          {language === 'en' ? 'Quick Start Guide' : 'Guía de Inicio Rápido'}
        </h3>
        <p className="text-sm text-text-secondary">
          {language === 'en' ?'Get started in 3 simple steps' :'Comienza en 3 simples pasos'
          }
        </p>
      </div>

      <div className="space-y-4">
        {quickSteps.map((step, index) => (
          <div key={index} className="flex items-start space-x-4">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
              <Icon name={step.icon} size={16} color="white" />
            </div>
            <div className="flex-1">
              <h4 className="font-medium text-foreground text-sm mb-1">
                {step.title}
              </h4>
              <p className="text-xs text-text-secondary leading-relaxed">
                {step.description}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-4 border-t border-primary/20">
        <Button
          variant="default"
          size="sm"
          fullWidth
          iconName="ArrowRight"
          iconPosition="right"
          onClick={() => window.location.href = '/home-landing-page'}
        >
          {language === 'en' ? 'Start Downloading' : 'Comenzar a Descargar'}
        </Button>
      </div>
    </div>
  );
};

export default QuickStartCard;