import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AdvancedOptionsGuide = ({ language }) => {
  const [showAdvanced, setShowAdvanced] = useState(false);

  const formatOptions = {
    video: language === 'en' ? [
      { format: 'MP4', quality: '360p', size: '~25MB/min', description: 'Standard quality, smaller file size' },
      { format: 'MP4', quality: '720p', size: '~50MB/min', description: 'High quality, balanced size' },
      { format: 'MP4', quality: '1080p', size: '~100MB/min', description: 'Full HD, larger file size' },
      { format: 'WebM', quality: '720p', size: '~40MB/min', description: 'Web optimized format' }
    ] : [
      { format: 'MP4', quality: '360p', size: '~25MB/min', description: 'Calidad estándar, archivo más pequeño' },
      { format: 'MP4', quality: '720p', size: '~50MB/min', description: 'Alta calidad, tamaño equilibrado' },
      { format: 'MP4', quality: '1080p', size: '~100MB/min', description: 'Full HD, archivo más grande' },
      { format: 'WebM', quality: '720p', size: '~40MB/min', description: 'Formato optimizado para web' }
    ],
    audio: language === 'en' ? [
      { format: 'MP3', bitrate: '128kbps', size: '~1MB/min', description: 'Standard audio quality' },
      { format: 'MP3', bitrate: '256kbps', size: '~2MB/min', description: 'High audio quality' },
      { format: 'MP3', bitrate: '320kbps', size: '~2.5MB/min', description: 'Premium audio quality' },
      { format: 'M4A', bitrate: '256kbps', size: '~2MB/min', description: 'Apple optimized format' }
    ] : [
      { format: 'MP3', bitrate: '128kbps', size: '~1MB/min', description: 'Calidad de audio estándar' },
      { format: 'MP3', bitrate: '256kbps', size: '~2MB/min', description: 'Alta calidad de audio' },
      { format: 'MP3', bitrate: '320kbps', size: '~2.5MB/min', description: 'Calidad de audio premium' },
      { format: 'M4A', bitrate: '256kbps', size: '~2MB/min', description: 'Formato optimizado para Apple' }
    ]
  };

  const advancedFeatures = language === 'en' ? [
    {
      icon: 'Scissors',
      title: 'TikTok Watermark Removal',
      description: 'Remove TikTok watermarks for cleaner video downloads',
      steps: [
        'Select TikTok video for download',
        'Check the "Remove Watermark" option',
        'Processing will take slightly longer',
        'Download clean video without watermark'
      ]
    },
    {
      icon: 'Download',
      title: 'Batch Downloads',
      description: 'Download multiple videos from playlists or channels',
      steps: [
        'Paste playlist or channel URL',
        'Select individual videos or download all',
        'Choose format for all videos',
        'Monitor download progress for each item'
      ]
    },
    {
      icon: 'Settings',
      title: 'Quality Auto-Selection',
      description: 'Automatically choose best available quality',
      steps: [
        'Enable "Auto Quality" in settings',
        'System selects highest available quality',
        'Fallback to lower quality if needed',
        'Optimal balance of quality and speed'
      ]
    }
  ] : [
    {
      icon: 'Scissors',
      title: 'Eliminación de Marca de Agua de TikTok',
      description: 'Elimina las marcas de agua de TikTok para descargas de video más limpias',
      steps: [
        'Selecciona video de TikTok para descargar',
        'Marca la opción "Eliminar Marca de Agua"',
        'El procesamiento tomará un poco más de tiempo',
        'Descarga video limpio sin marca de agua'
      ]
    },
    {
      icon: 'Download',
      title: 'Descargas por Lotes',
      description: 'Descarga múltiples videos de listas de reproducción o canales',
      steps: [
        'Pega URL de lista de reproducción o canal',
        'Selecciona videos individuales o descarga todos',
        'Elige formato para todos los videos',
        'Monitorea el progreso de descarga para cada elemento'
      ]
    },
    {
      icon: 'Settings',
      title: 'Selección Automática de Calidad',
      description: 'Elige automáticamente la mejor calidad disponible',
      steps: [
        'Habilita "Calidad Automática" en configuraciones',
        'El sistema selecciona la mayor calidad disponible',
        'Recurre a menor calidad si es necesario',
        'Balance óptimo de calidad y velocidad'
      ]
    }
  ];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
          <Icon name="Settings" size={24} className="text-primary" />
        </div>
        <h2 className="text-2xl font-semibold text-foreground mb-2">
          {language === 'en' ? 'Advanced Options' : 'Opciones Avanzadas'}
        </h2>
        <p className="text-text-secondary">
          {language === 'en' ?'Customize your download experience with advanced features' :'Personaliza tu experiencia de descarga con funciones avanzadas'
          }
        </p>
      </div>

      {/* Format Selection Guide */}
      <div className="space-y-6">
        <Button
          variant="outline"
          onClick={() => setShowAdvanced(!showAdvanced)}
          iconName={showAdvanced ? 'ChevronUp' : 'ChevronDown'}
          iconPosition="right"
          className="w-full justify-between"
        >
          {language === 'en' ? 'Show Format Details' : 'Mostrar Detalles de Formato'}
        </Button>

        {showAdvanced && (
          <div className="grid md:grid-cols-2 gap-6">
            {/* Video Formats */}
            <div className="space-y-4">
              <h3 className="font-semibold text-foreground flex items-center space-x-2">
                <Icon name="Video" size={20} className="text-primary" />
                <span>{language === 'en' ? 'Video Formats' : 'Formatos de Video'}</span>
              </h3>
              <div className="space-y-3">
                {formatOptions.video.map((option, index) => (
                  <div key={index} className="border border-border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-foreground">
                        {option.format} - {option.quality}
                      </span>
                      <span className="text-xs text-text-secondary bg-muted px-2 py-1 rounded">
                        {option.size}
                      </span>
                    </div>
                    <p className="text-sm text-text-secondary">{option.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Audio Formats */}
            <div className="space-y-4">
              <h3 className="font-semibold text-foreground flex items-center space-x-2">
                <Icon name="Music" size={20} className="text-primary" />
                <span>{language === 'en' ? 'Audio Formats' : 'Formatos de Audio'}</span>
              </h3>
              <div className="space-y-3">
                {formatOptions.audio.map((option, index) => (
                  <div key={index} className="border border-border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-foreground">
                        {option.format} - {option.bitrate}
                      </span>
                      <span className="text-xs text-text-secondary bg-muted px-2 py-1 rounded">
                        {option.size}
                      </span>
                    </div>
                    <p className="text-sm text-text-secondary">{option.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Advanced Features */}
      <div className="space-y-6">
        <h3 className="text-xl font-semibold text-foreground text-center">
          {language === 'en' ? 'Advanced Features' : 'Funciones Avanzadas'}
        </h3>
        
        <div className="grid gap-6">
          {advancedFeatures.map((feature, index) => (
            <div key={index} className="border border-border rounded-lg p-6">
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon name={feature.icon} size={20} className="text-primary" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-foreground mb-2">{feature.title}</h4>
                  <p className="text-sm text-text-secondary mb-4">{feature.description}</p>
                  
                  <div className="space-y-2">
                    <h5 className="text-sm font-medium text-foreground">
                      {language === 'en' ? 'How to use:' : 'Cómo usar:'}
                    </h5>
                    <ol className="space-y-1">
                      {feature.steps.map((step, stepIndex) => (
                        <li key={stepIndex} className="flex items-start space-x-2 text-sm text-text-secondary">
                          <span className="w-5 h-5 bg-primary/20 text-primary rounded-full flex items-center justify-center text-xs font-medium flex-shrink-0 mt-0.5">
                            {stepIndex + 1}
                          </span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Pro Tips */}
      <div className="bg-success/5 border border-success/20 rounded-lg p-6">
        <div className="flex items-start space-x-3">
          <Icon name="Lightbulb" size={24} className="text-success flex-shrink-0" />
          <div>
            <h4 className="font-semibold text-foreground mb-2">
              {language === 'en' ? 'Pro Tips for Better Downloads' : 'Consejos Pro para Mejores Descargas'}
            </h4>
            <ul className="space-y-2 text-sm text-text-secondary">
              <li className="flex items-start space-x-2">
                <Icon name="Check" size={14} className="text-success mt-1 flex-shrink-0" />
                <span>
                  {language === 'en' ?'Use 720p for the best balance of quality and file size' :'Usa 720p para el mejor balance de calidad y tamaño de archivo'
                  }
                </span>
              </li>
              <li className="flex items-start space-x-2">
                <Icon name="Check" size={14} className="text-success mt-1 flex-shrink-0" />
                <span>
                  {language === 'en' ?'Download during off-peak hours for faster processing' :'Descarga durante horas de menor tráfico para procesamiento más rápido'
                  }
                </span>
              </li>
              <li className="flex items-start space-x-2">
                <Icon name="Check" size={14} className="text-success mt-1 flex-shrink-0" />
                <span>
                  {language === 'en' ?'Use MP3 320kbps for music downloads for best audio quality' :'Usa MP3 320kbps para descargas de música para la mejor calidad de audio'
                  }
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdvancedOptionsGuide;