import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const PlatformGuideCard = ({ platform, isExpanded, onToggle, language }) => {
  const [copiedUrl, setCopiedUrl] = useState(null);

  const handleCopyUrl = (url) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(url);
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  const platformData = {
    youtube: {
      name: 'YouTube',
      icon: 'Youtube',
      color: 'text-red-500',
      bgColor: 'bg-red-50 dark:bg-red-950/20',
      borderColor: 'border-red-200 dark:border-red-800',
      exampleUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      screenshot: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=600&h=300&fit=crop',
      steps: language === 'en' ? [
        "Navigate to the YouTube video you want to download",
        "Copy the URL from your browser\'s address bar",
        "Paste the URL into our download field",
        "Select your preferred format and quality",
        "Click download and wait for processing"
      ] : [
        "Navega al video de YouTube que quieres descargar",
        "Copia la URL de la barra de direcciones de tu navegador",
        "Pega la URL en nuestro campo de descarga",
        "Selecciona tu formato y calidad preferidos",
        "Haz clic en descargar y espera el procesamiento"
      ],
      tips: language === 'en' ? [
        "Works with both regular and shortened YouTube URLs",
        "Supports playlists and individual videos",
        "Age-restricted content may require special handling"
      ] : [
        "Funciona con URLs regulares y acortadas de YouTube",
        "Soporta listas de reproducción y videos individuales",
        "El contenido con restricción de edad puede requerir manejo especial"
      ]
    },
    instagram: {
      name: 'Instagram',
      icon: 'Instagram',
      color: 'text-pink-500',
      bgColor: 'bg-pink-50 dark:bg-pink-950/20',
      borderColor: 'border-pink-200 dark:border-pink-800',
      exampleUrl: 'https://www.instagram.com/p/ABC123DEF456/',
      screenshot: 'https://images.unsplash.com/photo-1611262588024-d12430b98920?w=600&h=300&fit=crop',
      steps: language === 'en' ? [
        "Open the Instagram post, reel, or story",
        "Tap the three dots menu and select 'Copy Link'",
        "Paste the copied URL into our downloader",
        "Choose between video or image format",
        "Download your content instantly"
      ] : [
        "Abre la publicación, reel o historia de Instagram",
        "Toca el menú de tres puntos y selecciona \'Copiar enlace'",
        "Pega la URL copiada en nuestro descargador",
        "Elige entre formato de video o imagen",
        "Descarga tu contenido instantáneamente"
      ],
      tips: language === 'en' ? [
        "Works with posts, reels, IGTV, and stories",
        "Private accounts require public access",
        "Stories are only available for 24 hours"
      ] : [
        "Funciona con publicaciones, reels, IGTV e historias",
        "Las cuentas privadas requieren acceso público",
        "Las historias solo están disponibles por 24 horas"
      ]
    },
    tiktok: {
      name: 'TikTok',
      icon: 'Music',
      color: 'text-black dark:text-white',
      bgColor: 'bg-gray-50 dark:bg-gray-950/20',
      borderColor: 'border-gray-200 dark:border-gray-800',
      exampleUrl: 'https://www.tiktok.com/@username/video/1234567890123456789',
      screenshot: 'https://images.unsplash.com/photo-1611605698335-8b1569810432?w=600&h=300&fit=crop',
      steps: language === 'en' ? [
        "Find the TikTok video you want to save",
        "Tap the \'Share\' button on the right side",
        "Select \'Copy Link\' from the share menu",
        "Paste the URL into our download tool",
        "Choose to remove watermark if desired"
      ] : [
        "Encuentra el video de TikTok que quieres guardar",
        "Toca el botón 'Compartir' en el lado derecho",
        "Selecciona \'Copiar enlace\' del menú de compartir",
        "Pega la URL en nuestra herramienta de descarga",
        "Elige quitar la marca de agua si lo deseas"
      ],
      tips: language === 'en' ? [
        "Option to download with or without watermark",
        "Supports both mobile and desktop URLs",
        "Works with trending and regular videos"
      ] : [
        "Opción de descargar con o sin marca de agua",
        "Soporta URLs tanto móviles como de escritorio",
        "Funciona con videos trending y regulares"
      ]
    },
    twitter: {
      name: 'Twitter/X',
      icon: 'Twitter',
      color: 'text-blue-500',
      bgColor: 'bg-blue-50 dark:bg-blue-950/20',
      borderColor: 'border-blue-200 dark:border-blue-800',
      exampleUrl: 'https://twitter.com/username/status/1234567890123456789',
      screenshot: 'https://images.unsplash.com/photo-1611605698323-b1e99cfd37ea?w=600&h=300&fit=crop',
      steps: language === 'en' ? [
        "Open the tweet containing the video",
        "Click the share icon below the tweet",
        "Select \'Copy link to Tweet'",
        "Paste the URL into our downloader",
        "Download the video in your preferred quality"
      ] : [
        "Abre el tweet que contiene el video",
        "Haz clic en el ícono de compartir debajo del tweet",
        "Selecciona \'Copiar enlace al Tweet'",
        "Pega la URL en nuestro descargador",
        "Descarga el video en tu calidad preferida"
      ],
      tips: language === 'en' ? [
        "Works with both Twitter and X.com URLs",
        "Supports videos and GIFs",
        "Protected tweets require public access"
      ] : [
        "Funciona con URLs de Twitter y X.com",
        "Soporta videos y GIFs",
        "Los tweets protegidos requieren acceso público"
      ]
    }
  };

  const data = platformData[platform];

  return (
    <div className={`border rounded-lg overflow-hidden transition-all duration-200 ${data.borderColor} ${isExpanded ? data.bgColor : 'bg-background'}`}>
      <button
        onClick={onToggle}
        className="w-full p-4 flex items-center justify-between hover:bg-muted/50 transition-colors"
      >
        <div className="flex items-center space-x-3">
          <div className={`w-10 h-10 rounded-lg ${data.bgColor} flex items-center justify-center`}>
            <Icon name={data.icon} size={20} className={data.color} />
          </div>
          <div className="text-left">
            <h3 className="font-semibold text-foreground">{data.name}</h3>
            <p className="text-sm text-text-secondary">
              {language === 'en' ? 'Step-by-step guide' : 'Guía paso a paso'}
            </p>
          </div>
        </div>
        <Icon 
          name={isExpanded ? 'ChevronUp' : 'ChevronDown'} 
          size={20} 
          className="text-text-secondary" 
        />
      </button>

      {isExpanded && (
        <div className="p-4 pt-0 space-y-6">
          {/* Example URL */}
          <div className="bg-background rounded-lg p-4 border border-border">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">
                {language === 'en' ? 'Example URL:' : 'URL de ejemplo:'}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleCopyUrl(data.exampleUrl)}
                iconName={copiedUrl === data.exampleUrl ? 'Check' : 'Copy'}
                iconPosition="left"
                className="text-xs"
              >
                {copiedUrl === data.exampleUrl 
                  ? (language === 'en' ? 'Copied!' : '¡Copiado!') 
                  : (language === 'en' ? 'Copy' : 'Copiar')
                }
              </Button>
            </div>
            <code className="text-xs text-text-secondary break-all bg-muted p-2 rounded block">
              {data.exampleUrl}
            </code>
          </div>

          {/* Screenshot */}
          <div className="space-y-2">
            <h4 className="font-medium text-foreground">
              {language === 'en' ? 'Visual Example:' : 'Ejemplo visual:'}
            </h4>
            <div className="rounded-lg overflow-hidden border border-border">
              <Image
                src={data.screenshot}
                alt={`${data.name} interface example`}
                className="w-full h-48 object-cover"
              />
            </div>
          </div>

          {/* Steps */}
          <div className="space-y-3">
            <h4 className="font-medium text-foreground">
              {language === 'en' ? 'Step-by-step Instructions:' : 'Instrucciones paso a paso:'}
            </h4>
            <ol className="space-y-2">
              {data.steps.map((step, index) => (
                <li key={index} className="flex items-start space-x-3">
                  <span className={`w-6 h-6 rounded-full ${data.bgColor} ${data.color} flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-0.5`}>
                    {index + 1}
                  </span>
                  <span className="text-sm text-text-secondary leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>
          </div>

          {/* Tips */}
          <div className="space-y-3">
            <h4 className="font-medium text-foreground">
              {language === 'en' ? 'Pro Tips:' : 'Consejos profesionales:'}
            </h4>
            <ul className="space-y-2">
              {data.tips.map((tip, index) => (
                <li key={index} className="flex items-start space-x-2">
                  <Icon name="Lightbulb" size={14} className="text-warning mt-1 flex-shrink-0" />
                  <span className="text-sm text-text-secondary leading-relaxed">{tip}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default PlatformGuideCard;