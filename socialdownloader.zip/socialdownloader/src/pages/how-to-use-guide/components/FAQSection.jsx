import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const FAQSection = ({ language }) => {
  const [expandedFaq, setExpandedFaq] = useState(null);

  const faqData = language === 'en' ? [
    {
      id: 1,
      question: "What video formats are supported for download?",
      answer: "We support MP4 and WebM video formats with quality options ranging from 360p to 1080p. For audio, we offer MP3 and M4A formats with bitrates from 128kbps to 320kbps."
    },
    {
      id: 2,
      question: "Can I download private or restricted content?",
      answer: "No, we can only download publicly available content. Private accounts, age-restricted videos, or content behind paywalls cannot be accessed through our service."
    },
    {
      id: 3,
      question: "Is there a limit to how many videos I can download?",
      answer: "We implement fair usage policies to ensure service quality for all users. Heavy usage may be temporarily rate-limited, but normal usage is unrestricted."
    },
    {
      id: 4,
      question: "Why is my download taking so long?",
      answer: "Download speed depends on video length, quality selected, and server load. Higher quality videos (1080p) take longer to process than lower quality options (360p)."
    },
    {
      id: 5,
      question: "Can I remove TikTok watermarks?",
      answer: "Yes, we offer a watermark removal option for TikTok videos. Simply select the 'Remove Watermark' option when downloading TikTok content."
    },
    {
      id: 6,
      question: "What should I do if a URL doesn't work?",
      answer: "Ensure the URL is correct and the content is publicly accessible. Try refreshing the page or copying the URL again. If issues persist, contact our support team."
    }
  ] : [
    {
      id: 1,
      question: "¿Qué formatos de video son compatibles para descarga?",
      answer: "Soportamos formatos de video MP4 y WebM con opciones de calidad desde 360p hasta 1080p. Para audio, ofrecemos formatos MP3 y M4A con bitrates de 128kbps a 320kbps."
    },
    {
      id: 2,
      question: "¿Puedo descargar contenido privado o restringido?",
      answer: "No, solo podemos descargar contenido disponible públicamente. Cuentas privadas, videos con restricción de edad o contenido detrás de muros de pago no pueden ser accedidos a través de nuestro servicio."
    },
    {
      id: 3,
      question: "¿Hay un límite de cuántos videos puedo descargar?",
      answer: "Implementamos políticas de uso justo para asegurar la calidad del servicio para todos los usuarios. El uso intensivo puede ser temporalmente limitado, pero el uso normal es sin restricciones."
    },
    {
      id: 4,
      question: "¿Por qué mi descarga está tardando tanto?",
      answer: "La velocidad de descarga depende de la duración del video, la calidad seleccionada y la carga del servidor. Videos de mayor calidad (1080p) tardan más en procesarse que opciones de menor calidad (360p)."
    },
    {
      id: 5,
      question: "¿Puedo quitar las marcas de agua de TikTok?",
      answer: "Sí, ofrecemos una opción de eliminación de marca de agua para videos de TikTok. Simplemente selecciona la opción 'Quitar Marca de Agua' al descargar contenido de TikTok."
    },
    {
      id: 6,
      question: "¿Qué debo hacer si una URL no funciona?",
      answer: "Asegúrate de que la URL sea correcta y el contenido sea accesible públicamente. Intenta refrescar la página o copiar la URL nuevamente. Si los problemas persisten, contacta a nuestro equipo de soporte."
    }
  ];

  const toggleFaq = (faqId) => {
    setExpandedFaq(expandedFaq === faqId ? null : faqId);
  };

  return (
    <div className="space-y-4">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold text-foreground mb-2">
          {language === 'en' ? 'Frequently Asked Questions' : 'Preguntas Frecuentes'}
        </h2>
        <p className="text-text-secondary">
          {language === 'en' ?'Find answers to common questions about our download service' :'Encuentra respuestas a preguntas comunes sobre nuestro servicio de descarga'
          }
        </p>
      </div>

      <div className="space-y-3">
        {faqData.map((faq) => (
          <div key={faq.id} className="border border-border rounded-lg overflow-hidden">
            <button
              onClick={() => toggleFaq(faq.id)}
              className="w-full p-4 text-left flex items-center justify-between hover:bg-muted/50 transition-colors"
            >
              <span className="font-medium text-foreground pr-4">
                {faq.question}
              </span>
              <Icon 
                name={expandedFaq === faq.id ? 'ChevronUp' : 'ChevronDown'} 
                size={20} 
                className="text-text-secondary flex-shrink-0" 
              />
            </button>
            
            {expandedFaq === faq.id && (
              <div className="px-4 pb-4">
                <div className="pt-2 border-t border-border">
                  <p className="text-sm text-text-secondary leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-8 p-4 bg-muted rounded-lg text-center">
        <Icon name="MessageCircle" size={24} className="text-primary mx-auto mb-2" />
        <p className="text-sm text-text-secondary mb-3">
          {language === 'en' ? "Still have questions? We're here to help!" :"¿Aún tienes preguntas? ¡Estamos aquí para ayudar!"
          }
        </p>
        <a 
          href="/contact-support" 
          className="text-primary hover:text-primary/80 text-sm font-medium transition-colors"
        >
          {language === 'en' ? 'Contact Support' : 'Contactar Soporte'}
        </a>
      </div>
    </div>
  );
};

export default FAQSection;