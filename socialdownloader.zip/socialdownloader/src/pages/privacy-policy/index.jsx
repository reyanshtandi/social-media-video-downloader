import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import Footer from '../../components/ui/Footer';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import PolicySection from './components/PolicySection';
import PrivacyDashboard from './components/PrivacyDashboard';
import GDPRRights from './components/GDPRRights';
import DataRetentionTimeline from './components/DataRetentionTimeline';
import CookiePolicy from './components/CookiePolicy';
import ComplianceIndicators from './components/ComplianceIndicators';

const PrivacyPolicyPage = () => {
  const [language, setLanguage] = useState('en');
  const [lastUpdated, setLastUpdated] = useState('');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setLanguage(savedLanguage);
    
    // Set last updated date
    const updateDate = new Date('2025-07-12');
    setLastUpdated(updateDate.toLocaleDateString(
      language === 'en' ? 'en-US' : 'es-ES',
      { year: 'numeric', month: 'long', day: 'numeric' }
    ));

    // Listen for language changes
    const handleLanguageChange = (event) => {
      setLanguage(event.detail.language);
    };

    window.addEventListener('languageChange', handleLanguageChange);
    return () => window.removeEventListener('languageChange', handleLanguageChange);
  }, [language]);

  const pageTitle = language === 'en' ? 'Privacy Policy' : 'Política de Privacidad';
  const pageDescription = language === 'en' ?'Comprehensive privacy policy and data protection information for SocialDownloader. Learn about our GDPR compliance, data collection practices, and your privacy rights.' :'Política de privacidad integral e información de protección de datos para SocialDownloader. Conoce sobre nuestro cumplimiento GDPR, prácticas de recopilación de datos y tus derechos de privacidad.';

  const handleContactSupport = () => {
    window.location.href = '/contact-support';
  };

  const policySections = [
    {
      id: 'overview',
      title: language === 'en' ? 'Privacy Overview' : 'Resumen de Privacidad',
      icon: 'Eye',
      content: language === 'en' 
        ? `SocialDownloader is committed to protecting your privacy and ensuring transparency in how we collect, use, and protect your personal information. This privacy policy explains our data practices in clear, understandable terms.\n\nWe believe in data minimization - we only collect information that is necessary to provide our services. Your privacy is not a commodity to be traded, and we will never sell your personal data to third parties.`
        : `SocialDownloader está comprometido a proteger tu privacidad y garantizar transparencia en cómo recopilamos, usamos y protegemos tu información personal. Esta política de privacidad explica nuestras prácticas de datos en términos claros y comprensibles.\n\nCreemos en la minimización de datos - solo recopilamos información que es necesaria para proporcionar nuestros servicios. Tu privacidad no es una mercancía para comercializar, y nunca venderemos tus datos personales a terceros.`
    },
    {
      id: 'collection',
      title: language === 'en' ? 'Information We Collect' : 'Información que Recopilamos',
      icon: 'Database',
      isExpandable: true,
      content: language === 'en'
        ? `We collect minimal information to provide our download services:\n\n• URLs you submit for downloading (processed temporarily and not stored)\n• Technical information like IP address, browser type, and device information\n• Usage analytics to improve service performance and reliability\n• Cookie data for essential functionality and user preferences\n• Error logs to diagnose and fix technical issues\n\nWe do not collect:\n• Personal identification information unless voluntarily provided\n• Content of downloaded files\n• Social media account credentials\n• Location data beyond general geographic region`
        : `Recopilamos información mínima para proporcionar nuestros servicios de descarga:\n\n• URLs que envías para descargar (procesadas temporalmente y no almacenadas)\n• Información técnica como dirección IP, tipo de navegador e información del dispositivo\n• Análisis de uso para mejorar el rendimiento y confiabilidad del servicio\n• Datos de cookies para funcionalidad esencial y preferencias del usuario\n• Registros de errores para diagnosticar y solucionar problemas técnicos\n\nNo recopilamos:\n• Información de identificación personal a menos que se proporcione voluntariamente\n• Contenido de archivos descargados\n• Credenciales de cuentas de redes sociales\n• Datos de ubicación más allá de la región geográfica general`
    },
    {
      id: 'usage',
      title: language === 'en' ? 'How We Use Your Information' : 'Cómo Usamos tu Información',
      icon: 'Settings',
      isExpandable: true,
      content: language === 'en'
        ? `Your information is used exclusively for:\n\n• Processing download requests and delivering content\n• Maintaining service security and preventing abuse\n• Improving service performance and user experience\n• Providing customer support when requested\n• Complying with legal obligations and protecting rights\n\nWe never use your information for:\n• Selling or sharing with third parties for profit\n• Creating detailed user profiles for advertising\n• Tracking across other websites or services\n• Sending unsolicited marketing communications`
        : `Tu información se usa exclusivamente para:\n\n• Procesar solicitudes de descarga y entregar contenido\n• Mantener la seguridad del servicio y prevenir abuso\n• Mejorar el rendimiento del servicio y la experiencia del usuario\n• Proporcionar soporte al cliente cuando se solicite\n• Cumplir con obligaciones legales y proteger derechos\n\nNunca usamos tu información para:\n• Vender o compartir con terceros con fines de lucro\n• Crear perfiles detallados de usuarios para publicidad\n• Rastrear a través de otros sitios web o servicios\n• Enviar comunicaciones de marketing no solicitadas`
    },
    {
      id: 'sharing',
      title: language === 'en' ? 'Information Sharing' : 'Compartir Información',
      icon: 'Share',
      isExpandable: true,
      content: language === 'en'
        ? `We maintain strict data sharing policies:\n\n• We do not sell personal information to any third parties\n• We do not share data for advertising or marketing purposes\n• Limited sharing only occurs when legally required or for essential service operations\n\nLimited sharing scenarios:\n• Legal compliance: When required by law, court order, or government request\n• Service providers: Trusted partners who help operate our service (under strict data protection agreements)\n• Safety and security: To protect against fraud, abuse, or security threats\n• Business transfers: In the unlikely event of a merger or acquisition (with user notification)`
        : `Mantenemos políticas estrictas de compartir datos:\n\n• No vendemos información personal a terceros\n• No compartimos datos para propósitos de publicidad o marketing\n• El compartir limitado solo ocurre cuando es legalmente requerido o para operaciones esenciales del servicio\n\nEscenarios de compartir limitado:\n• Cumplimiento legal: Cuando es requerido por ley, orden judicial o solicitud gubernamental\n• Proveedores de servicios: Socios de confianza que ayudan a operar nuestro servicio (bajo acuerdos estrictos de protección de datos)\n• Seguridad y protección: Para proteger contra fraude, abuso o amenazas de seguridad\n• Transferencias comerciales: En el caso improbable de una fusión o adquisición (con notificación al usuario)`
    },
    {
      id: 'security',
      title: language === 'en' ? 'Data Security' : 'Seguridad de Datos',
      icon: 'Lock',
      isExpandable: true,
      content: language === 'en'
        ? `We implement comprehensive security measures:\n\n• End-to-end encryption for all data transmission\n• Secure servers with regular security updates and monitoring\n• Access controls limiting data access to authorized personnel only\n• Regular security audits and penetration testing\n• Incident response procedures for potential security breaches\n\nTechnical safeguards:\n• TLS/SSL encryption for all communications\n• Encrypted data storage with industry-standard algorithms\n• Multi-factor authentication for administrative access\n• Regular automated backups with encryption\n• Network security monitoring and intrusion detection`
        : `Implementamos medidas de seguridad integrales:\n\n• Cifrado de extremo a extremo para toda transmisión de datos\n• Servidores seguros con actualizaciones de seguridad regulares y monitoreo\n• Controles de acceso que limitan el acceso a datos solo a personal autorizado\n• Auditorías de seguridad regulares y pruebas de penetración\n• Procedimientos de respuesta a incidentes para posibles violaciones de seguridad\n\nSalvaguardas técnicas:\n• Cifrado TLS/SSL para todas las comunicaciones\n• Almacenamiento de datos cifrado con algoritmos estándar de la industria\n• Autenticación multifactor para acceso administrativo\n• Copias de seguridad automatizadas regulares con cifrado\n• Monitoreo de seguridad de red y detección de intrusiones`
    },
    {
      id: 'international',
      title: language === 'en' ? 'International Transfers' : 'Transferencias Internacionales',
      icon: 'Globe',
      isExpandable: true,
      content: language === 'en'
        ? `When we transfer data internationally, we ensure adequate protection:\n\n• All transfers comply with applicable data protection laws\n• We use appropriate safeguards such as Standard Contractual Clauses\n• Data processing agreements ensure equivalent protection standards\n• Users are informed of any international data transfers\n\nSafeguards for international transfers:\n• Adequacy decisions from relevant data protection authorities\n• Binding corporate rules for intra-group transfers\n• Certification schemes and codes of conduct\n• Regular monitoring of transfer arrangements and protection levels`
        : `Cuando transferimos datos internacionalmente, aseguramos protección adecuada:\n\n• Todas las transferencias cumplen con las leyes de protección de datos aplicables\n• Usamos salvaguardas apropiadas como Cláusulas Contractuales Estándar\n• Los acuerdos de procesamiento de datos aseguran estándares de protección equivalentes\n• Los usuarios son informados de cualquier transferencia internacional de datos\n\nSalvaguardas para transferencias internacionales:\n• Decisiones de adecuación de autoridades relevantes de protección de datos\n• Reglas corporativas vinculantes para transferencias intra-grupo\n• Esquemas de certificación y códigos de conducta\n• Monitoreo regular de arreglos de transferencia y niveles de protección`
    }
  ];

  return (
    <>
      <Helmet>
        <title>{pageTitle} - SocialDownloader</title>
        <meta name="description" content={pageDescription} />
        <meta name="keywords" content={language === 'en' ?'privacy policy, data protection, GDPR, privacy rights, data security, social media downloader' :'política de privacidad, protección de datos, GDPR, derechos de privacidad, seguridad de datos, descargador de redes sociales'
        } />
        <meta property="og:title" content={`${pageTitle} - SocialDownloader`} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:title" content={`${pageTitle} - SocialDownloader`} />
        <meta name="twitter:description" content={pageDescription} />
        <link rel="canonical" href="https://socialdownloader.com/privacy-policy" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-16">
          {/* Hero Section */}
          <section className="bg-gradient-to-br from-primary/5 via-background to-secondary/5 py-16 lg:py-24">
            <div className="container mx-auto px-4 lg:px-6">
              <div className="max-w-4xl mx-auto text-center">
                <div className="flex items-center justify-center space-x-3 mb-6">
                  <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center">
                    <Icon name="Shield" size={32} className="text-primary" />
                  </div>
                </div>
                
                <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
                  {pageTitle}
                </h1>
                
                <p className="text-xl text-text-secondary mb-8 leading-relaxed">
                  {language === 'en' ?'Your privacy matters to us. Learn how we protect your data and respect your rights with full transparency and GDPR compliance.' :'Tu privacidad nos importa. Aprende cómo protegemos tus datos y respetamos tus derechos con total transparencia y cumplimiento GDPR.'
                  }
                </p>
                
                <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
                  <div className="flex items-center space-x-2 text-sm text-text-secondary">
                    <Icon name="Calendar" size={16} />
                    <span>
                      {language === 'en' ? 'Last updated:' : 'Última actualización:'} {lastUpdated}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-success">
                    <Icon name="Shield" size={16} />
                    <span>
                      {language === 'en' ? 'GDPR Compliant' : 'Conforme con GDPR'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Quick Actions */}
          <section className="py-8 border-b border-border">
            <div className="container mx-auto px-4 lg:px-6">
              <div className="max-w-4xl mx-auto">
                <div className="flex flex-wrap items-center justify-center gap-4">
                  <Button variant="outline" size="sm">
                    <Icon name="Download" size={16} />
                    <span className="ml-2">
                      {language === 'en' ? 'Download PDF' : 'Descargar PDF'}
                    </span>
                  </Button>
                  <Button variant="outline" size="sm">
                    <Icon name="Printer" size={16} />
                    <span className="ml-2">
                      {language === 'en' ? 'Print Policy' : 'Imprimir Política'}
                    </span>
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleContactSupport}>
                    <Icon name="MessageCircle" size={16} />
                    <span className="ml-2">
                      {language === 'en' ? 'Contact Support' : 'Contactar Soporte'}
                    </span>
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* Main Content */}
          <section className="py-16">
            <div className="container mx-auto px-4 lg:px-6">
              <div className="max-w-4xl mx-auto">
                {/* Privacy Dashboard */}
                <div className="mb-12">
                  <PrivacyDashboard />
                </div>

                {/* Policy Sections */}
                <div className="mb-12">
                  {policySections.map((section) => (
                    <PolicySection
                      key={section.id}
                      title={section.title}
                      content={section.content}
                      icon={section.icon}
                      isExpandable={section.isExpandable}
                      defaultExpanded={false}
                    />
                  ))}
                </div>

                {/* GDPR Rights */}
                <div className="mb-12">
                  <GDPRRights />
                </div>

                {/* Data Retention Timeline */}
                <div className="mb-12">
                  <DataRetentionTimeline />
                </div>

                {/* Cookie Policy */}
                <div className="mb-12">
                  <CookiePolicy />
                </div>

                {/* Compliance Indicators */}
                <div className="mb-12">
                  <ComplianceIndicators />
                </div>

                {/* Contact Information */}
                <div className="bg-surface border border-border rounded-lg p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Icon name="MessageCircle" size={20} className="text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-foreground">
                        {language === 'en' ? 'Questions About Privacy?' : '¿Preguntas sobre Privacidad?'}
                      </h3>
                      <p className="text-sm text-text-secondary">
                        {language === 'en' ?'Contact our Data Protection Officer for any privacy-related inquiries' :'Contacta a nuestro Oficial de Protección de Datos para cualquier consulta relacionada con privacidad'
                        }
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-sm">
                        <Icon name="Mail" size={14} className="text-text-secondary" />
                        <span className="text-text-secondary">
                          {language === 'en' ? 'Email:' : 'Correo:'}
                        </span>
                        <span className="text-foreground font-medium">privacy@socialdownloader.com</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <Icon name="MapPin" size={14} className="text-text-secondary" />
                        <span className="text-text-secondary">
                          {language === 'en' ? 'Address:' : 'Dirección:'}
                        </span>
                        <span className="text-foreground font-medium">
                          {language === 'en' ? 'Data Protection Office, SocialDownloader Inc.' : 'Oficina de Protección de Datos, SocialDownloader Inc.'}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center justify-end">
                      <Button variant="default" onClick={handleContactSupport}>
                        <Icon name="Send" size={16} />
                        <span className="ml-2">
                          {language === 'en' ? 'Contact Us' : 'Contáctanos'}
                        </span>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default PrivacyPolicyPage;