import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const DataRetentionTimeline = () => {
  const [language, setLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setLanguage(savedLanguage);
  }, []);

  const retentionPeriods = [
    {
      id: 'session',
      dataType: language === 'en' ? 'Session Data' : 'Datos de Sesión',
      description: language === 'en' ?'Download URLs, temporary files, and session preferences' :'URLs de descarga, archivos temporales y preferencias de sesión',
      duration: language === 'en' ? 'Session End' : 'Fin de Sesión',
      durationDays: 0,
      icon: 'Clock',
      color: 'text-success'
    },
    {
      id: 'analytics',
      dataType: language === 'en' ? 'Analytics Data' : 'Datos de Análisis',
      description: language === 'en' ?'Usage patterns, performance metrics, and error logs' :'Patrones de uso, métricas de rendimiento y registros de errores',
      duration: language === 'en' ? '30 Days' : '30 Días',
      durationDays: 30,
      icon: 'BarChart3',
      color: 'text-primary'
    },
    {
      id: 'preferences',
      dataType: language === 'en' ? 'User Preferences' : 'Preferencias de Usuario',
      description: language === 'en' ?'Theme settings, language preferences, and privacy choices' :'Configuración de tema, preferencias de idioma y opciones de privacidad',
      duration: language === 'en' ? '1 Year' : '1 Año',
      durationDays: 365,
      icon: 'Settings',
      color: 'text-warning'
    },
    {
      id: 'support',
      dataType: language === 'en' ? 'Support Data' : 'Datos de Soporte',
      description: language === 'en' ?'Contact forms, support tickets, and communication records' :'Formularios de contacto, tickets de soporte y registros de comunicación',
      duration: language === 'en' ? '3 Years' : '3 Años',
      durationDays: 1095,
      icon: 'MessageCircle',
      color: 'text-destructive'
    }
  ];

  const getProgressPercentage = (days) => {
    if (days === 0) return 100;
    const maxDays = Math.max(...retentionPeriods.map(p => p.durationDays));
    return (days / maxDays) * 100;
  };

  return (
    <div className="bg-surface border border-border rounded-lg p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-warning/10 rounded-lg flex items-center justify-center">
          <Icon name="Calendar" size={20} className="text-warning" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">
            {language === 'en' ? 'Data Retention Timeline' : 'Cronología de Retención de Datos'}
          </h3>
          <p className="text-sm text-text-secondary">
            {language === 'en' ?'How long we keep different types of data' :'Cuánto tiempo conservamos diferentes tipos de datos'
            }
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {retentionPeriods.map((period, index) => (
          <div key={period.id} className="relative">
            {/* Timeline connector */}
            {index < retentionPeriods.length - 1 && (
              <div className="absolute left-4 top-12 w-0.5 h-16 bg-border"></div>
            )}
            
            <div className="flex items-start space-x-4">
              {/* Timeline dot */}
              <div className={`w-8 h-8 rounded-full border-2 border-current ${period.color} bg-background flex items-center justify-center flex-shrink-0`}>
                <Icon name={period.icon} size={14} className={period.color} />
              </div>
              
              {/* Content */}
              <div className="flex-1 bg-background border border-border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h4 className="font-medium text-foreground mb-1">{period.dataType}</h4>
                    <p className="text-sm text-text-secondary">{period.description}</p>
                  </div>
                  <div className="text-right ml-4">
                    <span className={`text-sm font-medium ${period.color}`}>
                      {period.duration}
                    </span>
                  </div>
                </div>
                
                {/* Progress bar */}
                <div className="w-full bg-muted rounded-full h-2 mb-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${
                      period.color === 'text-success' ? 'bg-success' :
                      period.color === 'text-primary' ? 'bg-primary' :
                      period.color === 'text-warning'? 'bg-warning' : 'bg-destructive'
                    }`}
                    style={{ width: `${getProgressPercentage(period.durationDays)}%` }}
                  ></div>
                </div>
                
                <div className="flex items-center justify-between text-xs text-text-secondary">
                  <span>
                    {language === 'en' ? 'Auto-deletion after' : 'Auto-eliminación después de'} {period.duration.toLowerCase()}
                  </span>
                  <div className="flex items-center space-x-1">
                    <Icon name="Trash2" size={10} />
                    <span>
                      {language === 'en' ? 'Automatic' : 'Automático'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-primary/5 border border-primary/20 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={16} className="text-primary flex-shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="text-primary font-medium mb-1">
              {language === 'en' ? 'Retention Policy' : 'Política de Retención'}
            </p>
            <p className="text-text-secondary">
              {language === 'en' ?'Data is automatically deleted according to the timelines above. You can request earlier deletion through your GDPR rights or by contacting our support team.' :'Los datos se eliminan automáticamente según los plazos anteriores. Puedes solicitar una eliminación anterior a través de tus derechos GDPR o contactando a nuestro equipo de soporte.'
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataRetentionTimeline;