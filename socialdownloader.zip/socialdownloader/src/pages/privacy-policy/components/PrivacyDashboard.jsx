import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PrivacyDashboard = () => {
  const [language, setLanguage] = useState('en');
  const [preferences, setPreferences] = useState({
    analytics: true,
    marketing: false,
    functional: true,
    performance: true
  });

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setLanguage(savedLanguage);
    
    const savedPreferences = localStorage.getItem('privacyPreferences');
    if (savedPreferences) {
      setPreferences(JSON.parse(savedPreferences));
    }
  }, []);

  const handlePreferenceChange = (key) => {
    const newPreferences = {
      ...preferences,
      [key]: !preferences[key]
    };
    setPreferences(newPreferences);
    localStorage.setItem('privacyPreferences', JSON.stringify(newPreferences));
  };

  const dataTypes = [
    {
      id: 'analytics',
      name: language === 'en' ? 'Analytics Data' : 'Datos de Análisis',
      description: language === 'en' ?'Usage patterns and performance metrics to improve our service' :'Patrones de uso y métricas de rendimiento para mejorar nuestro servicio',
      icon: 'BarChart3',
      required: false
    },
    {
      id: 'marketing',
      name: language === 'en' ? 'Marketing Data' : 'Datos de Marketing',
      description: language === 'en' ?'Information used for personalized content and advertisements' :'Información utilizada para contenido personalizado y anuncios',
      icon: 'Target',
      required: false
    },
    {
      id: 'functional',
      name: language === 'en' ? 'Functional Data' : 'Datos Funcionales',
      description: language === 'en' ?'Essential data required for core application functionality' :'Datos esenciales requeridos para la funcionalidad principal de la aplicación',
      icon: 'Settings',
      required: true
    },
    {
      id: 'performance',
      name: language === 'en' ? 'Performance Data' : 'Datos de Rendimiento',
      description: language === 'en' ?'Technical data to monitor and optimize application performance' :'Datos técnicos para monitorear y optimizar el rendimiento de la aplicación',
      icon: 'Zap',
      required: true
    }
  ];

  return (
    <div className="bg-surface border border-border rounded-lg p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
          <Icon name="Shield" size={20} className="text-primary" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">
            {language === 'en' ? 'Privacy Dashboard' : 'Panel de Privacidad'}
          </h3>
          <p className="text-sm text-text-secondary">
            {language === 'en' ?'Manage your data collection preferences' :'Gestiona tus preferencias de recopilación de datos'
            }
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {dataTypes.map((dataType) => (
          <div 
            key={dataType.id}
            className="flex items-start justify-between p-4 bg-background rounded-lg border border-border"
          >
            <div className="flex items-start space-x-3 flex-1">
              <div className="w-8 h-8 bg-muted rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                <Icon name={dataType.icon} size={16} className="text-text-secondary" />
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <h4 className="font-medium text-foreground">{dataType.name}</h4>
                  {dataType.required && (
                    <span className="text-xs bg-warning/10 text-warning px-2 py-1 rounded-full">
                      {language === 'en' ? 'Required' : 'Requerido'}
                    </span>
                  )}
                </div>
                <p className="text-sm text-text-secondary">{dataType.description}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 ml-4">
              <button
                onClick={() => !dataType.required && handlePreferenceChange(dataType.id)}
                disabled={dataType.required}
                className={`
                  relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                  ${preferences[dataType.id] 
                    ? 'bg-primary' :'bg-border'
                  }
                  ${dataType.required ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
                `}
              >
                <span
                  className={`
                    inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                    ${preferences[dataType.id] ? 'translate-x-6' : 'translate-x-1'}
                  `}
                />
              </button>
              <span className="text-xs text-text-secondary font-medium">
                {preferences[dataType.id] 
                  ? (language === 'en' ? 'ON' : 'ACTIVADO')
                  : (language === 'en' ? 'OFF' : 'DESACTIVADO')
                }
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-4 border-t border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-sm text-text-secondary">
            <Icon name="Clock" size={14} />
            <span>
              {language === 'en' ?'Last updated: July 12, 2025' :'Última actualización: 12 de julio, 2025'
              }
            </span>
          </div>
          <Button variant="outline" size="sm">
            <Icon name="Download" size={14} />
            <span className="ml-2">
              {language === 'en' ? 'Export Data' : 'Exportar Datos'}
            </span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PrivacyDashboard;