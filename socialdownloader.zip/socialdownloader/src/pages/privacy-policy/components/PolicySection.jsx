import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const PolicySection = ({ 
  title, 
  content, 
  isExpandable = false, 
  defaultExpanded = false,
  icon = "FileText",
  children 
}) => {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);

  const toggleExpanded = () => {
    if (isExpandable) {
      setIsExpanded(!isExpanded);
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 mb-6 transition-smooth hover:shadow-sm">
      <div 
        className={`flex items-start justify-between ${isExpandable ? 'cursor-pointer' : ''}`}
        onClick={toggleExpanded}
      >
        <div className="flex items-start space-x-3 flex-1">
          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
            <Icon name={icon} size={16} className="text-primary" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-foreground mb-2">
              {title}
            </h3>
            {!isExpandable && (
              <div className="text-text-secondary leading-relaxed">
                {content}
                {children}
              </div>
            )}
          </div>
        </div>
        {isExpandable && (
          <Icon 
            name={isExpanded ? "ChevronUp" : "ChevronDown"} 
            size={20} 
            className="text-text-secondary mt-1 flex-shrink-0 ml-2" 
          />
        )}
      </div>
      
      {isExpandable && isExpanded && (
        <div className="mt-4 pl-11 text-text-secondary leading-relaxed">
          {content}
          {children}
        </div>
      )}
    </div>
  );
};

export default PolicySection;