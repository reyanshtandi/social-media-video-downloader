import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const ComplianceIndicators = () => {
  const [language, setLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setLanguage(savedLanguage);
  }, []);

  const certifications = [
    {
      id: 'gdpr',
      name: 'GDPR',
      fullName: language === 'en' ?'General Data Protection Regulation' :'Reglamento General de Protección de Datos',
      status: 'compliant',
      description: language === 'en' ?'Fully compliant with EU data protection regulations' :'Totalmente conforme con las regulaciones de protección de datos de la UE',
      icon: 'Shield',
      lastAudit: '2025-06-15',
      nextAudit: '2025-12-15'
    },
    {
      id: 'ccpa',
      name: 'CCPA',
      fullName: language === 'en' ?'California Consumer Privacy Act' :'Ley de Privacidad del Consumidor de California',
      status: 'compliant',
      description: language === 'en' ?'Compliant with California privacy requirements' :'Conforme con los requisitos de privacidad de California',
      icon: 'FileCheck',
      lastAudit: '2025-05-20',
      nextAudit: '2025-11-20'
    },
    {
      id: 'iso27001',
      name: 'ISO 27001',
      fullName: language === 'en' ?'Information Security Management' :'Gestión de Seguridad de la Información',
      status: 'certified',
      description: language === 'en' ?'Certified information security management system' :'Sistema de gestión de seguridad de la información certificado',
      icon: 'Lock',
      lastAudit: '2025-04-10',
      nextAudit: '2026-04-10'
    },
    {
      id: 'soc2',
      name: 'SOC 2',
      fullName: language === 'en' ?'Service Organization Control 2' :'Control de Organización de Servicios 2',
      status: 'in-progress',
      description: language === 'en' ?'Security and availability controls audit in progress' :'Auditoría de controles de seguridad y disponibilidad en progreso',
      icon: 'Clock',
      lastAudit: null,
      nextAudit: '2025-09-30'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'compliant': case'certified':
        return 'text-success';
      case 'in-progress':
        return 'text-warning';
      case 'expired':
        return 'text-destructive';
      default:
        return 'text-text-secondary';
    }
  };

  const getStatusBg = (status) => {
    switch (status) {
      case 'compliant': case'certified':
        return 'bg-success/10 border-success/20';
      case 'in-progress':
        return 'bg-warning/10 border-warning/20';
      case 'expired':
        return 'bg-destructive/10 border-destructive/20';
      default:
        return 'bg-muted/10 border-border';
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'compliant':
        return language === 'en' ? 'Compliant' : 'Conforme';
      case 'certified':
        return language === 'en' ? 'Certified' : 'Certificado';
      case 'in-progress':
        return language === 'en' ? 'In Progress' : 'En Progreso';
      case 'expired':
        return language === 'en' ? 'Expired' : 'Expirado';
      default:
        return language === 'en' ? 'Unknown' : 'Desconocido';
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return language === 'en' ? date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
      : date.toLocaleDateString('es-ES', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  return (
    <div className="bg-surface border border-border rounded-lg p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
          <Icon name="Award" size={20} className="text-success" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">
            {language === 'en' ? 'Compliance & Certifications' : 'Cumplimiento y Certificaciones'}
          </h3>
          <p className="text-sm text-text-secondary">
            {language === 'en' ?'Our commitment to data protection and security standards' :'Nuestro compromiso con la protección de datos y estándares de seguridad'
            }
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {certifications.map((cert) => (
          <div 
            key={cert.id}
            className={`border rounded-lg p-4 ${getStatusBg(cert.status)}`}
          >
            <div className="flex items-start space-x-3 mb-3">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${getStatusBg(cert.status)}`}>
                <Icon name={cert.icon} size={16} className={getStatusColor(cert.status)} />
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <h4 className="font-medium text-foreground">{cert.name}</h4>
                  <span className={`text-xs px-2 py-1 rounded-full ${getStatusBg(cert.status)} ${getStatusColor(cert.status)}`}>
                    {getStatusLabel(cert.status)}
                  </span>
                </div>
                <p className="text-xs text-text-secondary mb-1">{cert.fullName}</p>
                <p className="text-sm text-text-secondary">{cert.description}</p>
              </div>
            </div>
            
            <div className="space-y-2 text-xs text-text-secondary">
              {cert.lastAudit && (
                <div className="flex items-center justify-between">
                  <span>{language === 'en' ? 'Last Audit:' : 'Última Auditoría:'}</span>
                  <span className="font-medium">{formatDate(cert.lastAudit)}</span>
                </div>
              )}
              <div className="flex items-center justify-between">
                <span>{language === 'en' ? 'Next Review:' : 'Próxima Revisión:'}</span>
                <span className="font-medium">{formatDate(cert.nextAudit)}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-background border border-border rounded-lg p-4 text-center">
          <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center mx-auto mb-3">
            <Icon name="Shield" size={24} className="text-success" />
          </div>
          <h4 className="font-medium text-foreground mb-1">
            {language === 'en' ? 'Data Protection' : 'Protección de Datos'}
          </h4>
          <p className="text-sm text-text-secondary">
            {language === 'en' ? 'End-to-end encryption' : 'Cifrado de extremo a extremo'}
          </p>
        </div>

        <div className="bg-background border border-border rounded-lg p-4 text-center">
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
            <Icon name="Eye" size={24} className="text-primary" />
          </div>
          <h4 className="font-medium text-foreground mb-1">
            {language === 'en' ? 'Transparency' : 'Transparencia'}
          </h4>
          <p className="text-sm text-text-secondary">
            {language === 'en' ? 'Clear data practices' : 'Prácticas de datos claras'}
          </p>
        </div>

        <div className="bg-background border border-border rounded-lg p-4 text-center">
          <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center mx-auto mb-3">
            <Icon name="Users" size={24} className="text-warning" />
          </div>
          <h4 className="font-medium text-foreground mb-1">
            {language === 'en' ? 'User Control' : 'Control del Usuario'}
          </h4>
          <p className="text-sm text-text-secondary">
            {language === 'en' ? 'Full data ownership' : 'Propiedad completa de datos'}
          </p>
        </div>
      </div>

      <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={16} className="text-primary flex-shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="text-primary font-medium mb-1">
              {language === 'en' ? 'Continuous Monitoring' : 'Monitoreo Continuo'}
            </p>
            <p className="text-text-secondary">
              {language === 'en' ?'Our compliance status is continuously monitored and updated. All certifications are verified by independent third-party auditors.' :'Nuestro estado de cumplimiento se monitorea y actualiza continuamente. Todas las certificaciones son verificadas por auditores independientes de terceros.'
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComplianceIndicators;