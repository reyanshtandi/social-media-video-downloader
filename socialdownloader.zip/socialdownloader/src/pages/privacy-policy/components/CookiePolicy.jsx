import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CookiePolicy = () => {
  const [language, setLanguage] = useState('en');
  const [cookieConsent, setCookieConsent] = useState({
    essential: true,
    analytics: false,
    marketing: false,
    preferences: true
  });

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setLanguage(savedLanguage);
    
    const savedConsent = localStorage.getItem('cookieConsent');
    if (savedConsent) {
      setCookieConsent(JSON.parse(savedConsent));
    }
  }, []);

  const handleConsentChange = (type) => {
    if (type === 'essential') return; // Essential cookies cannot be disabled
    
    const newConsent = {
      ...cookieConsent,
      [type]: !cookieConsent[type]
    };
    setCookieConsent(newConsent);
    localStorage.setItem('cookieConsent', JSON.stringify(newConsent));
  };

  const cookieTypes = [
    {
      id: 'essential',
      name: language === 'en' ? 'Essential Cookies' : 'Cookies Esenciales',
      description: language === 'en' ?'Required for basic website functionality and security. Cannot be disabled.' :'Requeridas para la funcionalidad básica del sitio web y seguridad. No se pueden desactivar.',
      examples: language === 'en' ?'Session management, security tokens, language preferences' :'Gestión de sesiones, tokens de seguridad, preferencias de idioma',
      icon: 'Shield',
      required: true,
      duration: language === 'en' ? 'Session' : 'Sesión'
    },
    {
      id: 'analytics',
      name: language === 'en' ? 'Analytics Cookies' : 'Cookies de Análisis',
      description: language === 'en' ?'Help us understand how visitors interact with our website.' :'Nos ayudan a entender cómo los visitantes interactúan con nuestro sitio web.',
      examples: language === 'en' ?'Page views, user behavior, performance metrics' :'Vistas de página, comportamiento del usuario, métricas de rendimiento',
      icon: 'BarChart3',
      required: false,
      duration: language === 'en' ? '30 days' : '30 días'
    },
    {
      id: 'marketing',
      name: language === 'en' ? 'Marketing Cookies' : 'Cookies de Marketing',
      description: language === 'en' ?'Used to deliver personalized advertisements and track campaign effectiveness.' :'Utilizadas para entregar anuncios personalizados y rastrear la efectividad de campañas.',
      examples: language === 'en' ?'Ad targeting, conversion tracking, social media integration' :'Segmentación de anuncios, seguimiento de conversiones, integración de redes sociales',
      icon: 'Target',
      required: false,
      duration: language === 'en' ? '90 days' : '90 días'
    },
    {
      id: 'preferences',
      name: language === 'en' ? 'Preference Cookies' : 'Cookies de Preferencias',
      description: language === 'en' ?'Remember your settings and preferences for a better experience.' :'Recuerdan tus configuraciones y preferencias para una mejor experiencia.',
      examples: language === 'en' ?'Theme selection, language choice, layout preferences' :'Selección de tema, elección de idioma, preferencias de diseño',
      icon: 'Settings',
      required: false,
      duration: language === 'en' ? '1 year' : '1 año'
    }
  ];

  const acceptAllCookies = () => {
    const allAccepted = {
      essential: true,
      analytics: true,
      marketing: true,
      preferences: true
    };
    setCookieConsent(allAccepted);
    localStorage.setItem('cookieConsent', JSON.stringify(allAccepted));
  };

  const rejectOptionalCookies = () => {
    const essentialOnly = {
      essential: true,
      analytics: false,
      marketing: false,
      preferences: false
    };
    setCookieConsent(essentialOnly);
    localStorage.setItem('cookieConsent', JSON.stringify(essentialOnly));
  };

  return (
    <div className="bg-surface border border-border rounded-lg p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-warning/10 rounded-lg flex items-center justify-center">
          <Icon name="Cookie" size={20} className="text-warning" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">
            {language === 'en' ? 'Cookie Policy' : 'Política de Cookies'}
          </h3>
          <p className="text-sm text-text-secondary">
            {language === 'en' ?'Manage your cookie preferences and consent' :'Gestiona tus preferencias y consentimiento de cookies'
            }
          </p>
        </div>
      </div>

      <div className="space-y-4 mb-6">
        {cookieTypes.map((cookie) => (
          <div 
            key={cookie.id}
            className="bg-background border border-border rounded-lg p-4"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start space-x-3 flex-1">
                <div className="w-8 h-8 bg-muted rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                  <Icon name={cookie.icon} size={16} className="text-text-secondary" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className="font-medium text-foreground">{cookie.name}</h4>
                    {cookie.required && (
                      <span className="text-xs bg-success/10 text-success px-2 py-1 rounded-full">
                        {language === 'en' ? 'Required' : 'Requerido'}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-text-secondary mb-2">{cookie.description}</p>
                  <div className="text-xs text-text-secondary">
                    <p className="mb-1">
                      <span className="font-medium">
                        {language === 'en' ? 'Examples:' : 'Ejemplos:'} 
                      </span> {cookie.examples}
                    </p>
                    <p>
                      <span className="font-medium">
                        {language === 'en' ? 'Duration:' : 'Duración:'} 
                      </span> {cookie.duration}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-2 ml-4">
                <button
                  onClick={() => handleConsentChange(cookie.id)}
                  disabled={cookie.required}
                  className={`
                    relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                    ${cookieConsent[cookie.id] 
                      ? 'bg-primary' :'bg-border'
                    }
                    ${cookie.required ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
                  `}
                >
                  <span
                    className={`
                      inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                      ${cookieConsent[cookie.id] ? 'translate-x-6' : 'translate-x-1'}
                    `}
                  />
                </button>
                <span className="text-xs text-text-secondary font-medium">
                  {cookieConsent[cookie.id] 
                    ? (language === 'en' ? 'ON' : 'ACTIVADO')
                    : (language === 'en' ? 'OFF' : 'DESACTIVADO')
                  }
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-border">
        <Button 
          variant="default" 
          onClick={acceptAllCookies}
          className="flex-1"
        >
          <Icon name="Check" size={16} />
          <span className="ml-2">
            {language === 'en' ? 'Accept All Cookies' : 'Aceptar Todas las Cookies'}
          </span>
        </Button>
        <Button 
          variant="outline" 
          onClick={rejectOptionalCookies}
          className="flex-1"
        >
          <Icon name="X" size={16} />
          <span className="ml-2">
            {language === 'en' ? 'Essential Only' : 'Solo Esenciales'}
          </span>
        </Button>
      </div>

      <div className="mt-4 p-3 bg-muted/50 rounded-lg">
        <div className="flex items-center space-x-2 text-xs text-text-secondary">
          <Icon name="Info" size={12} />
          <span>
            {language === 'en' ?'Changes take effect immediately. You can modify these settings at any time.' :'Los cambios surten efecto inmediatamente. Puedes modificar estas configuraciones en cualquier momento.'
            }
          </span>
        </div>
      </div>
    </div>
  );
};

export default CookiePolicy;