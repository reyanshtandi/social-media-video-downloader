import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const GDPRRights = () => {
  const [language, setLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setLanguage(savedLanguage);
  }, []);

  const handleRightAction = (rightType) => {
    // Mock action - in real app would navigate to request form
    console.log(`Requesting ${rightType} action`);
  };

  const rights = [
    {
      id: 'access',
      title: language === 'en' ? 'Right to Access' : 'Derecho de Acceso',
      description: language === 'en' ?'Request a copy of all personal data we hold about you' :'Solicitar una copia de todos los datos personales que tenemos sobre ti',
      icon: 'Eye',
      actionLabel: language === 'en' ? 'Request Data' : 'Solicitar Datos',
      timeframe: language === 'en' ? '30 days' : '30 días'
    },
    {
      id: 'rectification',
      title: language === 'en' ? 'Right to Rectification' : 'Derecho de Rectificación',
      description: language === 'en' ?'Correct or update any inaccurate personal information' :'Corregir o actualizar cualquier información personal inexacta',
      icon: 'Edit',
      actionLabel: language === 'en' ? 'Update Data' : 'Actualizar Datos',
      timeframe: language === 'en' ? '30 days' : '30 días'
    },
    {
      id: 'erasure',
      title: language === 'en' ? 'Right to Erasure' : 'Derecho al Olvido',
      description: language === 'en' ?'Request deletion of your personal data from our systems' :'Solicitar la eliminación de tus datos personales de nuestros sistemas',
      icon: 'Trash2',
      actionLabel: language === 'en' ? 'Delete Data' : 'Eliminar Datos',
      timeframe: language === 'en' ? '30 days' : '30 días'
    },
    {
      id: 'portability',
      title: language === 'en' ? 'Right to Data Portability' : 'Derecho a la Portabilidad',
      description: language === 'en' ?'Receive your data in a structured, machine-readable format' :'Recibir tus datos en un formato estructurado y legible por máquina',
      icon: 'Download',
      actionLabel: language === 'en' ? 'Export Data' : 'Exportar Datos',
      timeframe: language === 'en' ? '30 days' : '30 días'
    },
    {
      id: 'restriction',
      title: language === 'en' ? 'Right to Restriction' : 'Derecho a la Limitación',
      description: language === 'en' ?'Limit how we process your personal data' :'Limitar cómo procesamos tus datos personales',
      icon: 'Pause',
      actionLabel: language === 'en' ? 'Restrict Processing' : 'Restringir Procesamiento',
      timeframe: language === 'en' ? '30 days' : '30 días'
    },
    {
      id: 'objection',
      title: language === 'en' ? 'Right to Object' : 'Derecho de Oposición',
      description: language === 'en' ?'Object to processing of your data for specific purposes' :'Oponerse al procesamiento de tus datos para propósitos específicos',
      icon: 'X',
      actionLabel: language === 'en' ? 'Object to Processing' : 'Oponerse al Procesamiento',
      timeframe: language === 'en' ? '30 days' : '30 días'
    }
  ];

  return (
    <div className="bg-surface border border-border rounded-lg p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
          <Icon name="Shield" size={20} className="text-success" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">
            {language === 'en' ? 'Your GDPR Rights' : 'Tus Derechos GDPR'}
          </h3>
          <p className="text-sm text-text-secondary">
            {language === 'en' ?'Exercise your data protection rights under GDPR' :'Ejerce tus derechos de protección de datos bajo GDPR'
            }
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {rights.map((right) => (
          <div 
            key={right.id}
            className="bg-background border border-border rounded-lg p-4 hover:shadow-sm transition-smooth"
          >
            <div className="flex items-start space-x-3 mb-3">
              <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Icon name={right.icon} size={16} className="text-primary" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-foreground mb-1">{right.title}</h4>
                <p className="text-sm text-text-secondary leading-relaxed">
                  {right.description}
                </p>
              </div>
            </div>
            
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center space-x-2 text-xs text-text-secondary">
                <Icon name="Clock" size={12} />
                <span>
                  {language === 'en' ? 'Response time:' : 'Tiempo de respuesta:'} {right.timeframe}
                </span>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => handleRightAction(right.id)}
              >
                {right.actionLabel}
              </Button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-warning/5 border border-warning/20 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={16} className="text-warning flex-shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="text-warning font-medium mb-1">
              {language === 'en' ? 'Important Notice' : 'Aviso Importante'}
            </p>
            <p className="text-text-secondary">
              {language === 'en' ?'Some rights may not apply in certain circumstances. We will inform you if any limitations apply to your request and provide reasons for our decision.' :'Algunos derechos pueden no aplicar en ciertas circunstancias. Te informaremos si alguna limitación aplica a tu solicitud y proporcionaremos razones para nuestra decisión.'
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GDPRRights;