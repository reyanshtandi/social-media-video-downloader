import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import Footer from '../../components/ui/Footer';
import TableOfContents from './components/TableOfContents';
import TermsSection from './components/TermsSection';
import SearchBar from './components/SearchBar';
import ProgressIndicator from './components/ProgressIndicator';
import DocumentActions from './components/DocumentActions';
import LegalDisclaimer from './components/LegalDisclaimer';

const TermsOfService = () => {
  const [language, setLanguage] = useState('en');
  const [activeSection, setActiveSection] = useState('acceptance');
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredSections, setFilteredSections] = useState([]);

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setLanguage(savedLanguage);

    const handleLanguageChange = (event) => {
      setLanguage(event.detail.language);
    };

    window.addEventListener('languageChange', handleLanguageChange);
    return () => window.removeEventListener('languageChange', handleLanguageChange);
  }, []);

  const pageData = {
    en: {
      title: "Terms of Service",
      subtitle: "Legal Agreement and Usage Policies",
      description: "Please read these terms carefully before using SocialDownloader services."
    },
    es: {
      title: "Términos de Servicio",
      subtitle: "Acuerdo Legal y Políticas de Uso",
      description: "Por favor lea estos términos cuidadosamente antes de usar los servicios de SocialDownloader."
    }
  };

  const sectionsData = {
    en: [
      {
        id: 'acceptance',
        title: '1. Acceptance of Terms',
        icon: 'FileCheck',
        collapsible: false,
        content: [
          {
            type: 'paragraph',
            text: 'By accessing and using SocialDownloader ("the Service"), you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.'
          },
          {
            type: 'info',
            text: 'These terms apply to all visitors, users, and others who access or use the service.'
          },
          {
            type: 'list',
            items: [
              'You must be at least 13 years old to use this service',
              'You must provide accurate and complete information when creating an account',
              'You are responsible for maintaining the confidentiality of your account'
            ]
          }
        ]
      },
      {
        id: 'service-description',
        title: '2. Service Description',
        icon: 'Globe',
        collapsible: true,
        content: [
          {
            type: 'paragraph',
            text: 'SocialDownloader is a web-based platform that allows users to download publicly available content from various social media platforms including YouTube, Instagram, Facebook, Twitter/X, TikTok, SoundCloud, Vimeo, and LinkedIn.'
          },
          {
            type: 'highlight',
            text: 'Our service only works with publicly available content and respects platform terms of service.'
          }
        ],
        subsections: [
          {
            title: 'Supported Platforms',
            content: 'We currently support downloading from YouTube, Instagram, Facebook, Twitter/X, TikTok, SoundCloud, Vimeo, and LinkedIn. Platform availability may change without notice.'
          },
          {
            title: 'Content Types',
            content: 'Users can download videos in various formats (MP4, WebM) and qualities (360p, 720p, 1080p), as well as audio files in different formats (MP3, M4A) and bitrates.'
          }
        ]
      },
      {
        id: 'acceptable-use',
        title: '3. Acceptable Use Policy',
        icon: 'Shield',
        collapsible: true,
        content: [
          {
            type: 'paragraph',
            text: 'You agree to use SocialDownloader only for lawful purposes and in accordance with these Terms of Service. You are prohibited from using the service:'
          },
          {
            type: 'list',
            items: [
              'To download copyrighted content without proper authorization',
              'To violate any applicable local, state, national, or international law',
              'To transmit or procure the sending of any advertising or promotional material',
              'To impersonate or attempt to impersonate the company, employees, or other users',
              'To engage in any other conduct that restricts or inhibits use of the service'
            ]
          },
          {
            type: 'highlight',
            text: 'Users are solely responsible for ensuring they have the right to download and use any content.'
          }
        ]
      },
      {
        id: 'intellectual-property',
        title: '4. Intellectual Property Rights',
        icon: 'Copyright',
        collapsible: true,
        content: [
          {
            type: 'paragraph',
            text: 'The Service and its original content, features, and functionality are and will remain the exclusive property of SocialDownloader and its licensors. The service is protected by copyright, trademark, and other laws.'
          },
          {
            type: 'info',
            text: 'Downloaded content remains the property of its original creators and copyright holders.'
          },
          {
            type: 'list',
            items: [
              'You may not reproduce, distribute, or create derivative works of our service',
              'All trademarks and service marks are property of their respective owners',
              'You retain no ownership rights in downloaded content unless you are the original creator'
            ]
          }
        ]
      },
      {
        id: 'user-responsibilities',
        title: '5. User Responsibilities',
        icon: 'Users',
        collapsible: true,
        content: [
          {
            type: 'paragraph',
            text: 'As a user of SocialDownloader, you are responsible for your conduct and any content you download through our service. You agree to:'
          },
          {
            type: 'list',
            items: [
              'Comply with all applicable laws and regulations',
              'Respect the intellectual property rights of content creators',
              'Use downloaded content only for personal, non-commercial purposes unless authorized',
              'Not redistribute or share downloaded content without proper permissions',
              'Report any violations of these terms to our support team'
            ]
          },
          {
            type: 'highlight',
            text: 'Violation of these responsibilities may result in immediate termination of your access to the service.'
          }
        ]
      },
      {
        id: 'privacy-data',
        title: '6. Privacy and Data Protection',
        icon: 'Lock',
        collapsible: true,
        content: [
          {
            type: 'paragraph',
            text: 'Your privacy is important to us. Our Privacy Policy explains how we collect, use, and protect your information when you use our service. By using SocialDownloader, you agree to the collection and use of information in accordance with our Privacy Policy.'
          },
          {
            type: 'info',
            text: 'We do not store downloaded content on our servers and do not track your download history beyond the current session.'
          }
        ]
      },
      {
        id: 'disclaimers',
        title: '7. Disclaimers and Limitations',
        icon: 'AlertTriangle',
        collapsible: true,
        content: [
          {
            type: 'paragraph',
            text: 'The information on this service is provided on an "as is" basis. To the fullest extent permitted by law, SocialDownloader excludes all representations, warranties, conditions, and terms.'
          },
          {
            type: 'highlight',
            text: 'We do not guarantee the availability, accuracy, or reliability of downloaded content.'
          },
          {
            type: 'list',
            items: [
              'Service availability may be interrupted for maintenance or technical issues',
              'Download quality depends on source content and platform limitations',
              'We are not responsible for content removed by original platforms',
              'Users download content at their own risk and discretion'
            ]
          }
        ]
      },
      {
        id: 'termination',
        title: '8. Termination',
        icon: 'XCircle',
        collapsible: true,
        content: [
          {
            type: 'paragraph',
            text: 'We may terminate or suspend your access immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.'
          },
          {
            type: 'list',
            items: [
              'Termination may occur for violation of these terms',
              'We reserve the right to refuse service to anyone',
              'Upon termination, your right to use the service ceases immediately'
            ]
          }
        ]
      },
      {
        id: 'changes',
        title: '9. Changes to Terms',
        icon: 'Edit',
        collapsible: true,
        content: [
          {
            type: 'paragraph',
            text: 'We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material, we will try to provide at least 30 days notice prior to any new terms taking effect.'
          },
          {
            type: 'info',
            text: 'Continued use of the service after changes constitutes acceptance of the new terms.'
          }
        ]
      },
      {
        id: 'contact',
        title: '10. Contact Information',
        icon: 'Mail',
        collapsible: false,
        content: [
          {
            type: 'paragraph',
            text: 'If you have any questions about these Terms of Service, please contact us at:'
          },
          {
            type: 'list',
            items: [
              'Email: legal@socialdownloader.com',
              'Support: support@socialdownloader.com',
              'Address: 123 Legal Street, Tech City, TC 12345'
            ]
          }
        ]
      }
    ],
    es: [
      {
        id: 'acceptance',
        title: '1. Aceptación de Términos',
        icon: 'FileCheck',
        collapsible: false,
        content: [
          {
            type: 'paragraph',
            text: 'Al acceder y usar SocialDownloader ("el Servicio"), acepta y acuerda estar sujeto a los términos y disposiciones de este acuerdo. Si no acepta cumplir con lo anterior, por favor no use este servicio.'
          },
          {
            type: 'info',
            text: 'Estos términos se aplican a todos los visitantes, usuarios y otros que accedan o usen el servicio.'
          },
          {
            type: 'list',
            items: [
              'Debe tener al menos 13 años para usar este servicio',
              'Debe proporcionar información precisa y completa al crear una cuenta',
              'Es responsable de mantener la confidencialidad de su cuenta'
            ]
          }
        ]
      },
      {
        id: 'service-description',
        title: '2. Descripción del Servicio',
        icon: 'Globe',
        collapsible: true,
        content: [
          {
            type: 'paragraph',
            text: 'SocialDownloader es una plataforma basada en web que permite a los usuarios descargar contenido públicamente disponible de varias plataformas de redes sociales incluyendo YouTube, Instagram, Facebook, Twitter/X, TikTok, SoundCloud, Vimeo y LinkedIn.'
          },
          {
            type: 'highlight',
            text: 'Nuestro servicio solo funciona con contenido públicamente disponible y respeta los términos de servicio de las plataformas.'
          }
        ]
      }
    ]
  };

  const content = pageData[language] || pageData.en;
  const sections = sectionsData[language] || sectionsData.en;

  useEffect(() => {
    if (searchTerm) {
      const filtered = sections.filter(section =>
        section.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        section.content.some(item => 
          item.text && item.text.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
      setFilteredSections(filtered);
    } else {
      setFilteredSections(sections);
    }
  }, [searchTerm, sections]);

  const handleSectionClick = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleSectionVisible = (sectionId) => {
    setActiveSection(sectionId);
  };

  const handleSearch = (term) => {
    setSearchTerm(term);
  };

  return (
    <>
      <Helmet>
        <title>{content.title} - SocialDownloader</title>
        <meta name="description" content={content.description} />
        <meta name="keywords" content="terms of service, legal agreement, social media downloader, usage policy" />
        <meta property="og:title" content={`${content.title} - SocialDownloader`} />
        <meta property="og:description" content={content.description} />
        <meta property="og:type" content="website" />
        <link rel="canonical" href={`${window.location.origin}/terms-of-service`} />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-16">
          {/* Hero Section */}
          <section className="bg-surface border-b border-border py-12">
            <div className="container mx-auto px-4 lg:px-6">
              <div className="max-w-4xl mx-auto text-center">
                <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
                  {content.title}
                </h1>
                <p className="text-xl text-text-secondary mb-6">
                  {content.subtitle}
                </p>
                <p className="text-text-secondary">
                  {content.description}
                </p>
              </div>
            </div>
          </section>

          {/* Main Content */}
          <section className="py-12">
            <div className="container mx-auto px-4 lg:px-6">
              <div className="max-w-7xl mx-auto">
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                  {/* Sidebar */}
                  <div className="lg:col-span-1">
                    <TableOfContents
                      sections={sections}
                      activeSection={activeSection}
                      onSectionClick={handleSectionClick}
                      language={language}
                    />
                  </div>

                  {/* Content */}
                  <div className="lg:col-span-3">
                    <DocumentActions language={language} />
                    <LegalDisclaimer language={language} />
                    <SearchBar onSearch={handleSearch} language={language} />
                    
                    <div className="space-y-8">
                      {filteredSections.map((section) => (
                        <TermsSection
                          key={section.id}
                          section={section}
                          language={language}
                          onSectionVisible={handleSectionVisible}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </main>

        <Footer />
        <ProgressIndicator language={language} />
      </div>
    </>
  );
};

export default TermsOfService;