import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const DocumentActions = ({ language }) => {
  const actionsData = {
    en: {
      download: "Download PDF",
      print: "Print Document",
      bookmark: "Bookmark",
      share: "Share",
      lastUpdated: "Last updated",
      version: "Version 2.1"
    },
    es: {
      download: "Descargar PDF",
      print: "Imprimir Documento",
      bookmark: "Marcar",
      share: "Compartir",
      lastUpdated: "Última actualización",
      version: "Versión 2.1"
    }
  };

  const content = actionsData[language] || actionsData.en;

  const handleDownloadPDF = () => {
    // Mock PDF download functionality
    console.log('Downloading PDF...');
  };

  const handlePrint = () => {
    window.print();
  };

  const handleBookmark = () => {
    // Mock bookmark functionality
    console.log('Bookmarked');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'SocialDownloader Terms of Service',
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 mb-8">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between space-y-4 sm:space-y-0">
        <div className="flex flex-wrap gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownloadPDF}
            iconName="Download"
            iconPosition="left"
          >
            {content.download}
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={handlePrint}
            iconName="Printer"
            iconPosition="left"
          >
            {content.print}
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={handleBookmark}
            iconName="Bookmark"
            iconPosition="left"
          >
            {content.bookmark}
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={handleShare}
            iconName="Share2"
            iconPosition="left"
          >
            {content.share}
          </Button>
        </div>
        
        <div className="text-xs text-text-secondary">
          <div className="flex items-center space-x-4">
            <span>{content.lastUpdated}: July 12, 2025</span>
            <span className="flex items-center">
              <Icon name="FileText" size={12} className="mr-1" />
              {content.version}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentActions;