import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const ProgressIndicator = ({ language }) => {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  const progressData = {
    en: {
      progress: "Reading Progress",
      timeRemaining: "min remaining",
      backToTop: "Back to top"
    },
    es: {
      progress: "Progreso de Lectura",
      timeRemaining: "min restantes",
      backToTop: "Volver arriba"
    }
  };

  const content = progressData[language] || progressData.en;

  useEffect(() => {
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = (window.scrollY / totalHeight) * 100;
      setScrollProgress(Math.min(progress, 100));
      setIsVisible(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const estimatedTimeRemaining = Math.max(0, Math.ceil((100 - scrollProgress) * 0.12));

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <div className="bg-card border border-border rounded-lg p-4 shadow-lg min-w-48">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-foreground">
            {content.progress}
          </span>
          <span className="text-xs text-text-secondary">
            {Math.round(scrollProgress)}%
          </span>
        </div>
        
        <div className="w-full bg-muted rounded-full h-2 mb-3">
          <div 
            className="bg-primary h-2 rounded-full transition-all duration-300"
            style={{ width: `${scrollProgress}%` }}
          ></div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center text-xs text-text-secondary">
            <Icon name="Clock" size={12} className="mr-1" />
            <span>{estimatedTimeRemaining} {content.timeRemaining}</span>
          </div>
          
          <button
            onClick={scrollToTop}
            className="p-1 hover:bg-muted rounded-md transition-smooth"
            title={content.backToTop}
          >
            <Icon name="ArrowUp" size={14} className="text-text-secondary" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProgressIndicator;