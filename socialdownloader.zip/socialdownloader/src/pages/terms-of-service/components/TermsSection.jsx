import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const TermsSection = ({ section, language, onSectionVisible }) => {
  const [isExpanded, setIsExpanded] = useState(true);

  const sectionRef = React.useRef(null);

  React.useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          onSectionVisible(section.id);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, [section.id, onSectionVisible]);

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <section 
      ref={sectionRef}
      id={section.id}
      className="mb-8 scroll-mt-24"
    >
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-semibold text-foreground flex items-center">
          <Icon name={section.icon} size={24} className="mr-3 text-primary" />
          {section.title}
        </h2>
        {section.collapsible && (
          <button
            onClick={toggleExpanded}
            className="p-2 hover:bg-muted rounded-md transition-smooth"
          >
            <Icon 
              name={isExpanded ? "ChevronUp" : "ChevronDown"} 
              size={20} 
              className="text-text-secondary"
            />
          </button>
        )}
      </div>

      {isExpanded && (
        <div className="space-y-4">
          {section.content.map((paragraph, index) => (
            <div key={index} className="text-text-secondary leading-relaxed">
              {paragraph.type === 'paragraph' && (
                <p className="mb-4">{paragraph.text}</p>
              )}
              
              {paragraph.type === 'list' && (
                <ul className="list-disc list-inside space-y-2 ml-4">
                  {paragraph.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="text-sm">{item}</li>
                  ))}
                </ul>
              )}
              
              {paragraph.type === 'highlight' && (
                <div className="bg-warning/10 border-l-4 border-warning p-4 rounded-r-md">
                  <div className="flex items-start">
                    <Icon name="AlertTriangle" size={16} className="text-warning mr-2 mt-0.5" />
                    <p className="text-sm font-medium text-foreground">{paragraph.text}</p>
                  </div>
                </div>
              )}
              
              {paragraph.type === 'info' && (
                <div className="bg-primary/10 border-l-4 border-primary p-4 rounded-r-md">
                  <div className="flex items-start">
                    <Icon name="Info" size={16} className="text-primary mr-2 mt-0.5" />
                    <p className="text-sm text-foreground">{paragraph.text}</p>
                  </div>
                </div>
              )}
            </div>
          ))}
          
          {section.subsections && (
            <div className="mt-6 space-y-4">
              {section.subsections.map((subsection, subIndex) => (
                <div key={subIndex} className="border-l-2 border-border pl-4">
                  <h3 className="text-lg font-medium text-foreground mb-2">
                    {subsection.title}
                  </h3>
                  <p className="text-text-secondary text-sm leading-relaxed">
                    {subsection.content}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </section>
  );
};

export default TermsSection;