import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const TableOfContents = ({ sections, activeSection, onSectionClick, language }) => {
  const [isExpanded, setIsExpanded] = useState(true);

  const tocData = {
    en: {
      title: "Table of Contents",
      estimatedTime: "Estimated reading time: 12 minutes",
      collapse: "Collapse",
      expand: "Expand"
    },
    es: {
      title: "Tabla de Contenidos",
      estimatedTime: "Tiempo estimado de lectura: 12 minutos",
      collapse: "Contraer",
      expand: "Expandir"
    }
  };

  const content = tocData[language] || tocData.en;

  return (
    <div className="bg-card border border-border rounded-lg p-6 sticky top-24">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">
          {content.title}
        </h3>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="p-1 hover:bg-muted rounded-md transition-smooth"
        >
          <Icon 
            name={isExpanded ? "ChevronUp" : "ChevronDown"} 
            size={16} 
            className="text-text-secondary"
          />
        </button>
      </div>

      <p className="text-xs text-text-secondary mb-4 flex items-center">
        <Icon name="Clock" size={12} className="mr-1" />
        {content.estimatedTime}
      </p>

      {isExpanded && (
        <nav className="space-y-2">
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => onSectionClick(section.id)}
              className={`
                w-full text-left px-3 py-2 rounded-md text-sm transition-smooth
                ${activeSection === section.id 
                  ? 'bg-primary/10 text-primary border-l-2 border-primary' :'text-text-secondary hover:text-foreground hover:bg-muted'
                }
              `}
            >
              <div className="flex items-center justify-between">
                <span>{section.title}</span>
                {section.subsections && (
                  <Icon name="ChevronRight" size={12} />
                )}
              </div>
            </button>
          ))}
        </nav>
      )}
    </div>
  );
};

export default TableOfContents;