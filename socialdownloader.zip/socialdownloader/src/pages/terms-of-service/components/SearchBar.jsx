import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';

const SearchBar = ({ onSearch, language }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const searchData = {
    en: {
      placeholder: "Search terms and conditions...",
      noResults: "No results found",
      searchResults: "Search Results"
    },
    es: {
      placeholder: "Buscar términos y condiciones...",
      noResults: "No se encontraron resultados",
      searchResults: "Resultados de Búsqueda"
    }
  };

  const content = searchData[language] || searchData.en;

  const handleSearch = (value) => {
    setSearchTerm(value);
    onSearch(value);
  };

  const clearSearch = () => {
    setSearchTerm('');
    onSearch('');
  };

  return (
    <div className="relative mb-6">
      <div className="relative">
        <Input
          type="search"
          placeholder={content.placeholder}
          value={searchTerm}
          onChange={(e) => handleSearch(e.target.value)}
          className="pl-10 pr-10"
        />
        <Icon 
          name="Search" 
          size={16} 
          className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"
        />
        {searchTerm && (
          <button
            onClick={clearSearch}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-muted rounded-full transition-smooth"
          >
            <Icon name="X" size={14} className="text-text-secondary" />
          </button>
        )}
      </div>
    </div>
  );
};

export default SearchBar;