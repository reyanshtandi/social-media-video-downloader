import React from 'react';
import Icon from '../../../components/AppIcon';

const LegalDisclaimer = ({ language }) => {
  const disclaimerData = {
    en: {
      title: "Important Legal Notice",
      content: `These Terms of Service constitute a legally binding agreement between you and SocialDownloader. By using our service, you acknowledge that you have read, understood, and agree to be bound by these terms. If you do not agree with any part of these terms, you must not use our service.`,
      effectiveDate: "Effective Date: July 12, 2025",
      contact: "For legal inquiries, contact: legal@socialdownloader.com"
    },
    es: {
      title: "Aviso Legal Importante",
      content: `Estos Términos de Servicio constituyen un acuerdo legalmente vinculante entre usted y SocialDownloader. Al usar nuestro servicio, reconoce que ha leído, entendido y acepta estar sujeto a estos términos. Si no está de acuerdo con alguna parte de estos términos, no debe usar nuestro servicio.`,
      effectiveDate: "Fecha de Vigencia: 12 de julio de 2025",
      contact: "Para consultas legales, contacte: legal@socialdownloader.com"
    }
  };

  const content = disclaimerData[language] || disclaimerData.en;

  return (
    <div className="bg-warning/5 border border-warning/20 rounded-lg p-6 mb-8">
      <div className="flex items-start space-x-3">
        <Icon name="AlertTriangle" size={20} className="text-warning mt-0.5 flex-shrink-0" />
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-foreground mb-3">
            {content.title}
          </h3>
          <p className="text-text-secondary leading-relaxed mb-4">
            {content.content}
          </p>
          <div className="space-y-2 text-xs text-text-secondary">
            <div className="flex items-center">
              <Icon name="Calendar" size={12} className="mr-2" />
              <span>{content.effectiveDate}</span>
            </div>
            <div className="flex items-center">
              <Icon name="Mail" size={12} className="mr-2" />
              <span>{content.contact}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LegalDisclaimer;