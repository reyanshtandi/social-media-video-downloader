import React, { useState } from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const DownloadHistory = ({ language, isCollapsed = false, onToggle }) => {
  const [downloads] = useState([
    {
      id: 1,
      title: "Amazing Travel Vlog - Exploring Japan",
      platform: "youtube",
      thumbnail: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=300&h=200&fit=crop",
      format: "MP4 - 1080p",
      fileSize: "45.2 MB",
      downloadDate: new Date(Date.now() - 3600000),
      status: "completed"
    },
    {
      id: 2,
      title: "Cooking Tutorial: Perfect Pasta",
      platform: "instagram",
      thumbnail: "https://images.unsplash.com/photo-1551782450-17144efb9c50?w=300&h=200&fit=crop",
      format: "MP4 - 720p",
      fileSize: "28.7 MB",
      downloadDate: new Date(Date.now() - 7200000),
      status: "completed"
    },
    {
      id: 3,
      title: "Funny Dance Challenge",
      platform: "tiktok",
      thumbnail: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=300&h=200&fit=crop",
      format: "MP4 - 720p (No Watermark)",
      fileSize: "15.3 MB",
      downloadDate: new Date(Date.now() - 10800000),
      status: "completed"
    },
    {
      id: 4,
      title: "Tech Review: Latest Smartphone",
      platform: "youtube",
      thumbnail: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=200&fit=crop",
      format: "MP3 - 320kbps",
      fileSize: "8.9 MB",
      downloadDate: new Date(Date.now() - 14400000),
      status: "completed"
    }
  ]);

  const getPlatformIcon = (platform) => {
    const iconMap = {
      youtube: 'Youtube',
      instagram: 'Instagram',
      tiktok: 'Music',
      twitter: 'Twitter',
      facebook: 'Facebook'
    };
    return iconMap[platform] || 'Video';
  };

  const getPlatformColor = (platform) => {
    const colorMap = {
      youtube: 'text-red-500',
      instagram: 'text-pink-500',
      tiktok: 'text-black dark:text-white',
      twitter: 'text-blue-400',
      facebook: 'text-blue-600'
    };
    return colorMap[platform] || 'text-primary';
  };

  const formatTimeAgo = (date) => {
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return language === 'en' ? 'Just now' : 'Ahora mismo';
    } else if (diffInHours < 24) {
      return language === 'en' ? `${diffInHours}h ago` : `Hace ${diffInHours}h`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return language === 'en' ? `${diffInDays}d ago` : `Hace ${diffInDays}d`;
    }
  };

  if (isCollapsed) {
    return (
      <div className="bg-card border border-border rounded-lg p-4">
        <Button
          variant="ghost"
          onClick={onToggle}
          className="w-full justify-between"
        >
          <div className="flex items-center space-x-2">
            <Icon name="History" size={16} />
            <span className="text-sm font-medium">
              {language === 'en' ? 'Download History' : 'Historial de Descargas'}
            </span>
            <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
              {downloads.length}
            </span>
          </div>
          <Icon name="ChevronDown" size={16} />
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="History" size={18} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">
              {language === 'en' ? 'Download History' : 'Historial de Descargas'}
            </h3>
            <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">
              {downloads.length}
            </span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              iconName="Trash2"
              iconPosition="left"
            >
              {language === 'en' ? 'Clear' : 'Limpiar'}
            </Button>
            
            {onToggle && (
              <Button
                variant="ghost"
                size="icon"
                onClick={onToggle}
                className="lg:hidden"
              >
                <Icon name="ChevronUp" size={16} />
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Downloads List */}
      <div className="max-h-96 overflow-y-auto">
        {downloads.length === 0 ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="History" size={24} className="text-text-secondary" />
            </div>
            <h4 className="text-sm font-medium text-foreground mb-2">
              {language === 'en' ? 'No downloads yet' : 'Aún no hay descargas'}
            </h4>
            <p className="text-xs text-text-secondary">
              {language === 'en' ?'Your download history will appear here' :'Tu historial de descargas aparecerá aquí'
              }
            </p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {downloads.map((download) => (
              <div key={download.id} className="p-4 hover:bg-muted/50 transition-smooth">
                <div className="flex items-start space-x-3">
                  {/* Thumbnail */}
                  <div className="w-16 h-12 bg-muted rounded overflow-hidden flex-shrink-0">
                    <Image
                      src={download.thumbnail}
                      alt={download.title}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0 space-y-1">
                    <h4 className="text-sm font-medium text-foreground line-clamp-1">
                      {download.title}
                    </h4>
                    
                    <div className="flex items-center space-x-2 text-xs text-text-secondary">
                      <Icon 
                        name={getPlatformIcon(download.platform)} 
                        size={12} 
                        className={getPlatformColor(download.platform)}
                      />
                      <span className="capitalize">{download.platform}</span>
                      <span>•</span>
                      <span>{download.format}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 text-xs text-text-secondary">
                        <Icon name="HardDrive" size={12} />
                        <span>{download.fileSize}</span>
                        <span>•</span>
                        <span>{formatTimeAgo(download.downloadDate)}</span>
                      </div>

                      <div className="flex items-center space-x-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="w-6 h-6"
                          title={language === 'en' ? 'Download again' : 'Descargar de nuevo'}
                        >
                          <Icon name="Download" size={12} />
                        </Button>
                        
                        <Button
                          variant="ghost"
                          size="icon"
                          className="w-6 h-6"
                          title={language === 'en' ? 'Remove from history' : 'Eliminar del historial'}
                        >
                          <Icon name="X" size={12} />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      {downloads.length > 0 && (
        <div className="p-4 border-t border-border bg-muted/30">
          <div className="flex items-center justify-between text-xs text-text-secondary">
            <span>
              {language === 'en' 
                ? `${downloads.length} downloads in session`
                : `${downloads.length} descargas en sesión`
              }
            </span>
            <Button
              variant="ghost"
              size="sm"
              iconName="ExternalLink"
              iconPosition="right"
              className="text-xs"
            >
              {language === 'en' ? 'View All' : 'Ver Todo'}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default DownloadHistory;