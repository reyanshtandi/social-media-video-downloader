import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const DownloadProgress = ({ 
  isDownloading, 
  progress, 
  onDownload, 
  onCancel,
  estimatedTime,
  downloadSpeed,
  language,
  downloadComplete = false,
  fileName = '',
  fileSize = ''
}) => {
  const formatTime = (seconds) => {
    if (seconds < 60) return `${seconds}s`;
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  const formatSpeed = (bytesPerSecond) => {
    if (bytesPerSecond < 1024) return `${bytesPerSecond} B/s`;
    if (bytesPerSecond < 1024 * 1024) return `${(bytesPerSecond / 1024).toFixed(1)} KB/s`;
    return `${(bytesPerSecond / (1024 * 1024)).toFixed(1)} MB/s`;
  };

  if (downloadComplete) {
    return (
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="text-center space-y-4">
          {/* Success Icon */}
          <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto">
            <Icon name="CheckCircle" size={32} className="text-success" />
          </div>

          {/* Success Message */}
          <div className="space-y-2">
            <h3 className="text-lg font-semibold text-foreground">
              {language === 'en' ? 'Download Complete!' : '¡Descarga Completa!'}
            </h3>
            <p className="text-sm text-text-secondary">
              {language === 'en' ?'Your file has been successfully downloaded.' :'Tu archivo se ha descargado exitosamente.'
              }
            </p>
          </div>

          {/* File Info */}
          <div className="bg-muted/50 rounded-md p-4 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-text-secondary">
                {language === 'en' ? 'File Name:' : 'Nombre del Archivo:'}
              </span>
              <span className="font-medium text-foreground truncate ml-2">
                {fileName || 'downloaded_content.mp4'}
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-text-secondary">
                {language === 'en' ? 'File Size:' : 'Tamaño:'}
              </span>
              <span className="font-medium text-foreground">
                {fileSize || '25.4 MB'}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              variant="default"
              iconName="Download"
              iconPosition="left"
              className="flex-1"
              onClick={() => window.location.href = '/home-landing-page'}
            >
              {language === 'en' ? 'Download Another' : 'Descargar Otro'}
            </Button>
            <Button
              variant="outline"
              iconName="Share"
              iconPosition="left"
              className="flex-1"
            >
              {language === 'en' ? 'Share' : 'Compartir'}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (isDownloading) {
    return (
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="space-y-4">
          {/* Progress Header */}
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-foreground">
              {language === 'en' ? 'Downloading...' : 'Descargando...'}
            </h3>
            <span className="text-sm font-medium text-primary">
              {progress}%
            </span>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
              <div 
                className="bg-primary h-full rounded-full transition-all duration-300 ease-out relative overflow-hidden"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-shimmer"></div>
              </div>
            </div>
            
            {/* Progress Stats */}
            <div className="flex items-center justify-between text-xs text-text-secondary">
              <span>{progress}% {language === 'en' ? 'complete' : 'completo'}</span>
              {estimatedTime && (
                <span>
                  {language === 'en' ? 'ETA:' : 'Tiempo restante:'} {formatTime(estimatedTime)}
                </span>
              )}
            </div>
          </div>

          {/* Download Stats */}
          <div className="grid grid-cols-2 gap-4 pt-2">
            {downloadSpeed && (
              <div className="text-center p-3 bg-muted/50 rounded-md">
                <div className="flex items-center justify-center space-x-1 mb-1">
                  <Icon name="Zap" size={14} className="text-primary" />
                  <span className="text-xs text-text-secondary">
                    {language === 'en' ? 'Speed' : 'Velocidad'}
                  </span>
                </div>
                <span className="text-sm font-medium text-foreground">
                  {formatSpeed(downloadSpeed)}
                </span>
              </div>
            )}
            
            <div className="text-center p-3 bg-muted/50 rounded-md">
              <div className="flex items-center justify-center space-x-1 mb-1">
                <Icon name="Clock" size={14} className="text-primary" />
                <span className="text-xs text-text-secondary">
                  {language === 'en' ? 'Remaining' : 'Restante'}
                </span>
              </div>
              <span className="text-sm font-medium text-foreground">
                {estimatedTime ? formatTime(estimatedTime) : '--'}
              </span>
            </div>
          </div>

          {/* Cancel Button */}
          <div className="pt-4 border-t border-border">
            <Button
              variant="outline"
              iconName="X"
              iconPosition="left"
              onClick={onCancel}
              className="w-full"
            >
              {language === 'en' ? 'Cancel Download' : 'Cancelar Descarga'}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="text-center space-y-4">
        {/* Download Icon */}
        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
          <Icon name="Download" size={32} className="text-primary" />
        </div>

        {/* Ready Message */}
        <div className="space-y-2">
          <h3 className="text-lg font-semibold text-foreground">
            {language === 'en' ? 'Ready to Download' : 'Listo para Descargar'}
          </h3>
          <p className="text-sm text-text-secondary">
            {language === 'en' ?'Click the button below to start downloading your content.' :'Haz clic en el botón de abajo para comenzar a descargar tu contenido.'
            }
          </p>
        </div>

        {/* Download Button */}
        <Button
          variant="default"
          size="lg"
          iconName="Download"
          iconPosition="left"
          onClick={onDownload}
          className="w-full"
        >
          {language === 'en' ? 'Start Download' : 'Iniciar Descarga'}
        </Button>

        {/* Download Info */}
        <div className="pt-4 border-t border-border">
          <div className="flex items-center justify-center space-x-2 text-xs text-text-secondary">
            <Icon name="Shield" size={12} />
            <span>
              {language === 'en' ?'Secure download • No registration required' :'Descarga segura • No requiere registro'
              }
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DownloadProgress;