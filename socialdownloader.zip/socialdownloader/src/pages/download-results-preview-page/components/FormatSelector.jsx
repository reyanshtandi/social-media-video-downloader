import React, { useState } from 'react';

import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';
import Icon from '../../../components/AppIcon';

const FormatSelector = ({ 
  content, 
  onFormatChange, 
  selectedFormat, 
  language,
  onWatermarkToggle,
  removeWatermark = false 
}) => {
  const [activeTab, setActiveTab] = useState('video');

  const videoFormats = [
    { value: 'mp4_360p', label: 'MP4 - 360p', description: language === 'en' ? 'Standard quality' : 'Calidad estándar' },
    { value: 'mp4_720p', label: 'MP4 - 720p', description: language === 'en' ? 'HD quality' : 'Calidad HD' },
    { value: 'mp4_1080p', label: 'MP4 - 1080p', description: language === 'en' ? 'Full HD quality' : 'Calidad Full HD' },
    { value: 'webm_720p', label: 'WebM - 720p', description: language === 'en' ? 'HD quality' : 'Calidad HD' },
    { value: 'webm_1080p', label: 'WebM - 1080p', description: language === 'en' ? 'Full HD quality' : 'Calidad Full HD' }
  ];

  const audioFormats = [
    { value: 'mp3_128', label: 'MP3 - 128kbps', description: language === 'en' ? 'Standard quality' : 'Calidad estándar' },
    { value: 'mp3_256', label: 'MP3 - 256kbps', description: language === 'en' ? 'High quality' : 'Alta calidad' },
    { value: 'mp3_320', label: 'MP3 - 320kbps', description: language === 'en' ? 'Premium quality' : 'Calidad premium' },
    { value: 'm4a_256', label: 'M4A - 256kbps', description: language === 'en' ? 'High quality' : 'Alta calidad' },
    { value: 'm4a_320', label: 'M4A - 320kbps', description: language === 'en' ? 'Premium quality' : 'Calidad premium' }
  ];

  const tabs = [
    {
      id: 'video',
      label: language === 'en' ? 'Video' : 'Video',
      icon: 'Video',
      formats: videoFormats
    },
    {
      id: 'audio',
      label: language === 'en' ? 'Audio' : 'Audio',
      icon: 'Music',
      formats: audioFormats
    }
  ];

  const handleTabChange = (tabId) => {
    setActiveTab(tabId);
    // Reset format selection when switching tabs
    const defaultFormat = tabId === 'video' ? videoFormats[1] : audioFormats[1];
    onFormatChange(defaultFormat.value);
  };

  const getFormatIcon = (format) => {
    if (format.includes('mp4')) return 'FileVideo';
    if (format.includes('webm')) return 'FileVideo';
    if (format.includes('mp3')) return 'Music';
    if (format.includes('m4a')) return 'Music';
    return 'File';
  };

  const getQualityBadge = (format) => {
    if (format.includes('1080p') || format.includes('320')) return 'premium';
    if (format.includes('720p') || format.includes('256')) return 'high';
    return 'standard';
  };

  const getBadgeClasses = (quality) => {
    switch (quality) {
      case 'premium':
        return 'bg-primary/10 text-primary border-primary/20';
      case 'high':
        return 'bg-success/10 text-success border-success/20';
      default:
        return 'bg-muted text-text-secondary border-border';
    }
  };

  const currentTab = tabs.find(tab => tab.id === activeTab);

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      {/* Tab Navigation */}
      <div className="border-b border-border">
        <div className="flex">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => handleTabChange(tab.id)}
              className={`
                flex-1 flex items-center justify-center space-x-2 px-4 py-3 text-sm font-medium
                transition-smooth border-b-2 
                ${activeTab === tab.id
                  ? 'border-primary text-primary bg-primary/5' :'border-transparent text-text-secondary hover:text-foreground hover:bg-muted'
                }
              `}
            >
              <Icon name={tab.icon} size={16} />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Format Selection */}
      <div className="p-4 space-y-4">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-foreground">
              {language === 'en' ? 'Select Format & Quality' : 'Seleccionar Formato y Calidad'}
            </h3>
            <div className="flex items-center space-x-1 text-xs text-text-secondary">
              <Icon name="Info" size={12} />
              <span>
                {currentTab.formats.length} {language === 'en' ? 'options available' : 'opciones disponibles'}
              </span>
            </div>
          </div>

          {/* Format Options */}
          <div className="grid gap-2">
            {currentTab.formats.map((format) => (
              <label
                key={format.value}
                className={`
                  flex items-center space-x-3 p-3 rounded-md border cursor-pointer
                  transition-smooth hover:bg-muted/50
                  ${selectedFormat === format.value
                    ? 'border-primary bg-primary/5' :'border-border bg-background'
                  }
                `}
              >
                <input
                  type="radio"
                  name="format"
                  value={format.value}
                  checked={selectedFormat === format.value}
                  onChange={(e) => onFormatChange(e.target.value)}
                  className="sr-only"
                />
                
                <div className={`
                  w-4 h-4 rounded-full border-2 flex items-center justify-center
                  ${selectedFormat === format.value
                    ? 'border-primary bg-primary' :'border-border bg-background'
                  }
                `}>
                  {selectedFormat === format.value && (
                    <div className="w-2 h-2 rounded-full bg-white"></div>
                  )}
                </div>

                <Icon 
                  name={getFormatIcon(format.value)} 
                  size={16} 
                  className="text-text-secondary" 
                />

                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-foreground">
                      {format.label}
                    </span>
                    <span className={`
                      px-2 py-0.5 text-xs font-medium rounded border
                      ${getBadgeClasses(getQualityBadge(format.value))}
                    `}>
                      {getQualityBadge(format.value) === 'premium' 
                        ? (language === 'en' ? 'Premium' : 'Premium')
                        : getQualityBadge(format.value) === 'high'
                        ? (language === 'en' ? 'High' : 'Alta')
                        : (language === 'en' ? 'Standard' : 'Estándar')
                      }
                    </span>
                  </div>
                  <p className="text-xs text-text-secondary">
                    {format.description}
                  </p>
                </div>

                {selectedFormat === format.value && (
                  <Icon name="Check" size={16} className="text-primary" />
                )}
              </label>
            ))}
          </div>
        </div>

        {/* TikTok Watermark Option */}
        {content.platform.toLowerCase() === 'tiktok' && activeTab === 'video' && (
          <div className="pt-4 border-t border-border">
            <Checkbox
              label={language === 'en' ? 'Remove TikTok watermark' : 'Eliminar marca de agua de TikTok'}
              description={language === 'en' ?'Download video without TikTok branding' :'Descargar video sin marca de TikTok'
              }
              checked={removeWatermark}
              onChange={(e) => onWatermarkToggle(e.target.checked)}
              className="space-y-1"
            />
          </div>
        )}

        {/* Format Info */}
        <div className="pt-4 border-t border-border">
          <div className="flex items-start space-x-2 p-3 bg-muted/50 rounded-md">
            <Icon name="Info" size={16} className="text-primary mt-0.5" />
            <div className="text-xs text-text-secondary space-y-1">
              <p>
                {language === 'en' ?'Higher quality formats may take longer to process and result in larger file sizes.' :'Los formatos de mayor calidad pueden tardar más en procesarse y resultar en archivos más grandes.'
                }
              </p>
              <p>
                {language === 'en' ?'MP4 format is recommended for better compatibility across devices.' :'Se recomienda el formato MP4 para mejor compatibilidad entre dispositivos.'
                }
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FormatSelector;