import React from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';

const ContentPreviewCard = ({ content, language }) => {
  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatViews = (views) => {
    if (views >= 1000000) {
      return `${(views / 1000000).toFixed(1)}M`;
    } else if (views >= 1000) {
      return `${(views / 1000).toFixed(1)}K`;
    }
    return views.toString();
  };

  const getPlatformIcon = (platform) => {
    const iconMap = {
      youtube: 'Youtube',
      instagram: 'Instagram',
      tiktok: 'Music',
      twitter: 'Twitter',
      facebook: 'Facebook',
      soundcloud: 'Music',
      vimeo: 'Video',
      linkedin: 'Linkedin'
    };
    return iconMap[platform.toLowerCase()] || 'Video';
  };

  const getPlatformColor = (platform) => {
    const colorMap = {
      youtube: 'text-red-500',
      instagram: 'text-pink-500',
      tiktok: 'text-black dark:text-white',
      twitter: 'text-blue-400',
      facebook: 'text-blue-600',
      soundcloud: 'text-orange-500',
      vimeo: 'text-blue-500',
      linkedin: 'text-blue-700'
    };
    return colorMap[platform.toLowerCase()] || 'text-primary';
  };

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden shadow-sm">
      {/* Thumbnail Section */}
      <div className="relative aspect-video bg-muted overflow-hidden">
        <Image
          src={content.thumbnail}
          alt={content.title}
          className="w-full h-full object-cover"
        />
        
        {/* Duration Badge */}
        {content.duration && (
          <div className="absolute bottom-2 right-2 bg-black/80 text-white px-2 py-1 rounded text-xs font-medium">
            {formatDuration(content.duration)}
          </div>
        )}

        {/* Platform Badge */}
        <div className="absolute top-2 left-2 bg-background/90 backdrop-blur-sm border border-border rounded-md px-2 py-1 flex items-center space-x-1">
          <Icon 
            name={getPlatformIcon(content.platform)} 
            size={14} 
            className={getPlatformColor(content.platform)}
          />
          <span className="text-xs font-medium text-foreground capitalize">
            {content.platform}
          </span>
        </div>

        {/* Quality Badge */}
        {content.quality && (
          <div className="absolute top-2 right-2 bg-primary text-primary-foreground px-2 py-1 rounded text-xs font-medium">
            {content.quality}
          </div>
        )}
      </div>

      {/* Content Info */}
      <div className="p-4 space-y-3">
        {/* Title */}
        <h2 className="text-lg font-semibold text-foreground line-clamp-2 leading-tight">
          {content.title}
        </h2>

        {/* Creator Info */}
        {content.creator && (
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center overflow-hidden">
              {content.creator.avatar ? (
                <Image
                  src={content.creator.avatar}
                  alt={content.creator.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <Icon name="User" size={16} className="text-text-secondary" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">
                {content.creator.name}
              </p>
              {content.creator.verified && (
                <div className="flex items-center space-x-1">
                  <Icon name="CheckCircle" size={12} className="text-blue-500" />
                  <span className="text-xs text-text-secondary">
                    {language === 'en' ? 'Verified' : 'Verificado'}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="flex items-center justify-between text-sm text-text-secondary">
          <div className="flex items-center space-x-4">
            {content.views && (
              <div className="flex items-center space-x-1">
                <Icon name="Eye" size={14} />
                <span>{formatViews(content.views)} {language === 'en' ? 'views' : 'vistas'}</span>
              </div>
            )}
            
            {content.likes && (
              <div className="flex items-center space-x-1">
                <Icon name="Heart" size={14} />
                <span>{formatViews(content.likes)}</span>
              </div>
            )}
          </div>

          {content.uploadDate && (
            <span className="text-xs">
              {new Date(content.uploadDate).toLocaleDateString(
                language === 'en' ? 'en-US' : 'es-ES',
                { year: 'numeric', month: 'short', day: 'numeric' }
              )}
            </span>
          )}
        </div>

        {/* Description Preview */}
        {content.description && (
          <div className="pt-2 border-t border-border">
            <p className="text-sm text-text-secondary line-clamp-2">
              {content.description}
            </p>
          </div>
        )}

        {/* File Size Info */}
        {content.fileSize && (
          <div className="flex items-center justify-between pt-2 border-t border-border">
            <span className="text-sm text-text-secondary">
              {language === 'en' ? 'File Size:' : 'Tamaño:'}
            </span>
            <span className="text-sm font-medium text-foreground">
              {content.fileSize}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default ContentPreviewCard;