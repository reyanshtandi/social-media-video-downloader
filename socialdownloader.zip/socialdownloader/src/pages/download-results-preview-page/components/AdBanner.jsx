import React, { useState } from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const AdBanner = ({ 
  position = 'horizontal', // 'horizontal', 'vertical', 'square'
  size = 'medium', // 'small', 'medium', 'large'
  language,
  className = ""
}) => {
  const [isVisible, setIsVisible] = useState(true);
  const [isLoaded, setIsLoaded] = useState(true);

  // Mock ad data
  const adData = {
    title: language === 'en' ? 'Premium Video Editor' : 'Editor de Video Premium',
    description: language === 'en' ?'Edit your downloaded videos with professional tools. Free trial available!' :'¡Edita tus videos descargados con herramientas profesionales. Prueba gratuita disponible!',
    ctaText: language === 'en' ? 'Try Free' : 'Prueba Gratis',
    advertiser: 'VideoEdit Pro',
    image: 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=400&h=300&fit=crop'
  };

  const getSizeClasses = () => {
    const sizeMap = {
      horizontal: {
        small: 'h-20',
        medium: 'h-24',
        large: 'h-32'
      },
      vertical: {
        small: 'w-48 h-64',
        medium: 'w-56 h-80',
        large: 'w-64 h-96'
      },
      square: {
        small: 'w-48 h-48',
        medium: 'w-56 h-56',
        large: 'w-64 h-64'
      }
    };
    
    return sizeMap[position][size];
  };

  const handleClose = () => {
    setIsVisible(false);
  };

  if (!isVisible || !isLoaded) {
    return null;
  }

  return (
    <div className={`relative bg-card border border-border rounded-lg overflow-hidden ${getSizeClasses()} ${className}`}>
      {/* Ad Label */}
      <div className="absolute top-2 left-2 z-10">
        <span className="text-xs bg-muted/80 text-text-secondary px-2 py-0.5 rounded">
          {language === 'en' ? 'Ad' : 'Anuncio'}
        </span>
      </div>

      {/* Close Button */}
      <Button
        variant="ghost"
        size="icon"
        onClick={handleClose}
        className="absolute top-2 right-2 z-10 w-6 h-6 bg-background/80 hover:bg-background"
      >
        <Icon name="X" size={12} />
      </Button>

      {/* Ad Content */}
      {position === 'horizontal' ? (
        <div className="flex h-full">
          {/* Image */}
          <div className="w-24 h-full bg-muted flex-shrink-0 overflow-hidden">
            <img
              src={adData.image}
              alt={adData.title}
              className="w-full h-full object-cover"
              onError={() => setIsLoaded(false)}
            />
          </div>
          
          {/* Content */}
          <div className="flex-1 p-3 flex flex-col justify-center space-y-1">
            <h4 className="text-sm font-semibold text-foreground line-clamp-1">
              {adData.title}
            </h4>
            <p className="text-xs text-text-secondary line-clamp-2">
              {adData.description}
            </p>
            <div className="flex items-center justify-between mt-2">
              <span className="text-xs text-text-secondary">
                {adData.advertiser}
              </span>
              <Button
                variant="default"
                size="sm"
                className="text-xs px-3 py-1 h-6"
              >
                {adData.ctaText}
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <div className="h-full flex flex-col">
          {/* Image */}
          <div className="flex-1 bg-muted overflow-hidden">
            <img
              src={adData.image}
              alt={adData.title}
              className="w-full h-full object-cover"
              onError={() => setIsLoaded(false)}
            />
          </div>
          
          {/* Content */}
          <div className="p-3 space-y-2">
            <h4 className="text-sm font-semibold text-foreground line-clamp-1">
              {adData.title}
            </h4>
            <p className="text-xs text-text-secondary line-clamp-2">
              {adData.description}
            </p>
            <div className="space-y-2">
              <Button
                variant="default"
                size="sm"
                className="w-full text-xs"
              >
                {adData.ctaText}
              </Button>
              <div className="text-center">
                <span className="text-xs text-text-secondary">
                  {adData.advertiser}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Loading State */}
      {!isLoaded && (
        <div className="absolute inset-0 bg-muted animate-pulse flex items-center justify-center">
          <div className="text-center space-y-2">
            <Icon name="Image" size={24} className="text-text-secondary mx-auto" />
            <span className="text-xs text-text-secondary">
              {language === 'en' ? 'Loading ad...' : 'Cargando anuncio...'}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdBanner;