import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const ErrorDisplay = ({ 
  error, 
  onRetry, 
  onNewDownload, 
  language 
}) => {
  const getErrorIcon = (errorType) => {
    switch (errorType) {
      case 'private':
        return 'Lock';
      case 'not_found':
        return 'Search';
      case 'network':
        return 'Wifi';
      case 'format':
        return 'FileX';
      case 'rate_limit':
        return 'Clock';
      default:
        return 'AlertCircle';
    }
  };

  const getErrorTitle = (errorType) => {
    const titles = {
      en: {
        private: 'Private Content',
        not_found: 'Content Not Found',
        network: 'Network Error',
        format: 'Unsupported Format',
        rate_limit: 'Rate Limit Exceeded',
        default: 'Download Error'
      },
      es: {
        private: 'Contenido Privado',
        not_found: 'Contenido No Encontrado',
        network: 'Error de Red',
        format: 'Formato No Soportado',
        rate_limit: 'Límite de Velocidad Excedido',
        default: 'Error de Descarga'
      }
    };
    
    return titles[language][error.type] || titles[language].default;
  };

  const getErrorMessage = (errorType) => {
    const messages = {
      en: {
        private: 'This content is private and cannot be downloaded. Please check if the content is publicly accessible.',
        not_found: 'The requested content could not be found. The URL might be incorrect or the content may have been removed.',
        network: 'Unable to connect to the server. Please check your internet connection and try again.',
        format: 'This content format is not supported for download. Please try a different URL.',
        rate_limit: 'Too many requests. Please wait a moment before trying again.',
        default: 'An unexpected error occurred while processing your request. Please try again.'
      },
      es: {
        private: 'Este contenido es privado y no se puede descargar. Verifica si el contenido es públicamente accesible.',
        not_found: 'No se pudo encontrar el contenido solicitado. La URL podría ser incorrecta o el contenido pudo haber sido eliminado.',
        network: 'No se puede conectar al servidor. Verifica tu conexión a internet e intenta de nuevo.',
        format: 'Este formato de contenido no es compatible para descarga. Intenta con una URL diferente.',
        rate_limit: 'Demasiadas solicitudes. Espera un momento antes de intentar de nuevo.',
        default: 'Ocurrió un error inesperado al procesar tu solicitud. Intenta de nuevo.'
      }
    };
    
    return messages[language][error.type] || messages[language].default;
  };

  const getSuggestions = (errorType) => {
    const suggestions = {
      en: {
        private: [
          'Verify the content is publicly accessible',
          'Check if you have permission to view the content',
          'Try logging into the platform first'
        ],
        not_found: [
          'Double-check the URL for typos',
          'Ensure the content still exists',
          'Try copying the URL again from the source'
        ],
        network: [
          'Check your internet connection',
          'Try refreshing the page',
          'Wait a moment and try again'
        ],
        format: [
          'Try a different video or audio URL',
          'Check if the platform is supported',
          'Contact support if the issue persists'
        ],
        rate_limit: [
          'Wait 5-10 minutes before trying again',
          'Avoid making multiple requests quickly',
          'Try again during off-peak hours'
        ],
        default: [
          'Try again in a few moments',
          'Check your internet connection',
          'Contact support if the problem continues'
        ]
      },
      es: {
        private: [
          'Verifica que el contenido sea públicamente accesible',
          'Revisa si tienes permiso para ver el contenido',
          'Intenta iniciar sesión en la plataforma primero'
        ],
        not_found: [
          'Revisa la URL por errores tipográficos',
          'Asegúrate de que el contenido aún existe',
          'Intenta copiar la URL nuevamente desde la fuente'
        ],
        network: [
          'Verifica tu conexión a internet',
          'Intenta actualizar la página',
          'Espera un momento e intenta de nuevo'
        ],
        format: [
          'Intenta con una URL diferente de video o audio',
          'Verifica si la plataforma es compatible',
          'Contacta soporte si el problema persiste'
        ],
        rate_limit: [
          'Espera 5-10 minutos antes de intentar de nuevo',
          'Evita hacer múltiples solicitudes rápidamente',
          'Intenta de nuevo durante horas de menor actividad'
        ],
        default: [
          'Intenta de nuevo en unos momentos',
          'Verifica tu conexión a internet',
          'Contacta soporte si el problema continúa'
        ]
      }
    };
    
    return suggestions[language][error.type] || suggestions[language].default;
  };

  const getErrorColor = (errorType) => {
    switch (errorType) {
      case 'private':
        return 'text-warning';
      case 'rate_limit':
        return 'text-warning';
      default:
        return 'text-destructive';
    }
  };

  const getErrorBgColor = (errorType) => {
    switch (errorType) {
      case 'private':
        return 'bg-warning/10';
      case 'rate_limit':
        return 'bg-warning/10';
      default:
        return 'bg-destructive/10';
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="text-center space-y-6">
        {/* Error Icon */}
        <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto ${getErrorBgColor(error.type)}`}>
          <Icon 
            name={getErrorIcon(error.type)} 
            size={32} 
            className={getErrorColor(error.type)} 
          />
        </div>

        {/* Error Title & Message */}
        <div className="space-y-2">
          <h3 className="text-lg font-semibold text-foreground">
            {getErrorTitle(error.type)}
          </h3>
          <p className="text-sm text-text-secondary max-w-md mx-auto">
            {error.message || getErrorMessage(error.type)}
          </p>
        </div>

        {/* Error Code */}
        {error.code && (
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-muted rounded-full">
            <Icon name="Hash" size={12} className="text-text-secondary" />
            <span className="text-xs font-mono text-text-secondary">
              {error.code}
            </span>
          </div>
        )}

        {/* Suggestions */}
        <div className="bg-muted/50 rounded-md p-4 text-left max-w-md mx-auto">
          <h4 className="text-sm font-medium text-foreground mb-3 flex items-center">
            <Icon name="Lightbulb" size={14} className="mr-2 text-primary" />
            {language === 'en' ? 'Suggestions:' : 'Sugerencias:'}
          </h4>
          <ul className="space-y-2">
            {getSuggestions(error.type).map((suggestion, index) => (
              <li key={index} className="flex items-start space-x-2 text-xs text-text-secondary">
                <Icon name="ChevronRight" size={12} className="mt-0.5 text-primary flex-shrink-0" />
                <span>{suggestion}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 max-w-sm mx-auto">
          {onRetry && (
            <Button
              variant="default"
              iconName="RotateCcw"
              iconPosition="left"
              onClick={onRetry}
              className="flex-1"
            >
              {language === 'en' ? 'Try Again' : 'Intentar de Nuevo'}
            </Button>
          )}
          
          <Button
            variant="outline"
            iconName="Plus"
            iconPosition="left"
            onClick={onNewDownload}
            className="flex-1"
          >
            {language === 'en' ? 'New Download' : 'Nueva Descarga'}
          </Button>
        </div>

        {/* Help Link */}
        <div className="pt-4 border-t border-border">
          <Button
            variant="ghost"
            size="sm"
            iconName="HelpCircle"
            iconPosition="left"
            onClick={() => window.location.href = '/contact-support'}
          >
            {language === 'en' ? 'Need Help?' : '¿Necesitas Ayuda?'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ErrorDisplay;