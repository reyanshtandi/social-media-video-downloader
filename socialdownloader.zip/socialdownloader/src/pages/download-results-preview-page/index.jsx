import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Footer from '../../components/ui/Footer';
import ProgressIndicator from '../../components/ui/ProgressIndicator';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import useDownload from '../../hooks/useDownload';

// Import page components
import ContentPreviewCard from './components/ContentPreviewCard';
import FormatSelector from './components/FormatSelector';
import DownloadProgress from './components/DownloadProgress';
import DownloadHistory from './components/DownloadHistory';
import ErrorDisplay from './components/ErrorDisplay';
import AdBanner from './components/AdBanner';

const DownloadResultsPreviewPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  // Get URL and metadata from navigation state
  const { url, metadata: initialMetadata } = location.state || {};
  
  // Language state
  const [language, setLanguage] = useState('en');
  
  // Download options
  const [selectedFormat, setSelectedFormat] = useState('mp4_720p');
  const [removeWatermark, setRemoveWatermark] = useState(false);
  
  // UI states
  const [historyCollapsed, setHistoryCollapsed] = useState(true);
  const [showMobileHistory, setShowMobileHistory] = useState(false);

  // Download hook
  const {
    isDownloading,
    downloadProgress,
    downloadComplete,
    metadata,
    error,
    downloadInfo,
    startDownload,
    cancelDownload,
    reset,
    clearError,
    validateAndFetchMetadata
  } = useDownload();

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setLanguage(savedLanguage);

    // Listen for language changes
    const handleLanguageChange = (event) => {
      setLanguage(event.detail.language);
    };

    window.addEventListener('languageChange', handleLanguageChange);
    return () => window.removeEventListener('languageChange', handleLanguageChange);
  }, []);

  // Initialize metadata if coming from home page
  useEffect(() => {
    if (initialMetadata) {
      // Metadata was already fetched from home page
      return;
    }
    
    if (url && !metadata) {
      // Try to fetch metadata if URL is available but no metadata
      validateAndFetchMetadata(url).catch((error) => {
        console.error('Failed to fetch metadata:', error);
      });
    }
    
    if (!url) {
      // No URL provided, redirect to home
      navigate('/home-landing-page');
    }
  }, [url, metadata, initialMetadata, validateAndFetchMetadata, navigate]);

  // Use initial metadata or fetched metadata
  const contentData = initialMetadata || metadata;

  const handleDownload = () => {
    if (!url) return;
    
    const options = {
      format: selectedFormat,
      removeWatermark: removeWatermark && contentData?.platformInfo?.platform === 'tiktok'
    };
    
    startDownload(url, options);
  };

  const handleRetry = () => {
    clearError();
    handleDownload();
  };

  const handleNewDownload = () => {
    reset();
    navigate('/home-landing-page');
  };

  const handleFormatChange = (format) => {
    setSelectedFormat(format);
  };

  const handleWatermarkToggle = (enabled) => {
    setRemoveWatermark(enabled);
  };

  const progressSteps = [
    { 
      id: 1, 
      label: language === 'en' ? 'Enter URL' : 'Ingresar URL', 
      icon: 'Link' 
    },
    { 
      id: 2, 
      label: language === 'en' ? 'Preview Content' : 'Vista Previa', 
      icon: 'Eye' 
    },
    { 
      id: 3, 
      label: language === 'en' ? 'Download' : 'Descargar', 
      icon: 'Download' 
    }
  ];

  // Show loading if no content data yet
  if (!contentData && !error) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-16">
          <div className="container mx-auto px-4 lg:px-6 py-8">
            <div className="flex items-center justify-center min-h-[400px]">
              <div className="text-center space-y-4">
                <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent mx-auto"></div>
                <p className="text-text-secondary">
                  {language === 'en' ? 'Loading content...' : 'Cargando contenido...'}
                </p>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-16">
        {/* Progress Indicator */}
        <div className="bg-surface border-b border-border">
          <div className="container mx-auto px-4 lg:px-6 py-6">
            <ProgressIndicator 
              currentStep={downloadComplete ? 3 : 2} 
              totalSteps={3} 
              steps={progressSteps}
            />
          </div>
        </div>

        <div className="container mx-auto px-4 lg:px-6 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content Area */}
            <div className="lg:col-span-2 space-y-6">
              {/* Page Header */}
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-foreground">
                    {language === 'en' ? 'Download Preview' : 'Vista Previa de Descarga'}
                  </h1>
                  <p className="text-text-secondary mt-1">
                    {language === 'en' ?'Review your content and select download options' :'Revisa tu contenido y selecciona opciones de descarga'
                    }
                  </p>
                </div>
                
                <Button
                  variant="outline"
                  iconName="ArrowLeft"
                  iconPosition="left"
                  onClick={handleNewDownload}
                  className="hidden sm:flex"
                >
                  {language === 'en' ? 'New Download' : 'Nueva Descarga'}
                </Button>
              </div>

              {/* Content Preview Card */}
              {contentData && (
                <ContentPreviewCard 
                  content={contentData} 
                  language={language}
                />
              )}

              {/* Ad Banner - Horizontal */}
              <AdBanner 
                position="horizontal" 
                size="medium" 
                language={language}
                className="my-6"
              />

              {/* Format Selection */}
              {contentData && !error && (
                <FormatSelector
                  content={contentData}
                  selectedFormat={selectedFormat}
                  onFormatChange={handleFormatChange}
                  onWatermarkToggle={handleWatermarkToggle}
                  removeWatermark={removeWatermark}
                  language={language}
                />
              )}

              {/* Download Progress or Error */}
              {error ? (
                <ErrorDisplay
                  error={error}
                  onRetry={handleRetry}
                  onNewDownload={handleNewDownload}
                  language={language}
                />
              ) : (
                <DownloadProgress
                  isDownloading={isDownloading}
                  progress={downloadProgress}
                  onDownload={handleDownload}
                  onCancel={cancelDownload}
                  estimatedTime={downloadInfo.estimatedTime}
                  downloadSpeed={downloadInfo.downloadSpeed}
                  downloadComplete={downloadComplete}
                  fileName={downloadInfo.fileName}
                  fileSize={downloadInfo.fileSize}
                  language={language}
                />
              )}

              {/* Mobile History Toggle */}
              <div className="lg:hidden">
                <Button
                  variant="outline"
                  onClick={() => setShowMobileHistory(!showMobileHistory)}
                  className="w-full justify-between"
                >
                  <div className="flex items-center space-x-2">
                    <Icon name="History" size={16} />
                    <span>
                      {language === 'en' ? 'Download History' : 'Historial de Descargas'}
                    </span>
                  </div>
                  <Icon 
                    name={showMobileHistory ? 'ChevronUp' : 'ChevronDown'} 
                    size={16} 
                  />
                </Button>
                
                {showMobileHistory && (
                  <div className="mt-4">
                    <DownloadHistory 
                      language={language}
                      isCollapsed={false}
                      onToggle={() => setShowMobileHistory(false)}
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1 space-y-6">
              {/* Ad Banner - Vertical */}
              <AdBanner 
                position="vertical" 
                size="medium" 
                language={language}
                className="hidden lg:block"
              />

              {/* Download History - Desktop */}
              <div className="hidden lg:block">
                <DownloadHistory 
                  language={language}
                  isCollapsed={historyCollapsed}
                  onToggle={() => setHistoryCollapsed(!historyCollapsed)}
                />
              </div>

              {/* Quick Actions */}
              <div className="bg-card border border-border rounded-lg p-4">
                <h3 className="text-sm font-semibold text-foreground mb-3">
                  {language === 'en' ? 'Quick Actions' : 'Acciones Rápidas'}
                </h3>
                <div className="space-y-2">
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Plus"
                    iconPosition="left"
                    onClick={handleNewDownload}
                    className="w-full justify-start"
                  >
                    {language === 'en' ? 'Download Another' : 'Descargar Otro'}
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="HelpCircle"
                    iconPosition="left"
                    onClick={() => navigate('/how-to-use-guide')}
                    className="w-full justify-start"
                  >
                    {language === 'en' ? 'How to Use' : 'Cómo Usar'}
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="MessageCircle"
                    iconPosition="left"
                    onClick={() => navigate('/contact-support')}
                    className="w-full justify-start"
                  >
                    {language === 'en' ? 'Get Help' : 'Obtener Ayuda'}
                  </Button>
                </div>
              </div>

              {/* Platform Support Info */}
              <div className="bg-card border border-border rounded-lg p-4">
                <h3 className="text-sm font-semibold text-foreground mb-3">
                  {language === 'en' ? 'Supported Platforms' : 'Plataformas Soportadas'}
                </h3>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { name: 'YouTube', icon: 'Youtube', color: 'text-red-500' },
                    { name: 'Instagram', icon: 'Instagram', color: 'text-pink-500' },
                    { name: 'TikTok', icon: 'Music', color: 'text-black dark:text-white' },
                    { name: 'Twitter', icon: 'Twitter', color: 'text-blue-400' },
                    { name: 'Facebook', icon: 'Facebook', color: 'text-blue-600' },
                    { name: 'SoundCloud', icon: 'Music', color: 'text-orange-500' }
                  ].map((platform) => (
                    <div
                      key={platform.name}
                      className="flex items-center space-x-2 p-2 rounded-md bg-muted/50"
                    >
                      <Icon 
                        name={platform.icon} 
                        size={14} 
                        className={platform.color} 
                      />
                      <span className="text-xs text-text-secondary">
                        {platform.name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default DownloadResultsPreviewPage;