import React from 'react';
import Icon from '../../../components/AppIcon';

const ContactInfo = ({ language }) => {
  const contactMethods = [
    {
      icon: 'Mail',
      title: language === 'en' ? 'Email Support' : 'Soporte por Email',
      description: language === 'en' ? 'Get help via email' : 'Obtén ayuda por email',
      value: 'support@socialdownloader.com',
      responseTime: language === 'en' ? 'Response within 24 hours' : 'Respuesta en 24 horas'
    },
    {
      icon: 'MessageCircle',
      title: language === 'en' ? 'Live Chat' : 'Chat en Vivo',
      description: language === 'en' ? 'Instant support chat' : 'Chat de soporte instantáneo',
      value: language === 'en' ? 'Available 9 AM - 6 PM EST' : 'Disponible 9 AM - 6 PM EST',
      responseTime: language === 'en' ? 'Immediate response' : 'Respuesta inmediata'
    },
    {
      icon: 'Phone',
      title: language === 'en' ? 'Phone Support' : 'Soporte Telefónico',
      description: language === 'en' ? 'Premium users only' : 'Solo usuarios premium',
      value: '+1 (555) 123-4567',
      responseTime: language === 'en' ? 'Business hours only' : 'Solo horario comercial'
    }
  ];

  const supportHours = [
    {
      day: language === 'en' ? 'Monday - Friday' : 'Lunes - Viernes',
      hours: '9:00 AM - 6:00 PM EST'
    },
    {
      day: language === 'en' ? 'Saturday' : 'Sábado',
      hours: '10:00 AM - 4:00 PM EST'
    },
    {
      day: language === 'en' ? 'Sunday' : 'Domingo',
      hours: language === 'en' ? 'Closed' : 'Cerrado'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Contact Methods */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
            <Icon name="Headphones" size={18} className="text-success" />
          </div>
          <h2 className="text-xl font-semibold text-foreground">
            {language === 'en' ? 'Contact Methods' : 'Métodos de Contacto'}
          </h2>
        </div>

        <div className="space-y-4">
          {contactMethods.map((method, index) => (
            <div key={index} className="flex items-start space-x-4 p-4 bg-background rounded-lg border border-border hover:bg-muted transition-smooth">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Icon name={method.icon} size={18} className="text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-foreground mb-1">{method.title}</h3>
                <p className="text-sm text-text-secondary mb-2">{method.description}</p>
                <p className="text-sm font-medium text-foreground mb-1">{method.value}</p>
                <p className="text-xs text-success">{method.responseTime}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Support Hours */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-8 h-8 bg-warning/10 rounded-lg flex items-center justify-center">
            <Icon name="Clock" size={18} className="text-warning" />
          </div>
          <h2 className="text-xl font-semibold text-foreground">
            {language === 'en' ? 'Support Hours' : 'Horarios de Soporte'}
          </h2>
        </div>

        <div className="space-y-3">
          {supportHours.map((schedule, index) => (
            <div key={index} className="flex items-center justify-between py-2 border-b border-border last:border-b-0">
              <span className="text-sm font-medium text-foreground">{schedule.day}</span>
              <span className="text-sm text-text-secondary">{schedule.hours}</span>
            </div>
          ))}
        </div>

        <div className="mt-4 p-3 bg-warning/5 rounded-lg border border-warning/20">
          <div className="flex items-start space-x-2">
            <Icon name="Info" size={14} className="text-warning mt-0.5 flex-shrink-0" />
            <p className="text-xs text-text-secondary">
              {language === 'en' ?'During off-hours, you can still submit support tickets via the form above. We will respond as soon as possible during business hours.' :'Fuera del horario de atención, aún puedes enviar tickets de soporte a través del formulario anterior. Responderemos lo antes posible durante el horario comercial.'
              }
            </p>
          </div>
        </div>
      </div>

      {/* Emergency Contact */}
      <div className="bg-destructive/5 rounded-lg border border-destructive/20 p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-8 h-8 bg-destructive/10 rounded-lg flex items-center justify-center">
            <Icon name="AlertTriangle" size={18} className="text-destructive" />
          </div>
          <h3 className="text-lg font-semibold text-foreground">
            {language === 'en' ? 'Emergency Contact' : 'Contacto de Emergencia'}
          </h3>
        </div>
        
        <p className="text-sm text-text-secondary mb-3">
          {language === 'en' ?'For critical security issues or service outages affecting multiple users:' :'Para problemas críticos de seguridad o interrupciones del servicio que afecten a múltiples usuarios:'
          }
        </p>
        
        <div className="flex items-center space-x-2 text-sm">
          <Icon name="Mail" size={14} className="text-destructive" />
          <span className="font-medium text-foreground">emergency@socialdownloader.com</span>
        </div>
        
        <p className="text-xs text-text-secondary mt-2">
          {language === 'en' ?'Emergency contacts are monitored 24/7 and will receive immediate attention.' :'Los contactos de emergencia se monitorean 24/7 y recibirán atención inmediata.'
          }
        </p>
      </div>

      {/* Status Indicator */}
      <div className="bg-card rounded-lg border border-border p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 bg-success rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-foreground">
              {language === 'en' ? 'All Systems Operational' : 'Todos los Sistemas Operativos'}
            </span>
          </div>
          <button className="text-xs text-primary hover:underline">
            {language === 'en' ? 'View Status Page' : 'Ver Página de Estado'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ContactInfo;