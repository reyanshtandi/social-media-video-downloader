import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const ContactForm = ({ language }) => {
  const [formData, setFormData] = useState({
    email: '',
    subject: '',
    inquiryType: '',
    message: '',
    affectedUrl: '',
    deviceInfo: '',
    agreeToTerms: false
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [uploadedFile, setUploadedFile] = useState(null);

  const inquiryTypes = [
    { 
      value: 'technical', 
      label: language === 'en' ? 'Technical Issue' : 'Problema Técnico',
      description: language === 'en' ? 'Download errors, bugs, or technical problems' : 'Errores de descarga, bugs o problemas técnicos'
    },
    { 
      value: 'feature', 
      label: language === 'en' ? 'Feature Request' : 'Solicitud de Función',
      description: language === 'en' ? 'Suggest new features or improvements' : 'Sugerir nuevas funciones o mejoras'
    },
    { 
      value: 'general', 
      label: language === 'en' ? 'General Question' : 'Pregunta General',
      description: language === 'en' ? 'General inquiries about our service' : 'Consultas generales sobre nuestro servicio'
    },
    { 
      value: 'report', 
      label: language === 'en' ? 'Report Content' : 'Reportar Contenido',
      description: language === 'en' ? 'Report inappropriate or copyrighted content' : 'Reportar contenido inapropiado o con derechos de autor'
    }
  ];

  const validateForm = () => {
    const newErrors = {};

    if (!formData.email) {
      newErrors.email = language === 'en' ? 'Email is required' : 'El email es requerido';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = language === 'en' ? 'Please enter a valid email' : 'Por favor ingresa un email válido';
    }

    if (!formData.subject) {
      newErrors.subject = language === 'en' ? 'Subject is required' : 'El asunto es requerido';
    }

    if (!formData.inquiryType) {
      newErrors.inquiryType = language === 'en' ? 'Please select an inquiry type' : 'Por favor selecciona un tipo de consulta';
    }

    if (!formData.message) {
      newErrors.message = language === 'en' ? 'Message is required' : 'El mensaje es requerido';
    } else if (formData.message.length < 10) {
      newErrors.message = language === 'en' ? 'Message must be at least 10 characters' : 'El mensaje debe tener al menos 10 caracteres';
    }

    if (!formData.agreeToTerms) {
      newErrors.agreeToTerms = language === 'en' ? 'You must agree to the terms' : 'Debes aceptar los términos';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 2000);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const removeFile = () => {
    setUploadedFile(null);
    document.getElementById('file-upload').value = '';
  };

  if (isSubmitted) {
    return (
      <div className="bg-card rounded-lg border border-border p-8 text-center">
        <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="CheckCircle" size={32} className="text-success" />
        </div>
        <h3 className="text-xl font-semibold text-foreground mb-2">
          {language === 'en' ? 'Message Sent Successfully!' : '¡Mensaje Enviado Exitosamente!'}
        </h3>
        <p className="text-text-secondary mb-4">
          {language === 'en' ?'Thank you for contacting us. We have received your message and will respond within 24 hours.' :'Gracias por contactarnos. Hemos recibido tu mensaje y responderemos dentro de 24 horas.'
          }
        </p>
        <div className="bg-muted rounded-lg p-4 mb-6">
          <p className="text-sm text-foreground font-medium">
            {language === 'en' ? 'Ticket Number:' : 'Número de Ticket:'} #SD-{Date.now().toString().slice(-6)}
          </p>
          <p className="text-xs text-text-secondary mt-1">
            {language === 'en' ?'Please save this number for future reference' :'Por favor guarda este número para referencia futura'
            }
          </p>
        </div>
        <Button 
          onClick={() => {
            setIsSubmitted(false);
            setFormData({
              email: '',
              subject: '',
              inquiryType: '',
              message: '',
              affectedUrl: '',
              deviceInfo: '',
              agreeToTerms: false
            });
            setUploadedFile(null);
          }}
          variant="outline"
        >
          {language === 'en' ? 'Send Another Message' : 'Enviar Otro Mensaje'}
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
          <Icon name="MessageCircle" size={18} className="text-primary" />
        </div>
        <h2 className="text-xl font-semibold text-foreground">
          {language === 'en' ? 'Contact Support' : 'Contactar Soporte'}
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Email */}
        <Input
          label={language === 'en' ? 'Email Address' : 'Dirección de Email'}
          type="email"
          placeholder={language === 'en' ? 'your.email@example.com' : 'tu.email@ejemplo.com'}
          value={formData.email}
          onChange={(e) => handleInputChange('email', e.target.value)}
          error={errors.email}
          required
        />

        {/* Inquiry Type */}
        <Select
          label={language === 'en' ? 'Type of Inquiry' : 'Tipo de Consulta'}
          placeholder={language === 'en' ? 'Select inquiry type' : 'Selecciona tipo de consulta'}
          options={inquiryTypes}
          value={formData.inquiryType}
          onChange={(value) => handleInputChange('inquiryType', value)}
          error={errors.inquiryType}
          required
        />

        {/* Subject */}
        <Input
          label={language === 'en' ? 'Subject' : 'Asunto'}
          type="text"
          placeholder={language === 'en' ? 'Brief description of your issue' : 'Breve descripción de tu problema'}
          value={formData.subject}
          onChange={(e) => handleInputChange('subject', e.target.value)}
          error={errors.subject}
          required
        />

        {/* Conditional Fields based on Inquiry Type */}
        {(formData.inquiryType === 'technical' || formData.inquiryType === 'report') && (
          <Input
            label={language === 'en' ? 'Affected URL (Optional)' : 'URL Afectada (Opcional)'}
            type="url"
            placeholder={language === 'en' ? 'https://example.com/video' : 'https://ejemplo.com/video'}
            value={formData.affectedUrl}
            onChange={(e) => handleInputChange('affectedUrl', e.target.value)}
            description={language === 'en' ? 'URL of the content causing issues' : 'URL del contenido que causa problemas'}
          />
        )}

        {formData.inquiryType === 'technical' && (
          <Input
            label={language === 'en' ? 'Device Information (Optional)' : 'Información del Dispositivo (Opcional)'}
            type="text"
            placeholder={language === 'en' ? 'Browser, OS, device type' : 'Navegador, SO, tipo de dispositivo'}
            value={formData.deviceInfo}
            onChange={(e) => handleInputChange('deviceInfo', e.target.value)}
            description={language === 'en' ? 'Help us troubleshoot by sharing your device details' : 'Ayúdanos a solucionar problemas compartiendo los detalles de tu dispositivo'}
          />
        )}

        {/* Message */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            {language === 'en' ? 'Message' : 'Mensaje'} *
          </label>
          <textarea
            value={formData.message}
            onChange={(e) => handleInputChange('message', e.target.value)}
            placeholder={language === 'en' ?'Please describe your issue or question in detail...' :'Por favor describe tu problema o pregunta en detalle...'
            }
            rows={5}
            className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground placeholder-text-secondary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
          />
          {errors.message && (
            <p className="mt-1 text-xs text-destructive">{errors.message}</p>
          )}
        </div>

        {/* File Upload */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            {language === 'en' ? 'Attach Screenshot (Optional)' : 'Adjuntar Captura (Opcional)'}
          </label>
          <div className="border-2 border-dashed border-border rounded-lg p-4 text-center hover:border-primary/50 transition-smooth">
            {uploadedFile ? (
              <div className="flex items-center justify-between bg-muted rounded-md p-3">
                <div className="flex items-center space-x-2">
                  <Icon name="File" size={16} className="text-text-secondary" />
                  <span className="text-sm text-foreground">{uploadedFile.name}</span>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={removeFile}
                >
                  <Icon name="X" size={14} />
                </Button>
              </div>
            ) : (
              <div>
                <Icon name="Upload" size={24} className="text-text-secondary mx-auto mb-2" />
                <p className="text-sm text-text-secondary mb-2">
                  {language === 'en' ?'Click to upload or drag and drop' :'Haz clic para subir o arrastra y suelta'
                  }
                </p>
                <p className="text-xs text-text-secondary">
                  {language === 'en' ? 'PNG, JPG up to 5MB' : 'PNG, JPG hasta 5MB'}
                </p>
                <input
                  id="file-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById('file-upload').click()}
                  className="mt-2"
                >
                  {language === 'en' ? 'Choose File' : 'Elegir Archivo'}
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Terms Agreement */}
        <Checkbox
          label={language === 'en' ?'I agree to the Terms of Service and Privacy Policy' :'Acepto los Términos de Servicio y Política de Privacidad'
          }
          checked={formData.agreeToTerms}
          onChange={(e) => handleInputChange('agreeToTerms', e.target.checked)}
          error={errors.agreeToTerms}
          required
        />

        {/* Submit Button */}
        <Button
          type="submit"
          loading={isSubmitting}
          disabled={isSubmitting}
          fullWidth
          iconName="Send"
          iconPosition="right"
        >
          {isSubmitting 
            ? (language === 'en' ? 'Sending...' : 'Enviando...')
            : (language === 'en' ? 'Send Message' : 'Enviar Mensaje')
          }
        </Button>
      </form>

      {/* Privacy Notice */}
      <div className="mt-6 p-4 bg-muted rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Shield" size={16} className="text-primary mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-sm text-foreground font-medium mb-1">
              {language === 'en' ? 'Privacy Notice' : 'Aviso de Privacidad'}
            </p>
            <p className="text-xs text-text-secondary">
              {language === 'en' ?'Your information is encrypted and will only be used to respond to your inquiry. We do not share personal data with third parties.' :'Tu información está encriptada y solo se usará para responder a tu consulta. No compartimos datos personales con terceros.'
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactForm;