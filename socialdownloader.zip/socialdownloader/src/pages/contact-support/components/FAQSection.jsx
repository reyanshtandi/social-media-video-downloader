import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const FAQSection = ({ language }) => {
  const [openFAQ, setOpenFAQ] = useState(null);

  const faqData = [
    {
      id: 1,
      question: language === 'en' ? 'Which platforms are supported?' : '¿Qué plataformas son compatibles?',
      answer: language === 'en' ?'We support YouTube, Instagram, Facebook, Twitter/X, TikTok, SoundCloud, Vimeo, and LinkedIn. More platforms are being added regularly.' :'Admitimos YouTube, Instagram, Facebook, Twitter/X, TikTok, SoundCloud, Vimeo y LinkedIn. Se agregan más plataformas regularmente.'
    },
    {
      id: 2,
      question: language === 'en' ? 'Are there any download limits?' : '¿Hay límites de descarga?',
      answer: language === 'en' ?'Free users can download up to 10 videos per day. Premium users have unlimited downloads with faster processing speeds.' :'Los usuarios gratuitos pueden descargar hasta 10 videos por día. Los usuarios premium tienen descargas ilimitadas con velocidades de procesamiento más rápidas.'
    },
    {
      id: 3,
      question: language === 'en' ? 'Why is my download failing?' : '¿Por qué falla mi descarga?',
      answer: language === 'en' ?'Common issues include: private videos, age-restricted content, invalid URLs, or temporary server issues. Try refreshing and ensure the content is publicly accessible.' :'Los problemas comunes incluyen: videos privados, contenido con restricción de edad, URLs inválidas o problemas temporales del servidor. Intenta actualizar y asegúrate de que el contenido sea públicamente accesible.'
    },
    {
      id: 4,
      question: language === 'en' ? 'What video qualities are available?' : '¿Qué calidades de video están disponibles?',
      answer: language === 'en' ?'We offer multiple quality options: 360p, 720p, 1080p, and sometimes 4K depending on the source. Audio formats include MP3 (128kbps, 256kbps, 320kbps) and M4A.' :'Ofrecemos múltiples opciones de calidad: 360p, 720p, 1080p y a veces 4K dependiendo de la fuente. Los formatos de audio incluyen MP3 (128kbps, 256kbps, 320kbps) y M4A.'
    },
    {
      id: 5,
      question: language === 'en' ? 'Is it safe to use this service?' : '¿Es seguro usar este servicio?',
      answer: language === 'en' ?'Yes, we use SSL encryption and do not store your personal data or downloaded content. All downloads are processed securely and deleted from our servers immediately.' :'Sí, usamos cifrado SSL y no almacenamos tus datos personales o contenido descargado. Todas las descargas se procesan de forma segura y se eliminan de nuestros servidores inmediatamente.'
    }
  ];

  const toggleFAQ = (id) => {
    setOpenFAQ(openFAQ === id ? null : id);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
          <Icon name="HelpCircle" size={18} className="text-primary" />
        </div>
        <h2 className="text-xl font-semibold text-foreground">
          {language === 'en' ? 'Frequently Asked Questions' : 'Preguntas Frecuentes'}
        </h2>
      </div>

      <div className="space-y-3">
        {faqData.map((faq) => (
          <div key={faq.id} className="border border-border rounded-lg overflow-hidden">
            <button
              onClick={() => toggleFAQ(faq.id)}
              className="w-full px-4 py-4 text-left bg-background hover:bg-muted transition-smooth flex items-center justify-between"
            >
              <span className="font-medium text-foreground text-sm">
                {faq.question}
              </span>
              <Icon 
                name={openFAQ === faq.id ? "ChevronUp" : "ChevronDown"} 
                size={16} 
                className="text-text-secondary flex-shrink-0 ml-3"
              />
            </button>
            
            {openFAQ === faq.id && (
              <div className="px-4 py-3 bg-muted border-t border-border">
                <p className="text-sm text-text-secondary leading-relaxed">
                  {faq.answer}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-primary/5 rounded-lg border border-primary/20">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={16} className="text-primary mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-sm text-foreground font-medium mb-1">
              {language === 'en' ? 'Still need help?' : '¿Aún necesitas ayuda?'}
            </p>
            <p className="text-xs text-text-secondary">
              {language === 'en' ?'If you cannot find the answer to your question above, please use the contact form below.' :'Si no puedes encontrar la respuesta a tu pregunta arriba, por favor usa el formulario de contacto a continuación.'
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQSection;