import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import Footer from '../../components/ui/Footer';
import FAQSection from './components/FAQSection';
import ContactForm from './components/ContactForm';
import ContactInfo from './components/ContactInfo';
import Icon from '../../components/AppIcon';

const ContactSupport = () => {
  const [language, setLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setLanguage(savedLanguage);

    const handleLanguageChange = (event) => {
      setLanguage(event.detail.language);
    };

    window.addEventListener('languageChange', handleLanguageChange);
    return () => window.removeEventListener('languageChange', handleLanguageChange);
  }, []);

  const breadcrumbs = [
    { 
      label: language === 'en' ? 'Home' : 'Inicio', 
      path: '/home-landing-page' 
    },
    { 
      label: language === 'en' ? 'Contact Support' : 'Contactar Soporte', 
      path: '/contact-support' 
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>
          {language === 'en' ?'Contact Support - SocialDownloader | Get Help & Technical Support' :'Contactar Soporte - SocialDownloader | Obtén Ayuda y Soporte Técnico'
          }
        </title>
        <meta 
          name="description" 
          content={language === 'en' ?'Get technical support, report issues, and contact our team. Fast response times and comprehensive help for all your social media downloading needs.' :'Obtén soporte técnico, reporta problemas y contacta a nuestro equipo. Tiempos de respuesta rápidos y ayuda integral para todas tus necesidades de descarga de redes sociales.'
          }
        />
        <meta name="keywords" content="contact support, technical help, customer service, social media downloader support" />
        <link rel="canonical" href="https://socialdownloader.com/contact-support" />
      </Helmet>

      <Header />

      <main className="pt-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary/5 via-background to-secondary/5 py-16">
          <div className="container mx-auto px-4 lg:px-6">
            {/* Breadcrumbs */}
            <nav className="flex items-center space-x-2 text-sm text-text-secondary mb-8">
              {breadcrumbs.map((crumb, index) => (
                <React.Fragment key={crumb.path}>
                  {index > 0 && <Icon name="ChevronRight" size={14} />}
                  <span className={index === breadcrumbs.length - 1 ? 'text-foreground font-medium' : 'hover:text-foreground'}>
                    {crumb.label}
                  </span>
                </React.Fragment>
              ))}
            </nav>

            <div className="max-w-4xl mx-auto text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Icon name="Headphones" size={32} className="text-primary" />
              </div>
              
              <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
                {language === 'en' ? 'How Can We Help You?' : '¿Cómo Podemos Ayudarte?'}
              </h1>
              
              <p className="text-xl text-text-secondary mb-8 leading-relaxed">
                {language === 'en' ?'Get fast, reliable support for all your social media downloading needs. Our team is here to help you resolve any issues quickly.' :'Obtén soporte rápido y confiable para todas tus necesidades de descarga de redes sociales. Nuestro equipo está aquí para ayudarte a resolver cualquier problema rápidamente.'
                }
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
                <div className="bg-card rounded-lg border border-border p-6 text-center">
                  <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Icon name="Clock" size={24} className="text-success" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">
                    {language === 'en' ? '24h Response' : 'Respuesta 24h'}
                  </h3>
                  <p className="text-sm text-text-secondary">
                    {language === 'en' ? 'Fast response times' : 'Tiempos de respuesta rápidos'}
                  </p>
                </div>

                <div className="bg-card rounded-lg border border-border p-6 text-center">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Icon name="Users" size={24} className="text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">
                    {language === 'en' ? 'Expert Team' : 'Equipo Experto'}
                  </h3>
                  <p className="text-sm text-text-secondary">
                    {language === 'en' ? 'Technical specialists' : 'Especialistas técnicos'}
                  </p>
                </div>

                <div className="bg-card rounded-lg border border-border p-6 text-center">
                  <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Icon name="Shield" size={24} className="text-warning" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">
                    {language === 'en' ? 'Secure Support' : 'Soporte Seguro'}
                  </h3>
                  <p className="text-sm text-text-secondary">
                    {language === 'en' ? 'Privacy protected' : 'Privacidad protegida'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Main Content */}
        <section className="py-16">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left Column - FAQ and Contact Info */}
              <div className="lg:col-span-1 space-y-8">
                <FAQSection language={language} />
                <ContactInfo language={language} />
              </div>

              {/* Right Column - Contact Form */}
              <div className="lg:col-span-2">
                <ContactForm language={language} />
              </div>
            </div>
          </div>
        </section>

        {/* Additional Help Section */}
        <section className="py-16 bg-muted">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-foreground mb-4">
                  {language === 'en' ? 'Additional Resources' : 'Recursos Adicionales'}
                </h2>
                <p className="text-text-secondary">
                  {language === 'en' ?'Explore our help resources to find quick solutions' :'Explora nuestros recursos de ayuda para encontrar soluciones rápidas'
                  }
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-card rounded-lg border border-border p-6 hover:shadow-lg transition-smooth">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon name="BookOpen" size={24} className="text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground mb-2">
                        {language === 'en' ? 'User Guide' : 'Guía del Usuario'}
                      </h3>
                      <p className="text-sm text-text-secondary mb-3">
                        {language === 'en' ?'Step-by-step instructions for using our platform' :'Instrucciones paso a paso para usar nuestra plataforma'
                        }
                      </p>
                      <button className="text-sm text-primary hover:underline font-medium">
                        {language === 'en' ? 'Read Guide →' : 'Leer Guía →'}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-lg border border-border p-6 hover:shadow-lg transition-smooth">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon name="MessageSquare" size={24} className="text-success" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground mb-2">
                        {language === 'en' ? 'Community Forum' : 'Foro de la Comunidad'}
                      </h3>
                      <p className="text-sm text-text-secondary mb-3">
                        {language === 'en' ?'Connect with other users and share experiences' :'Conecta con otros usuarios y comparte experiencias'
                        }
                      </p>
                      <button className="text-sm text-success hover:underline font-medium">
                        {language === 'en' ? 'Join Forum →' : 'Unirse al Foro →'}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-lg border border-border p-6 hover:shadow-lg transition-smooth">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon name="Video" size={24} className="text-warning" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground mb-2">
                        {language === 'en' ? 'Video Tutorials' : 'Tutoriales en Video'}
                      </h3>
                      <p className="text-sm text-text-secondary mb-3">
                        {language === 'en' ?'Watch detailed video guides and tutorials' :'Mira guías detalladas en video y tutoriales'
                        }
                      </p>
                      <button className="text-sm text-warning hover:underline font-medium">
                        {language === 'en' ? 'Watch Videos →' : 'Ver Videos →'}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-lg border border-border p-6 hover:shadow-lg transition-smooth">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-destructive/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon name="AlertCircle" size={24} className="text-destructive" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground mb-2">
                        {language === 'en' ? 'Known Issues' : 'Problemas Conocidos'}
                      </h3>
                      <p className="text-sm text-text-secondary mb-3">
                        {language === 'en' ?'Check current known issues and workarounds' :'Revisa los problemas conocidos actuales y soluciones'
                        }
                      </p>
                      <button className="text-sm text-destructive hover:underline font-medium">
                        {language === 'en' ? 'View Issues →' : 'Ver Problemas →'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default ContactSupport;