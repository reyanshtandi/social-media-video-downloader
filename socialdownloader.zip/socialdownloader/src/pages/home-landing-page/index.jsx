import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Footer from '../../components/ui/Footer';
import HeroSection from './components/HeroSection';
import SupportedPlatforms from './components/SupportedPlatforms';
import FeatureHighlights from './components/FeatureHighlights';
import HowItWorks from './components/HowItWorks';
import AdBanner from './components/AdBanner';
import useDownload from '../../hooks/useDownload';

const HomeLandingPage = () => {
  const [language, setLanguage] = useState('en');
  const navigate = useNavigate();
  
  const {
    isValidating,
    validateAndFetchMetadata,
    error,
    clearError
  } = useDownload();

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setLanguage(savedLanguage);

    // Listen for language changes
    const handleLanguageChange = (event) => {
      setLanguage(event.detail.language);
    };

    window.addEventListener('languageChange', handleLanguageChange);
    return () => window.removeEventListener('languageChange', handleLanguageChange);
  }, []);

  const handleUrlSubmit = async (url) => {
    try {
      clearError();
      
      // Validate URL and fetch metadata
      const metadata = await validateAndFetchMetadata(url);
      
      // Navigate to download results page with metadata
      navigate('/download-results-preview-page', { 
        state: { 
          url, 
          metadata, 
          timestamp: Date.now() 
        } 
      });
    } catch (error) {
      // Error is already set by the hook, just log it
      console.error('URL validation failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Top Ad Banner */}
      <div className="pt-16">
        <AdBanner position="top" language={language} />
      </div>

      <main>
        {/* Hero Section */}
        <HeroSection 
          onUrlSubmit={handleUrlSubmit}
          isProcessing={isValidating}
          error={error}
          onClearError={clearError}
          language={language}
        />

        {/* Supported Platforms */}
        <SupportedPlatforms language={language} />

        {/* Feature Highlights */}
        <FeatureHighlights language={language} />

        {/* How It Works */}
        <HowItWorks language={language} />

        {/* Bottom Ad Banner */}
        <AdBanner position="bottom" language={language} />
      </main>

      <Footer />
    </div>
  );
};

export default HomeLandingPage;