import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const SupportedPlatforms = ({ language }) => {
  const content = {
    en: {
      title: "Supported Platforms",
      subtitle: "Download content from all major social media platforms",
      comingSoon: "Coming Soon"
    },
    es: {
      title: "Plataformas Soportadas", 
      subtitle: "Descarga contenido de todas las principales plataformas de redes sociales",
      comingSoon: "Próximamente"
    }
  };

  const platforms = [
    {
      name: "YouTube",
      icon: "Youtube",
      color: "text-red-600",
      bgColor: "bg-red-50 dark:bg-red-900/20",
      supported: true,
      formats: ["MP4", "MP3", "WebM"]
    },
    {
      name: "Instagram", 
      icon: "Instagram",
      color: "text-pink-600",
      bgColor: "bg-pink-50 dark:bg-pink-900/20",
      supported: true,
      formats: ["MP4", "JPG"]
    },
    {
      name: "TikTok",
      icon: "Music",
      color: "text-black dark:text-white",
      bgColor: "bg-gray-50 dark:bg-gray-900/20", 
      supported: true,
      formats: ["MP4", "MP3"]
    },
    {
      name: "Twitter/X",
      icon: "Twitter", 
      color: "text-blue-500",
      bgColor: "bg-blue-50 dark:bg-blue-900/20",
      supported: true,
      formats: ["MP4", "GIF"]
    },
    {
      name: "Facebook",
      icon: "Facebook",
      color: "text-blue-700",
      bgColor: "bg-blue-50 dark:bg-blue-900/20",
      supported: true,
      formats: ["MP4", "MP3"]
    },
    {
      name: "SoundCloud",
      icon: "Music2",
      color: "text-orange-600", 
      bgColor: "bg-orange-50 dark:bg-orange-900/20",
      supported: true,
      formats: ["MP3", "M4A"]
    },
    {
      name: "Vimeo",
      icon: "Video",
      color: "text-blue-600",
      bgColor: "bg-blue-50 dark:bg-blue-900/20",
      supported: true,
      formats: ["MP4", "WebM"]
    },
    {
      name: "LinkedIn",
      icon: "Linkedin",
      color: "text-blue-800",
      bgColor: "bg-blue-50 dark:bg-blue-900/20", 
      supported: false,
      formats: ["MP4"]
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-surface">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            {content[language].title}
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            {content[language].subtitle}
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {platforms.map((platform, index) => (
            <div
              key={platform.name}
              className={`
                relative p-6 rounded-xl border transition-all duration-200 hover:shadow-lg
                ${platform.supported 
                  ? 'bg-white dark:bg-slate-800 border-border hover:border-primary/30 cursor-pointer hover:-translate-y-1' :'bg-muted border-border opacity-60'
                }
              `}
            >
              {/* Platform Icon */}
              <div className={`w-12 h-12 rounded-lg ${platform.bgColor} flex items-center justify-center mb-4 mx-auto`}>
                <Icon 
                  name={platform.icon} 
                  size={24} 
                  className={platform.color}
                />
              </div>

              {/* Platform Name */}
              <h3 className="text-lg font-semibold text-foreground text-center mb-2">
                {platform.name}
              </h3>

              {/* Supported Formats */}
              <div className="flex flex-wrap justify-center gap-1 mb-3">
                {platform.formats.map((format) => (
                  <span
                    key={format}
                    className="px-2 py-1 text-xs font-medium bg-primary/10 text-primary rounded-md"
                  >
                    {format}
                  </span>
                ))}
              </div>

              {/* Status Badge */}
              <div className="flex items-center justify-center">
                {platform.supported ? (
                  <div className="flex items-center space-x-1 text-success">
                    <Icon name="Check" size={14} />
                    <span className="text-xs font-medium">
                      {language === 'en' ? 'Available' : 'Disponible'}
                    </span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-1 text-warning">
                    <Icon name="Clock" size={14} />
                    <span className="text-xs font-medium">
                      {content[language].comingSoon}
                    </span>
                  </div>
                )}
              </div>

              {/* Coming Soon Overlay */}
              {!platform.supported && (
                <div className="absolute inset-0 bg-muted/50 rounded-xl flex items-center justify-center">
                  <span className="text-sm font-medium text-text-secondary">
                    {content[language].comingSoon}
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="text-center mt-12">
          <div className="inline-flex items-center space-x-2 px-4 py-2 bg-primary/10 text-primary rounded-full">
            <Icon name="Plus" size={16} />
            <span className="text-sm font-medium">
              {language === 'en' ?'More platforms coming soon!' :'¡Más plataformas próximamente!'
              }
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SupportedPlatforms;