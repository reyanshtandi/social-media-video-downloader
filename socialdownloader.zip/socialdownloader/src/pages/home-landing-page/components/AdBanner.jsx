import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AdBanner = ({ position = "top", language }) => {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  const content = {
    en: {
      topAd: {
        title: "🚀 Premium Features Coming Soon!",
        description: "Get early access to batch downloads, cloud storage, and premium quality options.",
        cta: "Join Waitlist",
        dismiss: "Dismiss"
      },
      bottomAd: {
        title: "💡 Love SocialDownloader?",
        description: "Help us grow by sharing with friends and following us on social media for updates.",
        cta: "Share Now",
        dismiss: "Maybe Later"
      }
    },
    es: {
      topAd: {
        title: "🚀 ¡Funciones Premium Próximamente!",
        description: "Obtén acceso temprano a descargas por lotes, almacenamiento en la nube y opciones de calidad premium.",
        cta: "Unirse a Lista",
        dismiss: "Descartar"
      },
      bottomAd: {
        title: "💡 ¿Te Gusta SocialDownloader?",
        description: "Ayúdanos a crecer compartiendo con amigos y siguiéndonos en redes sociales para actualizaciones.",
        cta: "Compartir Ahora",
        dismiss: "Tal Vez Después"
      }
    }
  };

  const adContent = position === "top" ? content[language].topAd : content[language].bottomAd;
  
  const handleDismiss = () => {
    setIsVisible(false);
  };

  const handleCtaClick = () => {
    // Mock action for demo purposes
    if (position === "top") {
      alert(language === 'en' ? 'Thanks for your interest! We\'ll notify you when premium features are available.' : '¡Gracias por tu interés! Te notificaremos cuando las funciones premium estén disponibles.');
    } else {
      // Mock share functionality
      if (navigator.share) {
        navigator.share({
          title: 'SocialDownloader',
          text: language === 'en' ? 'Check out this amazing social media downloader!' : '¡Mira este increíble descargador de redes sociales!',
          url: window.location.href
        });
      } else {
        alert(language === 'en' ? 'Thanks for wanting to share! Copy this URL to share with friends.' : '¡Gracias por querer compartir! Copia esta URL para compartir con amigos.');
      }
    }
  };

  return (
    <div className={`
      relative w-full bg-gradient-to-r 
      ${position === "top" ?"from-blue-500 to-purple-600" :"from-green-500 to-blue-500"
      } 
      text-white py-4 px-4 lg:px-6
    `}>
      <div className="container mx-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 flex-1">
            {/* Icon */}
            <div className="hidden sm:flex w-10 h-10 bg-white/20 rounded-full items-center justify-center">
              <Icon 
                name={position === "top" ? "Star" : "Heart"} 
                size={20} 
                color="white"
              />
            </div>

            {/* Content */}
            <div className="flex-1">
              <h3 className="font-semibold text-sm lg:text-base mb-1">
                {adContent.title}
              </h3>
              <p className="text-xs lg:text-sm text-white/90 leading-relaxed">
                {adContent.description}
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-2 ml-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCtaClick}
              className="bg-white/20 hover:bg-white/30 text-white border-white/30 text-xs lg:text-sm"
            >
              {adContent.cta}
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={handleDismiss}
              className="w-8 h-8 hover:bg-white/20 text-white"
              title={adContent.dismiss}
            >
              <Icon name="X" size={16} />
            </Button>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-2 left-10 w-2 h-2 bg-white/30 rounded-full animate-pulse"></div>
        <div className="absolute bottom-2 right-20 w-3 h-3 bg-white/20 rounded-full animate-pulse delay-500"></div>
        <div className="absolute top-1/2 right-10 w-1 h-1 bg-white/40 rounded-full animate-pulse delay-1000"></div>
      </div>
    </div>
  );
};

export default AdBanner;