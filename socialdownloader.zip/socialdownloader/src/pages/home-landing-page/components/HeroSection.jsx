import React, { useState, useEffect } from 'react';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';
import downloadService from '../../../services/downloadService';

const HeroSection = ({ onUrlSubmit, isProcessing, error, onClearError, language }) => {
  const [url, setUrl] = useState('');
  const [urlError, setUrlError] = useState('');

  const content = {
    en: {
      title: "Download Social Media Content",
      subtitle: "Fast, secure, and reliable downloads from your favorite platforms",
      placeholder: "Paste your video or audio URL here (YouTube, Instagram, TikTok, etc.)",
      downloadButton: "Download Now",
      supportedText: "Supported Platforms",
      features: [
        "High Quality Downloads",
        "Multiple Format Options", 
        "No Registration Required",
        "100% Free to Use"
      ],
      errors: {
        invalid_url: "Please enter a valid URL",
        unsupported_platform: "This platform is not supported yet",
        empty_url: "Please enter a URL",
        network_error: "Network error - please check your connection",
        server_error: "Server error - please try again later"
      }
    },
    es: {
      title: "Descargar Contenido de Redes Sociales",
      subtitle: "Descargas rápidas, seguras y confiables de tus plataformas favoritas",
      placeholder: "Pega tu URL de video o audio aquí (YouTube, Instagram, TikTok, etc.)",
      downloadButton: "Descargar Ahora",
      supportedText: "Plataformas Soportadas",
      features: [
        "Descargas de Alta Calidad",
        "Múltiples Opciones de Formato",
        "Sin Registro Requerido", 
        "100% Gratis"
      ],
      errors: {
        invalid_url: "Por favor ingresa una URL válida",
        unsupported_platform: "Esta plataforma aún no es compatible",
        empty_url: "Por favor ingresa una URL",
        network_error: "Error de red - verifica tu conexión",
        server_error: "Error del servidor - intenta más tarde"
      }
    }
  };

  // Clear URL error when user starts typing
  useEffect(() => {
    if (urlError && url) {
      setUrlError('');
    }
  }, [url, urlError]);

  // Clear URL error when main error is cleared
  useEffect(() => {
    if (!error && urlError) {
      setUrlError('');
    }
  }, [error, urlError]);

  const validateUrl = async (inputUrl) => {
    if (!inputUrl?.trim()) {
      return content[language].errors.empty_url;
    }

    try {
      // Use the download service to validate the URL
      await downloadService.validateUrl(inputUrl.trim());
      return '';
    } catch (error) {
      // Map error messages to user-friendly messages
      const errorMessage = error.message.toLowerCase();
      
      if (errorMessage.includes('invalid') || errorMessage.includes('format')) {
        return content[language].errors.invalid_url;
      } else if (errorMessage.includes('unsupported') || errorMessage.includes('not supported')) {
        return content[language].errors.unsupported_platform;
      } else if (errorMessage.includes('network') || errorMessage.includes('connection')) {
        return content[language].errors.network_error;
      } else if (errorMessage.includes('server')) {
        return content[language].errors.server_error;
      }
      
      return error.message;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const trimmedUrl = url.trim();
    const validationError = await validateUrl(trimmedUrl);
    
    if (validationError) {
      setUrlError(validationError);
      return;
    }

    // Clear any previous errors
    setUrlError('');
    if (onClearError) {
      onClearError();
    }
    
    // Submit the URL
    if (onUrlSubmit) {
      onUrlSubmit(trimmedUrl);
    }
  };

  const handleUrlChange = (e) => {
    const newUrl = e.target.value;
    setUrl(newUrl);
    
    // Clear errors when user starts typing
    if (urlError) {
      setUrlError('');
    }
    if (error && onClearError) {
      onClearError();
    }
  };

  // Determine which error to show
  const displayError = urlError || (error?.type === 'validation' ? error.message : '');

  return (
    <section className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 py-20 lg:py-32">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main Heading */}
          <h1 className="text-4xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
            {content[language].title}
          </h1>
          
          {/* Subtitle */}
          <p className="text-lg lg:text-xl text-text-secondary mb-8 max-w-2xl mx-auto leading-relaxed">
            {content[language].subtitle}
          </p>

          {/* Features Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
            {content[language].features.map((feature, index) => (
              <div key={index} className="flex items-center justify-center space-x-2 p-3 bg-white/50 dark:bg-slate-800/50 rounded-lg backdrop-blur-sm">
                <Icon name="Check" size={16} className="text-success" />
                <span className="text-sm font-medium text-foreground">{feature}</span>
              </div>
            ))}
          </div>

          {/* Download Form */}
          <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
            <div className="bg-white dark:bg-slate-800 p-6 lg:p-8 rounded-2xl shadow-lg border border-border">
              
              {/* Global Error Display */}
              {error?.type === 'download' && (
                <div className="mb-4 p-4 bg-error/10 border border-error/20 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <Icon name="AlertCircle" size={16} className="text-error" />
                    <span className="text-sm text-error font-medium">
                      {error.message}
                    </span>
                  </div>
                </div>
              )}

              <Input
                type="url"
                placeholder={content[language].placeholder}
                value={url}
                onChange={handleUrlChange}
                error={displayError}
                className="mb-6"
                disabled={isProcessing}
                autoComplete="off"
                spellCheck="false"
              />
              
              <Button
                type="submit"
                variant="default"
                size="lg"
                fullWidth
                loading={isProcessing}
                iconName="Download"
                iconPosition="left"
                className="text-lg py-4"
                disabled={!url.trim() || isProcessing}
              >
                {isProcessing 
                  ? (language === 'en' ? 'Processing...' : 'Procesando...') 
                  : content[language].downloadButton
                }
              </Button>
            </div>
          </form>

          {/* Security Badge */}
          <div className="flex items-center justify-center space-x-2 mt-8 text-sm text-text-secondary">
            <Icon name="Shield" size={16} className="text-success" />
            <span>
              {language === 'en' ?'Secure & Private - No data stored' :'Seguro y Privado - No se almacenan datos'
              }
            </span>
          </div>

          {/* Processing Status */}
          {isProcessing && (
            <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="flex items-center justify-center space-x-2">
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-600 border-t-transparent"></div>
                <span className="text-sm text-blue-700 dark:text-blue-300">
                  {language === 'en' ?'Analyzing your link...' :'Analizando tu enlace...'
                  }
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Background Decoration */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-20 h-20 bg-blue-200 dark:bg-blue-800 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-32 h-32 bg-purple-200 dark:bg-purple-800 rounded-full opacity-20 animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-green-200 dark:bg-green-800 rounded-full opacity-20 animate-pulse delay-500"></div>
      </div>
    </section>
  );
};

export default HeroSection;