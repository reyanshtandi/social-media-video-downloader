import React from 'react';
import Icon from '../../../components/AppIcon';

const FeatureHighlights = ({ language }) => {
  const content = {
    en: {
      title: "Why Choose SocialDownloader?",
      subtitle: "Experience the fastest and most reliable way to download social media content",
      features: [
        {
          icon: "Zap",
          title: "Lightning Fast",
          description: "Download videos and audio in seconds with our optimized servers and advanced processing technology."
        },
        {
          icon: "Shield",
          title: "100% Secure",
          description: "Your privacy is our priority. We don't store your data or downloaded content on our servers."
        },
        {
          icon: "Settings",
          title: "Multiple Formats",
          description: "Choose from various video and audio formats including MP4, MP3, WebM with quality options."
        },
        {
          icon: "Smartphone",
          title: "Mobile Friendly",
          description: "Works perfectly on all devices - desktop, tablet, and mobile with responsive design."
        },
        {
          icon: "DollarSign",
          title: "Completely Free",
          description: "No hidden fees, no subscriptions, no registration required. Download unlimited content for free."
        },
        {
          icon: "Globe",
          title: "Multi-Platform",
          description: "Support for YouTube, Instagram, TikTok, Facebook, Twitter, SoundCloud, and more platforms."
        }
      ]
    },
    es: {
      title: "¿Por Qué Elegir SocialDownloader?",
      subtitle: "Experimenta la forma más rápida y confiable de descargar contenido de redes sociales",
      features: [
        {
          icon: "Zap",
          title: "Súper Rápido",
          description: "Descarga videos y audio en segundos con nuestros servidores optimizados y tecnología avanzada."
        },
        {
          icon: "Shield", 
          title: "100% Seguro",
          description: "Tu privacidad es nuestra prioridad. No almacenamos tus datos ni contenido descargado en nuestros servidores."
        },
        {
          icon: "Settings",
          title: "Múltiples Formatos",
          description: "Elige entre varios formatos de video y audio incluyendo MP4, MP3, WebM con opciones de calidad."
        },
        {
          icon: "Smartphone",
          title: "Compatible con Móviles",
          description: "Funciona perfectamente en todos los dispositivos - escritorio, tablet y móvil con diseño responsivo."
        },
        {
          icon: "DollarSign",
          title: "Completamente Gratis",
          description: "Sin tarifas ocultas, sin suscripciones, sin registro requerido. Descarga contenido ilimitado gratis."
        },
        {
          icon: "Globe",
          title: "Multi-Plataforma",
          description: "Soporte para YouTube, Instagram, TikTok, Facebook, Twitter, SoundCloud y más plataformas."
        }
      ]
    }
  };

  return (
    <section className="py-16 lg:py-24 bg-white dark:bg-slate-900">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            {content[language].title}
          </h2>
          <p className="text-lg text-text-secondary max-w-3xl mx-auto">
            {content[language].subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {content[language].features.map((feature, index) => (
            <div
              key={index}
              className="group p-6 bg-surface dark:bg-slate-800 rounded-xl border border-border hover:border-primary/30 transition-all duration-200 hover:shadow-lg hover:-translate-y-1"
            >
              {/* Icon */}
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <Icon 
                  name={feature.icon} 
                  size={24} 
                  className="text-primary"
                />
              </div>

              {/* Title */}
              <h3 className="text-xl font-semibold text-foreground mb-3">
                {feature.title}
              </h3>

              {/* Description */}
              <p className="text-text-secondary leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-primary to-blue-600 text-white rounded-full shadow-lg">
            <Icon name="Star" size={20} />
            <span className="font-medium">
              {language === 'en' ?'Trusted by millions of users worldwide' :'Confiado por millones de usuarios en todo el mundo'
              }
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeatureHighlights;