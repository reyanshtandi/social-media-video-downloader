import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const HowItWorks = ({ language }) => {
  const content = {
    en: {
      title: "How It Works",
      subtitle: "Download your favorite content in just 3 simple steps",
      learnMore: "Learn More",
      steps: [
        {
          number: "01",
          title: "Paste URL",
          description: "Copy and paste the link of the video or audio you want to download from any supported platform.",
          icon: "Link"
        },
        {
          number: "02", 
          title: "Choose Format",
          description: "Select your preferred format (MP4, MP3, WebM) and quality settings that suit your needs.",
          icon: "Settings"
        },
        {
          number: "03",
          title: "Download",
          description: "Click download and get your content instantly. No waiting, no registration required.",
          icon: "Download"
        }
      ]
    },
    es: {
      title: "Cómo Funciona",
      subtitle: "Descarga tu contenido favorito en solo 3 pasos simples",
      learnMore: "Aprende Más",
      steps: [
        {
          number: "01",
          title: "Pegar URL",
          description: "Copia y pega el enlace del video o audio que quieres descargar de cualquier plataforma soportada.",
          icon: "Link"
        },
        {
          number: "02",
          title: "Elegir Formato", 
          description: "Selecciona tu formato preferido (MP4, MP3, WebM) y configuraciones de calidad que se adapten a tus necesidades.",
          icon: "Settings"
        },
        {
          number: "03",
          title: "Descargar",
          description: "Haz clic en descargar y obtén tu contenido al instante. Sin esperas, sin registro requerido.",
          icon: "Download"
        }
      ]
    }
  };

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-800 dark:to-slate-900">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            {content[language].title}
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto mb-8">
            {content[language].subtitle}
          </p>
          
          <Link to="/how-to-use-guide">
            <Button variant="outline" iconName="ArrowRight" iconPosition="right">
              {content[language].learnMore}
            </Button>
          </Link>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
            {content[language].steps.map((step, index) => (
              <div key={index} className="relative">
                {/* Step Card */}
                <div className="bg-white dark:bg-slate-800 p-8 rounded-2xl shadow-lg border border-border hover:shadow-xl transition-all duration-200 text-center">
                  {/* Step Number */}
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-primary text-primary-foreground rounded-full text-2xl font-bold mb-6">
                    {step.number}
                  </div>

                  {/* Icon */}
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Icon 
                      name={step.icon} 
                      size={24} 
                      className="text-primary"
                    />
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-semibold text-foreground mb-4">
                    {step.title}
                  </h3>

                  {/* Description */}
                  <p className="text-text-secondary leading-relaxed">
                    {step.description}
                  </p>
                </div>

                {/* Connector Arrow (Desktop only) */}
                {index < content[language].steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-6 transform -translate-y-1/2 z-10">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                      <Icon 
                        name="ArrowRight" 
                        size={20} 
                        className="text-primary"
                      />
                    </div>
                  </div>
                )}

                {/* Connector Arrow (Mobile) */}
                {index < content[language].steps.length - 1 && (
                  <div className="lg:hidden flex justify-center my-6">
                    <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                      <Icon 
                        name="ArrowDown" 
                        size={16} 
                        className="text-primary"
                      />
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Additional Tips */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center space-x-2 px-6 py-3 bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm rounded-full border border-border">
            <Icon name="Lightbulb" size={18} className="text-warning" />
            <span className="text-sm font-medium text-foreground">
              {language === 'en' ?'Pro Tip: Bookmark this page for quick access to downloads!' :'¡Consejo: Marca esta página para acceso rápido a descargas!'
              }
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;